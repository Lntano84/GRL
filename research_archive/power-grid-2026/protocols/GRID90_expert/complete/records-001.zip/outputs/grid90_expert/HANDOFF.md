# GRID90 外部启发式比较接续

用户2026-10-19授权开始与ExpertOp4Grid比较，沿用统一控制/仿真/质量与计时标准。当前持久隐藏pipeline已启动，初始PID3912；它依次运行run.py、audit.py、archive.py --phase complete及scripts/git_push.cmd，正常前进时不启动第二运行器。

## 冻结范围

- 工作区D:/Codex/GRL研究；代码work/grid90_expert；结果outputs/grid90_expert。
- 冻结提交00d623df；design.json、713项code_freeze.json、96项data_freeze.json。全部6个已暴露G2场景、FRAME_GUARD与EXPERTOP_SHARED、两次交错反向计时共24条。
- ExpertOp作者源v0.3.3，commit f740aa80da1f6028ab558fe4a22cf28db2d8c3df；ExpertAgent参考commit2ec125b84ca0163f024a3ed170a411b2ad4e857a。
- 不训练、不调参、不改候选库/控制器/日期/阈值/预算，不追加其它对照；基线原默认每监测线25候选、每站5、至多3过载。所有较差结果保留。
- 两方法使用同一公共候选代表和别名、基础控制、普通一步预测。原生影响图/专家评分直接调用；公共接口不临时改保护或动作限制。分析线切除单独计查询。当前基线是任务适配，不是原论文/原完整ExpertAgent复现。
- 当公共控制器在rho<1调用时，适配分析负载率最高在线线；真正过载按原优先级处理。候选预测按相同基础动作组合和合法性/奖励规则返回最佳动作，不带入基线自有恢复/重连模块。
- 原纸正文已逐页提取通读：论文实验也使用历史候选动作库。这里限制共有库有原设定依据。

## 检查与恢复

先读pipeline_state.json、manifest.json、finished.json、pipeline_error.json、benchmark_error.json、最新worker日志和active_worker.json；核对pipeline.py/run.py/worker.py父子进程。source freeze期间不得改代码。计时期间不安装、训练或重型审计。

若正常推进，保持已有运行；若停，先核对完整目录/收据/冻结哈希。不重跑完整项，不自动删除部分输出。run.py遇到完整目录且result存在会校验后接回manifest；部分目录无result则安全停止，需工程恢复审查。

预检历史错误不当作新故障：live_final/live_qualification_error.json记录的是预测观测4712维、物理观测4460维不一致的保存接口问题，尚未有正式回放。已改用预测观测类模板，并以live_vector_fixed/live_qualification.json的三次真实校准状态通过；qualify.py的保存向量复原只属于接口检查，没有正确日历预测，不能解释为质量试验。原错误和所有尝试保留。正式benchmark/pipeline错误若产生则另行处理。

原依赖环境未升级。pydot3.0.4、rustworkx0.17.1仅安装在work/grid90_expert/deps。vendor完整克隆在D盘本地，Git只归档必要源码、MPL许可证和小记录，不拷入运行时/大数据。

## 审计与完成

audit.py在全部benchmark结束后检查保存物理动作/观测、合法反馈、逐步成本、所有候选和分析查询、严格预算、原生排名重执行、重复路径与FRAME重现GRID89。为预测观测类模板仅在初始化状态做一次forecast，不重新求解保存轨迹；不称独立AC重求解。

质量参考仅使用GRID89 sealed FULL的存活/时域/完整周成本，不能使用旧FULL时间称本批提速。双方全6质量和时域一致才有同质量计算比较资格；FRAME控制与查询宏平均少5%、至少4/6日期时间同向、两计时重复同向才通过冻结判据。否则完整报告质量/计算权衡或可比竞争力，不改预算救结果。公共反事实不可用需单列，不解释成原ExpertOp算法失败。

完成需确认review.json、decision.json、GRID90_report.md、complete.json、完整归档及Git远端SHA一致。协作目录论文协作资料/FRAME_ExpertOp启发式对照_20261019。中文通知应给两方法质量/完成/成本、完整控制/查询及P95，说明任务适配和同网已暴露场景范围。无需改论文、画图或自动新增实验；不恢复任何旧自动化。

本轮自动跟进ID为grid90-expertop；只跟进本轮，正常运行安静，完成或无法恢复通知后删除。未恢复任何旧自动化。
