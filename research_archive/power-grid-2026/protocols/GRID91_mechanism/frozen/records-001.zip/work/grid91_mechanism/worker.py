"""Same historical controller, with explicit per-item environment and policy."""
from pathlib import Path
import argparse, json, os, sys
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/grid91_mechanism'
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[k]='1'
ap=argparse.ArgumentParser();ap.add_argument('--index',type=int,required=True)
a=ap.parse_args()
D=json.loads((OUT/'design.json').read_text(encoding='utf-8'))
item=D['execution_order'][a.index]
source=ROOT/'work/grid55/run.py'
code=source.read_text(encoding='utf-8').replace("OUT=ROOT/'outputs/grid55'","OUT=ROOT/'outputs/grid91_mechanism'")
marker='    old_init=ResidualControl.__init__;old_propose=ResidualControl.propose'
assert code.count(marker)==1
patch="""    import importlib.util
    ss=importlib.util.spec_from_file_location('grid91_adapter',ROOT/'work/grid91_mechanism/adapter.py')
    aa=importlib.util.module_from_spec(ss);ss.loader.exec_module(aa);aa.install(engine.Search,item)
    import common
    def mechanism_env():
        return common.grid2op.make(str(ROOT/item['environment']),test=True,backend=common.LightSimBackend(),reward_class=common.MaxRhoReward,other_rewards=common.operational_other_rewards())
    common.make_env=mechanism_env
"""
code=code.replace(marker,patch+marker)
sys.argv=[str(source),'--worker',str(a.index)]
exec(compile(code,str(source),'exec'),{'__file__':str(source),'__name__':'__main__'})
