"""Finite saved-feedback test of the single predeclared completion trigger."""
from pathlib import Path
from collections import defaultdict
import bisect,csv,hashlib,importlib.util,json,statistics

ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid93_trigger';SOURCES={}


def read(p):
    SOURCES[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    return json.loads(p.read_text(encoding='utf-8'))


def save(n,obj):(OUT/n).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def csvsave(n,rows):
    if rows:
        with (OUT/n).open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    design=read(W/'design.json');save('design.json',design)
    sp=importlib.util.spec_from_file_location('grid93',W/'policies.py');P=importlib.util.module_from_spec(sp);sp.loader.exec_module(P)
    for path in [W/'policies.py',Path(__file__),ROOT/'work/grid91_mechanism/policies.py']:
        SOURCES[path.relative_to(ROOT).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
    D=read(ROOT/'outputs/grid91_mechanism/design.json');subs=read(ROOT/'outputs/grid28/offline.json')['public_subids']
    full,actual,needed=[],[],[];checks=dict(score=0,hidden_suffix=0,baseline=0)
    for ref in D['references']:
        changed=0;actual_gate_queries=0;actual_original_queries=0;calls=0
        for kind in ['full','frame']:
            for p in sorted((ROOT/ref[kind]).glob('call[0-9][0-9][0-9].json')):
                c=read(p);truth={r['pool_id']:r for r in c['outcomes']};aliases={int(k):v for k,v in c['aliases'].items()}
                def replay(policy,truth=truth):
                    seen=[]
                    def observe(i,phase):
                        assert i not in seen and i in truth;seen.append(i);return dict(truth[i],phase=phase)
                    z=P.run(c['order'],observe,policy,subs,aliases)
                    assert seen==[r['pool_id'] for r in z['outcomes']]
                    return z
                old=replay('FRAME_GUARD');new=replay('SUPPORT_GATE')
                old_best=next((r for r in old['outcomes'] if r['pool_id']==old['chosen_pool_id']),None)
                new_best=next((r for r in new['outcomes'] if r['pool_id']==new['chosen_pool_id']),None)
                old_reward=None if old_best is None else P.BASE.key(old_best)[0]
                new_reward=None if new_best is None else P.BASE.key(new_best)[0]
                info=new['trigger_support']
                prefix=[r for r in old['outcomes'] if r['phase']!='local_completion']
                if info:
                    station=int(subs[new['pre_extra_choice']]);target={v for k,v in aliases.items() if subs[k]==station}
                    aa=[P.BASE.key(r)[0] for r in prefix if r['strict_admissible'] and r['pool_id']!=new['pre_extra_choice'] and r['pool_id'] in target]
                    bb=sorted(P.BASE.key(r)[0] for r in prefix if r['strict_admissible'] and r['pool_id'] not in target)
                    # Independently compute pairwise wins/ties by sorted searches.
                    numerator=sum(2*bisect.bisect_left(bb,x)+bisect.bisect_right(bb,x)-bisect.bisect_left(bb,x) for x in aa)
                    denom=len(aa)*len(bb)
                    assert info['veto']==bool(denom and numerator<denom)
                    assert info['score']==(numerator/(2*denom) if denom else None)
                    checks['score']+=1
                    # Change every hidden suffix outcome; the decision must be unchanged.
                    seen={r['pool_id'] for r in prefix}
                    perturbed={i:(r if i in seen else dict(r,reward=-999.,rho=999.,strict_admissible=False)) for i,r in truth.items()}
                    altered=replay('SUPPORT_GATE',perturbed)
                    assert altered['trigger_support']==info;checks['hidden_suffix']+=1
                row=dict(cohort=ref['cohort'],week=ref['week'],call=p.stem,step=c['step'],source=p.relative_to(ROOT).as_posix(),
                         completion_budget=old['completion_budget'],veto=bool(info and info['veto']),score=None if info is None else info['score'],
                         local_observed=None if info is None else info['local_observed'],other_observed=None if info is None else info['other_observed'],
                         original_queries=old['public_queries'],gated_queries=new['public_queries'],saved_queries=old['public_queries']-new['public_queries'],
                         original_choice=old['chosen_pool_id'],gated_choice=new['chosen_pool_id'],choice_changed=old['chosen_pool_id']!=new['chosen_pool_id'],
                         reward_lost=None if old_reward is None else old_reward-new_reward,
                         local_gain=None if old_reward is None or old['pre_extra_choice'] is None else old_reward-P.BASE.key(truth[old['pre_extra_choice']])[0])
                assert row['saved_queries']>=0 and (row['reward_lost'] or 0)>=0
                if kind=='full':full.append(row)
                else:
                    assert c['chosen_pool_id']==old['chosen_pool_id'] and c['public_queries']==old['public_queries'];checks['baseline']+=1
                    actual.append(row);changed+=row['choice_changed'];calls+=1
                    actual_original_queries+=row['original_queries'];actual_gate_queries+=row['gated_queries']
        needed.append(dict(**ref,calls=calls,changed_search_choices=changed,
                           needs_closed_loop=bool(changed),frame_queries=actual_original_queries,
                           gate_queries_on_frame_states=actual_gate_queries,
                           note='Same-trajectory savings valid only when all search choices unchanged; otherwise these are teacher-forced diagnostics, not closed-loop totals'))
    assert len(full)==185 and len(needed)==25
    summaries=[]
    for kind,rows in [('FULL_states',full),('FRAME_states',actual)]:
        for group in ['old13','G1','G2']:
            rr=[r for r in rows if r['cohort']==group];tr=[r for r in rr if r['completion_budget']];veto=[r for r in tr if r['veto']]
            summaries.append(dict(states=kind,cohort=group,calls=len(rr),original_completion_calls=len(tr),veto_calls=len(veto),
                                  removed_improvements=sum((r['local_gain'] or 0)>1e-6 for r in veto),
                                  preserved_improvements=sum((r['local_gain'] or 0)>1e-6 for r in tr if not r['veto']),
                                  reward_lost_sum=sum(r['reward_lost'] or 0 for r in rr),
                                  original_queries=sum(r['original_queries'] for r in rr),gated_queries=sum(r['gated_queries'] for r in rr),
                                  saved_queries=sum(r['saved_queries'] for r in rr),changed_choices=sum(r['choice_changed'] for r in rr)))
    save('screen_summary.json',summaries);save('scenario_plan.json',needed)
    csvsave('full_state_screen.csv',full);csvsave('actual_frame_state_screen.csv',actual)
    save('screen_source_hashes.json',SOURCES)
    save('screen_verification.json',dict(passed=True,checks=checks,full_states=185,actual_frame_calls=len(actual),
                                        replay_scenarios=sum(x['needs_closed_loop'] for x in needed),
                                        new_simulations=0,new_training=0))
    print(json.dumps(dict(summary=summaries,replay_scenarios=[x['week'] for x in needed if x['needs_closed_loop']],checks=checks),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
