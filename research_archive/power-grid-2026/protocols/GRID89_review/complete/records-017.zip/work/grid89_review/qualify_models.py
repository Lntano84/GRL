"""All ten fixed models: offline/online legal-feedback and cache equivalence."""
from pathlib import Path
import hashlib,importlib.util,json,sys
import numpy as np,torch
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/grid89_review'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def main():
 torch.set_num_threads(1)
 s=importlib.util.spec_from_file_location('review_meta_qualification',ROOT/'work/grid77/metacontrol.py');M=importlib.util.module_from_spec(s);s.loader.exec_module(M)
 records=read(ROOT/'outputs/grid77/records.json');subs=read(ROOT/'outputs/grid77/data_receipts.json')['subids'];checks=0;hidden=0;models=[]
 for r in records:
  r['aliases']={int(k):int(v) for k,v in r['aliases'].items()};r['subids']=subs;r['context']={k:np.asarray(v,dtype=np.int64 if k=='edges' else np.float32) for k,v in r['context'].items()};r['prefixes']=M.prefixes(r)
 for item in read(OUT/'meta/design.json')['methods']:
  if not item.get('meta_model'):continue
  path=ROOT/item['meta_model'];model=M.QModel();model.load_state_dict(torch.load(path,map_location='cpu',weights_only=True));model.eval();assert all(torch.isfinite(v).all() for v in model.parameters())
  for r in records:
   truth={v['pool_id']:v for v in r['rows']};seen=[]
   def reveal(i,phase):assert i not in seen;seen.append(i);return dict(truth[i],phase=phase)
   expected=M.replay(model,r);got=M.run(r['order'],reveal,0,subs,r['aliases'],r['rho_limit'],r['context'],model=model)
   assert got['chosen_pool_id']==expected['chosen'] and got['public_queries']==expected['end'] and len(seen)==got['public_queries'];checks+=1
   purchased=set(seen);seen2=[]
   def perturb(i,phase):
    assert i not in seen2;seen2.append(i);x=dict(truth[i],phase=phase)
    if i not in purchased:x.update(reward=100.,rho=.001,strict_admissible=True)
    return x
   other=M.run(r['order'],perturb,0,subs,r['aliases'],r['rho_limit'],r['context'],model=model)
   assert seen2==seen and other['chosen_pool_id']==got['chosen_pool_id'];hidden+=1
  models.append(dict(method=item['method'],path=item['meta_model'],sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 result=dict(passed=True,models=models,online_offline_checks=checks,hidden_suffix_checks=hidden,records=len(records),new_simulations=0,training_and_calibration_used_for_qualification_only=True)
 (OUT/'models_qualification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='models'}),flush=True)
if __name__=='__main__':main()
