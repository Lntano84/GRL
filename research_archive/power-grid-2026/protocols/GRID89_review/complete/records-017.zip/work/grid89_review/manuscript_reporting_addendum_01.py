"""Pure reporting edit after audit; frozen benchmark code and results are preserved."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import shutil
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/grid89_review'
DOC = OUT / 'manuscript_v2'
HISTORY = OUT / 'manuscript_revision01'
PY = 'C:/Users/windows/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
SKILL = Path('C:/Users/windows/.codex/plugins/cache/openai-primary-runtime/documents/26.1015.12040/skills/documents')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not (HISTORY / 'receipt.json').exists(), 'Reporting edit already completed'
    HISTORY.mkdir(exist_ok=True)
    old = HISTORY / 'original'
    old.mkdir(exist_ok=True)
    for name in ['全文待排版.md', 'FRAME_ICAPS2027_中文合稿_V2.md',
                 'FRAME_ICAPS2027_中文合稿_V2.docx', '合稿来源与修改说明.json', 'render_complete.json']:
        assert not (old / name).exists(), name
        shutil.copy2(DOC / name, old / name)
    frozen = {name: sha(OUT / name) for name in ['review.json', 'decision.json', 'code_freeze.json', 'data_freeze.json']}
    R = json.loads((OUT / 'review.json').read_text(encoding='utf-8'))
    D = json.loads((OUT / 'decision.json').read_text(encoding='utf-8'))
    rows = R['groups']
    a = {r['date']: r for r in rows if r['phase'] == 'sealed' and r['method'] == 'FRAME_GUARD'}
    b = {r['date']: r for r in rows if r['phase'] == 'sealed' and r['method'] == 'FULL'}
    relative = lambda key: statistics.mean(1 - a[d][key] / b[d][key] for d in a)
    c = next(c for c in D['comparisons'] if c['phase'] == 'sealed' and c['method'] == 'FRAME_GUARD' and c['baseline'] == 'FULL')
    bands = c['date_cluster_controller95']
    cvs = [r['controller_sd'] / r['controller_s'] for r in a.values()]
    reps = '、'.join(f'{v * 100:.2f}%' for v in c['repeat_time_reductions'])
    parts = [
        f"新增六个场景各采用三次轮换计时。FRAME相对FULL的完整控制时间宏平均减少{relative('controller_s') * 100:.2f}%，三次重复分别减少{reps}，六个日期均更快。按日期重采样得到的描述性95%区间为[{bands[0] * 100:.2f}%，{bands[1] * 100:.2f}%]。各日期FRAME控制总时间的重复标准差与均值之比为{min(cvs) * 100:.2f}%～{max(cvs) * 100:.2f}%，具体均值、范围和标准差列入逐日期记录。",
        f"延迟分析区分全部控制步骤与触发拓扑搜索的步骤。逐日期先对三次重复的分位数取平均，再计算相对FULL的变化，搜索步骤P95和P99延迟宏平均分别降低{relative('search_p95') * 100:.2f}%和{relative('search_p99') * 100:.2f}%。全部控制步骤的P95则增加{-relative('all_p95') * 100:.2f}%，P99降低{relative('all_p99') * 100:.2f}%。这些结果表明，加速主要体现在拓扑搜索发生时；连续优化等其他操作仍然影响整个控制器的延迟分布。",
    ]
    means = {method: {key: statistics.mean(r[key] for r in rows if r['phase'] == 'sealed' and r['method'] == method)
                      for key in ['controller_s', 'forecast_s', 'optimizer_s']}
             for method in ['FULL', 'FRAME_GUARD']}
    f, g = means['FULL'], means['FRAME_GUARD']
    parts.append(f"互斥耗时分解显示，按日期计算的控制总时间算术均值从{f['controller_s']:.2f}秒降至{g['controller_s']:.2f}秒，其中预测仿真从{f['forecast_s']:.2f}秒降至{g['forecast_s']:.2f}秒；连续优化分别为{f['optimizer_s']:.2f}秒和{g['optimizer_s']:.2f}秒。候选查询压缩因此转化为实际提速，但整体降幅小于查询降幅。原十三日期对固定512的全部步骤P95降低0.42%，属于另一批比较。")
    text = (DOC / '全文待排版.md').read_text(encoding='utf-8')
    start = text.index('## 3.9 搜索步骤延迟与计算波动')
    end = text.index('# 4 结论', start)
    text = text[:start] + '## 3.9 搜索步骤延迟与计算波动\n\n' + '\n\n'.join(parts) + '\n\n' + text[end:]
    text = text.replace('它用于比较电网任务中的两种搜索控制方式：学习元策略与固定反馈规则。', '', 1)
    for key, label in [('p', '前缀长度'), ('h', '批次大小'), ('qmin', '最低核查量'), ('patience', '连续停滞批数'), ('safe', '分支负载率阈值')]:
        start = text.index(label + '分别设置为', text.index('## 3.6 '))
        end = text.index('。', start) + 1
        values = json.loads((OUT / 'design.json').read_text(encoding='utf-8'))['parameters']['single_axis'][key]
        info = []
        for value in values:
            name = f'FRAME_{key}_{str(value).replace(".", "p")}'
            group = [r for r in rows if r['phase'] == 'parameters' and r['method'] == name]
            info.append((sum(r['quality_pass'] for r in group), sum(r['queries'] for r in group)))
        new = f'{label}取{values[0]}和{values[1]}时，分别有{info[0][0]}/4和{info[1][0]}/4个场景达到质量标准，查询总数分别为{info[0][1]}和{info[1][1]}。'
        text = text[:start] + new + text[end:]
    (DOC / '全文待排版.md').write_text(text, encoding='utf-8')
    subprocess.run([PY, '-X', 'utf8', str(Path(__file__).with_name('build_docx.py'))], cwd=ROOT, check=True)
    env = dict(os.environ)
    env['TEMP'] = env['TMP'] = str(ROOT / 'tmp')
    env['PYTHONIOENCODING'] = 'utf-8'
    env['PATH'] = str(ROOT / 'work/grid_cn_draft/render_dependency/extracted/program') + ';C:/Users/windows/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin;' + env['PATH']
    qa = DOC / 'qa_latency_v2'
    subprocess.run([PY, '-X', 'utf8', str(SKILL / 'render_docx.py'), str(DOC / 'FRAME_ICAPS2027_中文合稿_V2.docx'), '--output_dir', str(qa), '--emit_pdf', '--dpi', '105'], cwd=ROOT, env=env, check=True)
    receipt = json.loads((DOC / '合稿来源与修改说明.json').read_text(encoding='utf-8'))
    receipt.update(new_validation_experiments_added=True, old_results_changed=False,
                   additional_sources={p: sha(OUT / p) for p in ['decision.json', 'review.json', 'design.json']},
                   visual_review_pending=True, reporting_addendum='outputs/grid89_review/manuscript_revision01/receipt.json')
    (DOC / '合稿来源与修改说明.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    pages = len(list(qa.glob('page-*.png')))
    (DOC / 'render_complete.json').write_text(json.dumps(dict(rendered=True, visual_check_pending=True, pages=pages, qa_directory=qa.relative_to(ROOT).as_posix()), indent=2), encoding='utf-8')
    assert frozen == {name: sha(OUT / name) for name in frozen}
    record = dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(), purpose='Add already audited timing and latency values to prose; smooth parameter-result wording.', benchmark_and_audit_hashes_unchanged=frozen,
                  prior_docx_sha256=sha(old / 'FRAME_ICAPS2027_中文合稿_V2.docx'), final_docx_sha256=sha(DOC / 'FRAME_ICAPS2027_中文合稿_V2.docx'),
                  new_replays=0, new_fits=0, pages=pages, qa_directory=qa.relative_to(ROOT).as_posix())
    (HISTORY / 'receipt.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(record, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
