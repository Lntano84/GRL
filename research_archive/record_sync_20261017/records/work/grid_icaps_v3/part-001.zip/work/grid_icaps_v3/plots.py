from pathlib import Path
import csv,json,statistics,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path('D:/Codex/GRL研究');OUT=ROOT/'outputs/grid_icaps_v3/figures'
plt.rcParams.update({'font.family':'Arial','font.size':8.7,'axes.titlesize':9.5,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
C={'FULL':'#8D99A4','FIRST_SAFE_BEST':'#427894','NO_LOCAL':'#B18451','FRAME':'#56877E'}
short={'FULL':'FULL','FIRST_SAFE_BEST':'FIRST','NO_LOCAL':'NO_LOCAL','FRAME':'FRAME'}
sets={}
for scope,stage in [('Development','grid61'),('Confirmation','grid62')]:
 path=ROOT/'outputs'/stage/'per_run.csv';rows=list(csv.DictReader(path.open(encoding='utf-8-sig')))
 for r in rows:
  for k in ['controller_s','n1_queries','cost','steps']:r[k]=float(r[k])
  r['complete']=r['complete']=='True';r['repeat']=int(r['repeat'])
 sets[scope]=rows
def aggregate(rows,m):
 vals=[]
 for week in sorted({r['week'] for r in rows}):
  f=[r for r in rows if r['method']=='FULL' and r['week']==week];a=[r for r in rows if r['method']==m and r['week']==week]
  ft=statistics.mean(r['controller_s'] for r in f);at=statistics.mean(r['controller_s'] for r in a)
  fq=statistics.mean(r['n1_queries'] for r in f);aq=statistics.mean(r['n1_queries'] for r in a)
  fc=statistics.mean(r['cost'] for r in f);ac=statistics.mean(r['cost'] for r in a)
  vals.append({'week':week,'time_savings':100*(1-at/ft),'query_savings':100*(1-aq/fq) if fq else None,'cost_change':100*(ac/fc-1) if all(r['complete'] for r in f+a) else None})
 return {'time':statistics.mean(v['time_savings'] for v in vals),'queries':statistics.mean(v['query_savings'] for v in vals if v['query_savings'] is not None),'cost':max(v['cost_change'] for v in vals if v['cost_change'] is not None),'dates':vals}
agg={s:{m:aggregate(rows,m) for m in C} for s,rows in sets.items()}
assert abs(agg['Development']['FRAME']['queries']-69.37)<.005
assert abs(agg['Confirmation']['FRAME']['time']-6.09)<.005
def save(fig,name):
 for ext in ['pdf','svg','png']:fig.savefig(OUT/f'{name}.{ext}',dpi=300,facecolor='white')
 plt.close(fig)
def results():
 fig,axs=plt.subplots(1,3,figsize=(7.2,2.75));fig.subplots_adjust(left=.075,right=.985,bottom=.3,top=.84,wspace=.43)
 methods=['FIRST_SAFE_BEST','NO_LOCAL','FRAME']
 ax=axs[0]
 for j,s in enumerate(sets):
  for i,m in enumerate(methods):
   v=agg[s][m]['queries'];ax.bar(i+(j-.5)*.33,v,.3,color=C[m],hatch='' if j==0 else '//',alpha=1 if j==0 else .65)
 ax.set(ylim=(0,100),xticks=range(3),xticklabels=['FIRST','NO_LOCAL','FRAME'],ylabel='Query reduction (%)')
 ax.set_title('(a) Fewer candidate evaluations',weight='bold',fontsize=9)
 ax.text(2,97,'69.37 / 83.54',ha='center',fontsize=8,color=C['FRAME'])
 ax=axs[1];weeks=sorted({r['week'] for r in sets['Confirmation']});labels=['Apr. 9','May 14','Nov. 19']
 for i,w in enumerate(weeks):
  for j,m in enumerate(['FULL','FRAME']):
   vs=[r['controller_s'] for r in sets['Confirmation'] if r['week']==w and r['method']==m];x=i+(j-.5)*.23
   ax.vlines(x,min(vs),max(vs),color=C[m],lw=1.2);ax.scatter([x]*2,vs,s=18,marker='o' if m=='FULL' else 'D',facecolor='white',edgecolor=C[m],lw=1,zorder=3)
   ax.plot([x-.055,x+.055],[statistics.mean(vs)]*2,color=C[m],lw=2)
 ax.set(ylim=(0,None),xticks=range(3),xticklabels=labels,ylabel='Controller time (s)')
 ax.set_title('(b) Actual timing repetitions',weight='bold',fontsize=9)
 ax=axs[2]
 for j,s in enumerate(sets):
  for i,m in enumerate(methods):ax.bar(i+(j-.5)*.33,agg[s][m]['cost'],.3,color=C[m],hatch='' if j==0 else '//',alpha=1 if j==0 else .65)
 ax.axhline(0,color='#61717F',lw=.7);ax.axhline(.5,color='#61717F',lw=.9,ls='--');ax.text(-.45,.7,'Quality limit',fontsize=8.4,color='#61717F')
 ax.set(xticks=range(3),xticklabels=['FIRST','NO_LOCAL','FRAME'],ylabel='Largest full-week cost change (%)',ylim=(-.6,5.8))
 ax.set_title('(c) Full-week quality',weight='bold',fontsize=9)
 ax.text(2,1.15,'0.372 / 0.014',ha='center',fontsize=8,color=C['FRAME'])
 for ax in axs:ax.set_axisbelow(True);ax.grid(axis='y',color='#E6EBEF',lw=.55);ax.tick_params(axis='x',labelsize=8.4)
 from matplotlib.patches import Patch
 from matplotlib.lines import Line2D
 handles=[Patch(fc=C['FRAME'],label='Development'),Patch(fc=C['FRAME'],alpha=.65,hatch='//',label='Confirmation'),Line2D([0],[0],marker='o',mfc='white',color=C['FULL'],label='FULL timing'),Line2D([0],[0],marker='D',mfc='white',color=C['FRAME'],label='FRAME timing')]
 fig.legend(handles=handles,loc='lower center',ncol=4,bbox_to_anchor=(.52,.11),frameon=False,fontsize=8.4)
 fig.text(.5,.025,'FIRST = FIRST_SAFE_BEST; query means use search-active dates.\nTiming shows both repetitions; ticks mark their mean.',ha='center',fontsize=8.4)
 save(fig,'results')
def case():
 fig,axs=plt.subplots(1,2,figsize=(7.2,2.65));fig.subplots_adjust(left=.14,right=.98,bottom=.26,top=.82,wspace=.4)
 ax=axs[0];methods=['NO_LOCAL','FRAME','FULL'];queries=[256,454,909];actions=[26,309,309]
 bars=ax.barh(range(3),queries,color=[C[m] for m in methods],height=.55);ax.invert_yaxis();ax.set_yticks(range(3),methods);ax.set_xlim(0,1070);ax.set_xlabel('Predictive simulation queries')
 ax.set_title('(a) Step 1733: local recovery',weight='bold')
 for i,(q,a) in enumerate(zip(queries,actions)):ax.text(q+15,i,f'{q} → action {a}',va='center',fontsize=8.4)
 ax=axs[1];vs=[agg['Development']['NO_LOCAL']['cost'],agg['Development']['FRAME']['cost']]
 assert abs(vs[0]-4.810)<.005 and abs(vs[1]-.372)<.0005
 ax.bar(range(2),vs,color=[C['NO_LOCAL'],C['FRAME']],width=.6);ax.set_xticks(range(2),['NO_LOCAL','FRAME']);ax.set_ylim(0,5.7);ax.set_ylabel('Cost change relative to FULL (%)');ax.set_title('(b) March full-week cost',weight='bold')
 ax.axhline(.5,color='#61717F',ls='--',lw=.9)
 for i,v in enumerate(vs):ax.text(i,v+.18,f'{v:.3f}%',ha='center',fontsize=9)
 for ax in axs:ax.set_axisbelow(True);ax.grid(axis='x' if ax==axs[0] else 'y',color='#E6EBEF',lw=.6)
 fig.text(.5,.05,'198 additional local queries recover action 309; the two panels describe single-step and full-week outcomes.',ha='center',fontsize=8.4)
 save(fig,'completion_case')
if __name__=='__main__':
 results();case();(OUT/'plot_data.json').write_text(json.dumps(agg,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Empirical figures generated directly from all GRID61/62 per-run CSV rows.')
