"""Serial replay only for six entries whose search choice changes."""
from pathlib import Path
import json,os,subprocess,sys,time,traceback,hashlib
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid93_trigger'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))


def save(n,x):
    p=OUT/n;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(t,p)


def main():
    assert read(OUT/'preflight.json')['passed']
    for rel,h in read(OUT/'code_freeze.json').items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h,rel
    D=read(OUT/'design.json');start=time.perf_counter()
    assert not (OUT/'finished.json').exists()
    summaries=read(OUT/'manifest.json')['summaries'] if (OUT/'manifest.json').exists() else []
    existing={s['week'] for s in summaries}
    for index,item in enumerate(D['execution_order']):
        if item['week'] in existing:continue
        assert time.perf_counter()-start<D['caps']['wall_s']
        folder=OUT/'runs'/f"r0__{item['week']}__SUPPORT_GATE"
        assert not folder.exists(),'Existing partial or unregistered output: inspect, never overwrite'
        save('pipeline_state.json',dict(phase='benchmark',pid=os.getpid(),completed=len(summaries),planned=len(D['execution_order']),item=item))
        with (OUT/f'worker_{index:02d}.log').open('x',encoding='utf-8') as f:
            proc=subprocess.Popen([sys.executable,'-u',str(W/'worker.py'),'--index',str(index)],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            save('active_worker.json',dict(pid=proc.pid,parent=os.getpid(),index=index))
            try:code=proc.wait(timeout=D['caps']['episode_s']+120)
            except subprocess.TimeoutExpired:
                subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=f,stderr=subprocess.STDOUT);proc.wait();raise
        assert code==0,(index,code)
        s=read(folder/'summary.json');assert s==read(OUT/f'worker_result_{index:02d}.json')
        summaries.append(s);save('manifest.json',dict(summaries=summaries,planned=len(D['execution_order'])))
        assert sum(x['public_forecasts'] for x in summaries)<=D['caps']['public_forecasts']
        print(json.dumps(dict(completed=len(summaries),planned=len(D['execution_order']),week=s['week'],cost=s['cost'],queries=s['n1_forecasts'])),flush=True)
    save('finished.json',dict(passed_engineering=True,summaries=summaries,runs=len(summaries)))
    save('pipeline_state.json',dict(phase='replays_finished_awaiting_audit',completed=len(summaries),planned=len(D['execution_order'])))


if __name__=='__main__':
    try:main()
    except BaseException:
        save('pipeline_error.json',dict(traceback=traceback.format_exc()));raise
