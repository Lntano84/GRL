"""Serial audit-and-revision continuation; never train or expose holdout data.

Wait for GRID22's successful sentinel. Stop immediately on a failed audit or
preflight; leave every log and result for diagnosis. GRID23 is a previously
specified development revision, using the same saved model weights.
"""
import ast
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/grid_pipeline/continue22_23"
OUT.mkdir(parents=True, exist_ok=False)
started = time.perf_counter()
history = []


def record(status, **kwargs):
    tmp = OUT / "state.tmp"
    tmp.write_text(json.dumps({"status": status, "history": history,
        "wall_s": time.perf_counter()-started, **kwargs}, indent=2), encoding="utf-8")
    os.replace(tmp, OUT / "state.json")


def invoke(source, log):
    assert (ROOT / source).is_file()
    record("RUNNING", active=source, new_fits=0)
    tick = time.perf_counter()
    with (ROOT / log).open("w", encoding="utf-8") as f:
        result = subprocess.run([sys.executable, str(ROOT / source)], cwd=ROOT,
            stdout=f, stderr=subprocess.STDOUT, env=os.environ.copy())
    entry = {"source": source, "source_sha256": hashlib.sha256((ROOT / source).read_bytes()).hexdigest(),
        "log": log, "exit_code": result.returncode, "wall_s": time.perf_counter()-tick}
    history.append(entry)
    record("RUNNING", last=entry, new_fits=0)
    assert result.returncode == 0, entry


try:
    record("WAIT_GRID22", new_fits=0)
    waiting = time.perf_counter()
    while not (ROOT / "outputs/grid22/finished.json").exists():
        assert time.perf_counter()-waiting < 7200, "No successful GRID22 sentinel within continuation window."
        time.sleep(5)
    invoke("work/grid22/audit.py", "outputs/grid22/audit.log")
    assert json.loads((ROOT / "outputs/grid22/audit.json").read_text())["passed"]
    invoke("work/grid22/review_completed.py", "outputs/grid22/progress_review.log")
    invoke("work/grid22/tie_review.py", "outputs/grid22/tie_review.log")
    invoke("work/grid22/closeout.py", "outputs/grid22/closeout.log")
    invoke("work/grid23/prepare.py", "outputs/grid_pipeline/continue22_23/prepare23.log")
    for name in ["canonical_adapter.py", "run.py", "audit.py", "closeout.py", "preflight.py"]:
        ast.parse((ROOT / "work/grid23" / name).read_text(encoding="utf-8"))
    invoke("work/grid23/preflight.py", "outputs/grid23/preflight.log")
    invoke("work/grid23/tie_preflight.py", "outputs/grid23/tie_preflight.log")
    invoke("work/grid23/freeze.py", "outputs/grid23/freeze.log")
    invoke("work/grid23/run.py", "outputs/grid23/run.log")
    invoke("work/grid23/audit.py", "outputs/grid23/audit.log")
    invoke("work/grid23/closeout.py", "outputs/grid23/closeout.log")
    record("COMPLETE", new_fits=0, new_RL=False, final_holdout_opened=False)
    print(json.dumps({"complete": True, "stages": [22, 23], "new_fits": 0}), flush=True)
except Exception:
    record("STOPPED_FOR_DIAGNOSIS", traceback=traceback.format_exc(), new_fits=0)
    raise
