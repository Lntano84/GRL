from pathlib import Path
import json,hashlib,re
from docx import Document
ROOT=Path('D:/Codex/GRL研究');OUT=ROOT/'outputs/grid_icaps_cn_v4'
guides={
'Abstract':'https://dy8q0bnq8y.feishu.cn/wiki/Tz2pwvxTyiBK0zkCVszcZmJ3nwd',
'Introduction':'https://dy8q0bnq8y.feishu.cn/wiki/ULATwBu2MiLqqRkXxV6c2S7AnPd',
'Experiments':'https://dy8q0bnq8y.feishu.cn/wiki/KHgSw2MkrikxlskGe5qclkdbn2c',
'Related Works':'https://dy8q0bnq8y.feishu.cn/wiki/CLSAwWm6qifjwQkTd82czgMNnYf',
'Reference':'https://dy8q0bnq8y.feishu.cn/wiki/A4q2wSnmRi91rykHke1cQIhnnAh'}
checks=[
('Abstract','基本思路','把摘要写成贡献说明，压缩范围描述','开头保留任务、结构问题、两阶段方法、量化证据和结论六句；删除权衡表述。','摘要'),
('Abstract','任务背景','用短句直接交代任务','首句明确预测仿真和逐候选计算开销。','摘要第1句'),
('Abstract','科学问题','指出具体结构原因，避免笼统困难','同站配置在全局排名中分散，停止可能遗漏相关配置。','摘要第2句'),
('Abstract','方法思想','凝练方法并解释问题对应关系','全局扩展后集中补查最佳动作所在变电站。','摘要第3句'),
('Abstract','量化结果','明确任务范围、对手及主要指标','一个公开电网、七日期、56回放；FULL参照；查询、计时和成本分别报告。','摘要第4至5句'),
('Abstract','逻辑闭环','结论回应问题而非只报泛化提升','末句回到保持质量、减少查询及降低控制开销。','摘要第6句'),
('Abstract','两个优秀案例','学习问题到方法再到量化结论的句子组织','已阅读两个案例正文和放大图；只借鉴组织方式，未挪用其结果或理论主张。','本次浏览记录及摘要'),
('Introduction','总逻辑','领域到已有工作到问题再到本文工作','重写为背景、相关进展、结构错位、方法、实验证据和三项贡献。','1节'),
('Introduction','建立领域','先交代应用任务与意义','连接变化、持续控制、仿真开销及效率目标在首段交代。','1节第1段'),
('Introduction','回顾研究','选择直接相关路线，不写完整综述','LJN混合控制与SoftGNN及图表示研究用于引出候选评估组织问题。','1节第2段'),
('Introduction','具体问题','写清哪种操作造成哪种缺口','交错排序、连续未改善与同站未查配置的关系被明确展开；图1配合解释。','1节第3段及图1'),
('Introduction','本文工作','直接说明目标和解决方式','两阶段、别名归属及控制器接口在一个方法段中交代。','1节第4段'),
('Introduction','贡献','两至四条，具体且可核验','三条分别对应搜索构造、别名集合与重复查询性质、闭环证据。','1节贡献列表'),
('Introduction','主题句','每段一个观点，首句说明段落功能','逐段检查背景、进展、问题、方法和证据的主题句。','1节全部段落'),
('Introduction','段落建议与模板','采用骨架组织，结构导读可选','使用五个主体段落加贡献列表；省去重复章节导读。','1节'),
('Experiments','结构服务贡献','选择必要实验类型','设置、指标、主结果、消融、动作案例、时间分析均有明确研究问题。','3.1至3.6'),
('Experiments','数据和基准','明确实验对象及数据划分','公开环境、动作库、四开发日期和三冻结日期的完整ID均列出。','3.1'),
('Experiments','比较方法','明确每个对手及公平条件','四策略定义表；共享排序、控制底座、仿真接口和缓存；逐候选策略按同底座实现。','表1及3.1'),
('Experiments','指标','明确质量与计算的计量','成本、存活、查询和控制时间分开定义，计量边界和比例符号明确。','3.2'),
('Experiments','实现与参数','可理解的运行细节','128初始、64批量、256最少查询、两批停滞、0.9阈值及软件硬件说明齐全。','3.1'),
('Experiments','训练推理设置','说明当前模块是否训练及排序来源','固定频次先验，本轮不拟合排序器；模型训练要求不适用于这份主实验。','3.1'),
('Experiments','重复种子统计','报告真实重复层级','补入环境种子0；每日期两次计时；先日期内平均再按日期等权。','3.1及3.2'),
('Experiments','主结果','引导读者看关键发现及意义','先回答质量通过，再看查询与时间；把开发和确认结果分段解释。','3.3及图3表2'),
('Experiments','没有提升的情况','保留较差或竞争结果','保留FIRST开发失效、确认竞争、5月负时间减少；不改主评价集合。','3.3及3.6'),
('Experiments','消融围绕动机','说明去掉什么且只改变什么','NO_LOCAL仅关闭同站补全；质量改善与查询增加并列呈现。','3.4'),
('Experiments','分析加深理解','说明何时更有作用而非重复主表','3月大幅改善、4月微小改善、11月未触发分别解释。','3.4'),
('Experiments','案例可视化','让读者理解具体行为差异','动作26到309，256加198查询与FULL909查询对照；单步与整周分开。','3.5图4'),
('Experiments','泛化及稳健性','根据贡献选用，不为凑数量','冻结日期作为时间上的补充验证；不添加未完成的跨网或参数敏感性结果。','3.3及6节'),
('Experiments','效率成本','报告实际计算而非只报代理量','完整控制计时与查询数同时报告，两次计时差异展示，共有缓存不单独归因。','3.6'),
('Experiments','邀请读者查看图表','正文中明确指出图表作用','图1解释问题、图2解释方法、图3分开三个指标、图4解释动作案例。','全文图表引用'),
('Experiments','关键结果与评价性语言','解释数字意味着什么','查询压缩、质量缺口修复、控制开销下降分别给出证据对应。','3.3至3.6'),
('Experiments','问题和异常','报告异常并使用合适强度的结论','共同提前结束和计时波动简洁说明；不把弱化词写成虚构的显著性或等价结论。','3.6及6节'),
('Related Works','研究脉络','分类概括而非逐篇堆砌','改为混合控制与排序、规划计算分配、结构配置比较三条路线。','5.1至5.3'),
('Related Works','与引言区别','定位技术关系，避免重复动机','引言引出结构问题，相关工作说明模块互补及计算对象。','1节与5节'),
('Related Works','组织结构','按研究方向或技术路线组织','每小节先概括路线，列代表工作，再解释与FRAME的关系。','5节'),
('Related Works','客观比较','不证明别人都不行','认可混合控制和排序的已有功能；突出本文在评估集合组织上的作用。','5.1'),
('Related Works','具体差异','写出共同点和区别','元推理决定继续计算或执行；FRAME利用动作归属确定停止后进一步查询的集合。','5.2'),
('Related Works','贡献关系','说明延续或互补而非一律超越','与控制和排序为互补；结构配置比较是具体实例化。','5.1及5.3'),
('Related Works','图表建议','仅在客观维度需要时使用','本轮三路线用短段落即可说明；不造本文有他人无的特征表。','5节'),
('Reference','逐条人工整理','来源条目还需手工校正','七条均核对作者、标题、类型、年份、出版或版本信息；附来源核对记录。','参考文献及下方记录'),
('Reference','引用键','作者年份关键词统一','配套BibTeX使用统一键，Grid2Op用机构名及访问年份。','references_checked.bib'),
('Reference','条目类型','会议期刊软件预印本分清','四会议论文为inproceedings，两软件和一预印本为misc；不编造刊物。','references_checked.bib'),
('Reference','字段整理','删除无关字段，保留必要项','去除publisher与重复会议信息；论文DOI、软件链接及访问日期保留用于追溯。','references_checked.bib'),
('Reference','标题大小写','保护名称与缩写并保持一致','标题用统一保护；英文文献标题保留原名，读稿不翻译论文题名。','references_checked.bib及参考文献'),
('Reference','作者','全作者格式统一','七条列全部作者，补回Milli文献Griffiths中间字母L。','参考文献'),
('Reference','会议期刊名称','统一同会议写法和届数','AAAI31与38均采用Proceedings of the序数Conference写法，ICAPS使用第32届全称。','参考文献5至7'),
('Reference','卷期页码','核实应有的页码且不编造','补Milli4422至4428；保留SoftGNN129至146、ICAPS556至564、Budd20053至20060。软件和arXiv不造页码。','参考文献'),
('Reference','去重及引用一致','避免重复版本与未引用条目','de Jong改为同一作品的v3，旧v1不另列；正文引用与七条文献一一对应。','文献4及全文引用'),
('Reference','投稿前自检','标题作者会刊字段大小写和重复检查','完成本次中文读稿一致性检查，投稿模板排版待中文确认后进行。','本轮范围')
]
lines=['# 中文全文逐节审核与修改说明\n','本次按用户要求重新打开五份飞书指南，顺序阅读全部正文和小节。Abstract两个案例的图片也逐一放大阅读。各指南中的句式示例用于理解段落功能，未机械套用英文句式。Methods及四幅配图沿用V3；本次仅改中文全文，不生成英语投稿版，不新增实验。\n','## 指南来源\n']
lines += [f'- [{k}]({v})' for k,v in guides.items()]
lines += ['\n## 逐项审核\n','“落实”指当前写作已经按要求修改，不意味着未做的实验通过验证。指南列出的可选实验和比较图，按论文贡献选择适用项目。\n','| 指南 | 部分 | 审查要求概括 | 本次处理 | 核对位置 |','| --- | --- | --- | --- | --- |']
lines += ['| '+' | '.join(r)+' |' for r in checks]
lines += ['\n## 重点修改\n',
'摘要按六句组织：任务、结构问题、方法、整体结果、补全结果、意义；减少次要数字和技术细节。引言按主题句组织五个主体段落，再列三项可核验贡献。全文重点统一为保持质量、大幅减少搜索查询、降低计算。\n',
'实验重新分成设置、指标、主结果、消融、动作案例、实际开销六节。设置补充环境种子0、重复计时层级和固定频次先验。主表从七列收为五列，质量通过与整周完成数在正文说明，使阅读更清楚；科学数值没有改动。\n',
'计时统一使用“先平均同日期两次计时，再计算日期比例并等权汇总”。GRID61旧review.json中的汇总以单条比例先算再平均，开发时间的13.0588%与本文13.1121%因此不同。论文及V3绘图已经采用后者，本次从32/24行CSV再次核验，未修改历史报告或择重复。\n',
'相关工作改为三条技术路线，明确控制器、排序模型与搜索组织之间的互补。删去把一般邻域思想单独包装成新范式的表述；具体贡献仍由补全集合、执行规则与消融结果支撑。\n',
'参考文献逐条人工核对。SoftGNN在DBLP标为2025，出版社页面首次上线为2025-10-02，但出版社“Cite this paper”给出的正式引用年为2026。本读稿采用出版社正式条目中的2026，保留ECML PKDD 2025会议名称；不改历史实验文件中的SoftGNN2025称呼。de Jong文献改用同一arXiv作品v3的新题名，原v1不重复列为第二项。\n',
'## 参考来源核对\n',
'| 条目 | 核对来源 | 核对结果 |','| --- | --- | --- |',
'| Grid2Op | https://github.com/Grid2op/grid2op | 软件条目使用实验版本和访问日期，未把2026写成首发年。 |',
'| LJN | https://github.com/lajavaness/l2rpn-2023-ljn-agent | 官方软件实现；文献类型保留软件。 |',
'| SoftGNN | https://link.springer.com/chapter/10.1007/978-3-032-06129-4_8 和 https://dblp.org/rec/conf/pkdd/HassounaHLJVSS25 | 全部七名作者、129至146、DOI；采用出版社2026正式引用年，记录DBLP差异。 |',
'| de Jong | https://arxiv.org/abs/2501.07186v3 | 同一作品v3已更名，仍为2025预印本，未写成Applied Energy已录用。 |',
'| Bhatia | https://ojs.aaai.org/index.php/ICAPS/article/view/19842 | 作者、2022、第32届、556至564、DOI核对。 |',
'| Milli | https://ojs.aaai.org/index.php/AAAI/article/view/11156/11015 | 原PDF起页4422末页4428，补全作者中间字母。 |',
'| Budd | https://ojs.aaai.org/index.php/AAAI/article/view/29983 | 2024、第38届、20053至20060、作者和DOI核对。 |',
'\n## 保留与待完善材料\n',
'用户V2、V3中英文稿及历史实验不覆盖。V3方法正文与公式内容保留，补入可见的公式1至3编号，四幅图使用原成果，图题补入读图说明。精确源文件哈希、数据聚合和交付哈希见revision_receipt.json。\n',
'中文确认后再推进英语及会议格式。本文主结果表是共同底座下的搜索策略比较；若最终论文需要声称优于完整学习控制器，还需将已有对应结果和实验范围单独整理，不能由这一表代替。跨电网、更多独立日期、参数适应性及外部频次先验教师覆盖仍是后续材料事项，正文未虚构这些结果。\n']
(OUT/'指南逐节审核与修改说明.md').write_text('\n'.join(lines),encoding='utf-8')
doc=Document(OUT/'ICAPS2027_中文全文修订稿_V4.docx')
text='\n'.join(p.text for p in doc.paragraphs)
assert '权衡' not in text
assert '不是' not in text and '而是' not in text
assert len(doc.inline_shapes)==4
assert len(doc.tables)==3
assert '13.11%' in text and '83.54%' in text
assert 'seed' not in text and '环境种子固定为0' in text
references=[p.text for p in doc.paragraphs if re.match(r'^\[\d\]',p.text)]
assert len(references)==7
assert all('['+str(n)+']' in text for n in range(1,8))
receipt=json.loads((OUT/'revision_receipt.json').read_text(encoding='utf-8'))
receipt['guide_requirement_checks']=len(checks)
receipt['document_checks']={'four_figures':True,'three_tables':True,'seven_references':True,'no_tradeoff_framing':True,'no_not_x_but_y':True,'source_documents_preserved':True}
receipt['visual_review']='pending'
(OUT/'revision_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print({'guide_checks':len(checks),'paragraphs':len(doc.paragraphs),'references':len(references)})
