"""Audit saved trigger traces and new vectors after all benchmark children exit."""
from pathlib import Path
import bisect,csv,gzip,hashlib,importlib.util,json,math,statistics
import numpy as np
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid93_trigger'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def save(n,x):(OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def main():
    D=read(OUT/'design.json');finish=read(OUT/'finished.json');assert finish['passed_engineering'] and finish['runs']==len(D['execution_order'])
    for name in ['code_freeze.json','data_freeze.json']:
        for rel,h in read(OUT/name).items():assert sha(ROOT/rel)==h,rel
    for rel,h in read(OUT/'screen_source_hashes.json').items():assert sha(ROOT/rel)==h,rel
    spec=importlib.util.spec_from_file_location('independent',ROOT/'work/grid89_review/reference_logic.py');I=importlib.util.module_from_spec(spec);spec.loader.exec_module(I)
    subs=read(ROOT/'outputs/grid28/offline.json')['public_subids']
    checks=dict(new_runs=0,steps=0,vectors=0,cost_steps=0,calls=0,queries=0,gate_decisions=0,reused_scenarios=0)
    digest=lambda x:hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()
    ledger_fields=['losses_mwh','redispatch_mwh','curtailment_delta_mwh','storage_throughput_mwh']
    new={s['week']:s for s in finish['summaries']}
    for s in finish['summaries']:
        folder=OUT/'runs'/f"r0__{s['week']}__SUPPORT_GATE"
        assert read(folder/'summary.json')==s
        with gzip.open(folder/'steps.jsonl.gz','rt',encoding='utf-8') as f:rs=[json.loads(x) for x in f]
        with np.load(folder/'vectors.npz') as z:actions=z['action'];observations=z['observation']
        assert len(rs)==len(actions)==len(observations)==s['steps']
        assert abs(math.fsum(r['raw_cost'] for r in rs)-s['cost'])<1e-6
        assert abs(math.fsum(r['decision_s'] for r in rs)-s['controller_s'])<1e-6
        assert sum(r['simulations'] for r in rs)==s['public_forecasts']
        assert s['illegal']==s['ambiguous']==0
        for j,r in enumerate(rs):
            assert digest(actions[j])==r['action_hash'] and digest(observations[j])==r['after_hash'];checks['vectors']+=2
            if j:assert r['before_hash']==rs[j-1]['after_hash']
            if r['ledger']:
                recomputed=r['ledger']['marginal_cost']*sum(r['ledger'][k] for k in ledger_fields)
                assert abs(recomputed-r['raw_cost'])<=r['ledger_tolerance']+1e-9;checks['cost_steps']+=1
        calls=sorted(folder.glob('call[0-9][0-9][0-9].json'));assert len(calls)==s['n1_calls']
        assert sum(read(p)['public_queries'] for p in calls)==s['n1_forecasts']
        for p in calls:
            c=read(p);truth={r['pool_id']:r for r in c['outcomes']};aliases={int(k):v for k,v in c['aliases'].items()}
            plan,initial_choice,budget=I.replay(c['order'],truth,subs,aliases,'NO_LOCAL',dict(p=128,h=64,patience=2,safe=.9,qmin=0))
            assert len(truth)==len(c['outcomes'])==c['public_queries']
            info=c['trigger_support'];local=[]
            if budget:
                station=subs[initial_choice];target={v for k,v in aliases.items() if subs[k]==station}
                left=[I.k(truth[i])[0] for i in plan if i!=initial_choice and i in target and truth[i]['strict_admissible']]
                right=sorted(I.k(truth[i])[0] for i in plan if i not in target and truth[i]['strict_admissible'])
                pairs=len(left)*len(right);twice_wins=sum(bisect.bisect_left(right,x)+bisect.bisect_right(right,x) for x in left)
                veto=bool(pairs and twice_wins<pairs)
                assert info['veto']==veto and info['score']==(twice_wins/(2*pairs) if pairs else None)
                assert c['completion_budget']==budget
                local=[i for i in c['order'] if i not in set(plan) and i in target] if not veto else []
                checks['gate_decisions']+=1
            else:assert info is None
            assert [r['pool_id'] for r in c['outcomes']]==plan+local
            assert c['local_queries']==len(local) and c['extra_selected_ids']==local
            picked=max((r for r in c['outcomes'] if r['strict_admissible']),key=I.k,default=None)
            assert c['chosen_pool_id']==(None if picked is None else picked['pool_id'])
            for r in c['outcomes']:
                assert r['strict_admissible']==bool(0<r['rho']<c['rho_limit'] and not r['done'] and not r['illegal'] and not r['ambiguous'] and not r['exceptions'])
            with np.load(p.with_name(p.stem+'_state.npz')) as z:assert digest(z['observation'])==c['state_hash']
            checks['queries']+=len(truth);checks['calls']+=1
        checks['new_runs']+=1;checks['steps']+=len(rs)
    rows=[]
    for plan in read(OUT/'scenario_plan.json'):
        frame=read(ROOT/plan['frame']/'summary.json');full=read(ROOT/plan['full']/'summary.json')
        if plan['needs_closed_loop']:
            gate=new[plan['week']];kind='new_closed_loop';queries=gate['n1_forecasts']
        else:
            gate=frame;kind='saved_call_equivalence';queries=plan['gate_queries_on_frame_states'];checks['reused_scenarios']+=1
        def quality(s):
            survival=bool(s['complete']) if full['complete'] else s['steps']>=full['steps']
            delta=s['cost']/full['cost']-1 if full['complete'] and s['complete'] else None
            return survival and (delta is None or delta<=.005),delta
        fq,fc=quality(frame);gq,gc=quality(gate)
        rows.append(dict(cohort=plan['cohort'],week=plan['week'],source_kind=kind,
                         frame_complete=frame['complete'],gate_complete=gate['complete'],frame_steps=frame['steps'],gate_steps=gate['steps'],
                         frame_quality=fq,gate_quality=gq,frame_cost=frame['cost'],gate_cost=gate['cost'],
                         frame_vs_full_pct=None if fc is None else 100*fc,gate_vs_full_pct=None if gc is None else 100*gc,
                         gate_vs_frame_cost_pct=100*(gate['cost']/frame['cost']-1) if frame['complete'] and gate['complete'] else None,
                         frame_queries=frame['n1_forecasts'],gate_queries=queries,
                         lost_quality=fq and not gq,
                         gate_descriptive_control_s=gate['controller_s'] if kind=='new_closed_loop' else None))
    with (OUT/'per_scenario.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
    groups=[]
    for g in ['old13','G1','G2']:
        rr=[r for r in rows if r['cohort']==g];costs=[r['gate_vs_frame_cost_pct'] for r in rr if r['gate_vs_frame_cost_pct'] is not None]
        groups.append(dict(cohort=g,scenarios=len(rr),frame_quality=sum(r['frame_quality'] for r in rr),gate_quality=sum(r['gate_quality'] for r in rr),
                           frame_complete=sum(r['frame_complete'] for r in rr),gate_complete=sum(r['gate_complete'] for r in rr),
                           new_runs=sum(r['source_kind']=='new_closed_loop' for r in rr),
                           frame_queries=sum(r['frame_queries'] for r in rr),gate_queries=sum(r['gate_queries'] for r in rr),
                           query_ratio_scenario_macro=statistics.mean(r['gate_queries']/r['frame_queries'] if r['frame_queries'] else 1. for r in rr),
                           complete_cost_pct_macro=statistics.mean(costs),max_cost_increase_pct=max(costs),lost_quality=[r['week'] for r in rr if r['lost_quality']]))
    save('review.json',dict(passed_saved_data=True,checks=checks,groups=groups,comparisons=rows,
                            independent_ac_resolve=False,new_training=0,new_rule_candidates=1,
                            reused_trajectory_caveat='19 entries checked at every original FRAME call; deterministic unchanged-choice reuse, not fresh physical replays or new timing.'))
    save('decision.json',dict(accepted=not any(r['lost_quality'] for r in rows),
                              category='REJECT_STATION_SUPPORT_TRIGGER' if any(r['lost_quality'] for r in rows) else 'QUALITY_PRESERVED_TRIGGER_WITH_LIMITED_EVIDENCE',
                              lost_quality=[r['week'] for r in rows if r['lost_quality']],
                              no_additional_rules_or_threshold_search=True))
    print(json.dumps(dict(groups=groups,checks=checks,decision=read(OUT/'decision.json')),ensure_ascii=False,indent=2))


if __name__=='__main__':main()
