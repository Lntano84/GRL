"""Independent arithmetic views and readable author/collaborator package."""
from pathlib import Path
from collections import defaultdict
import csv,hashlib,json,math,shutil,statistics,zipfile
from docx import Document
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/grid_icaps_cn_v5';PACK=ROOT/'论文协作资料/论文补强_GRID66-68'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 rec=read(OUT/'revision_receipt.json');assert sha(Path(rec['source']))==rec['source_sha256_unchanged']
 checks=0;results={}
 for stage in [65,67,68]:
  d=read(ROOT/f'outputs/grid{stage}/design.json');f=read(ROOT/f'outputs/grid{stage}/finished.json');rev=read(ROOT/f'outputs/grid{stage}/review.json');assert rev['passed_saved_data']
  by=defaultdict(list)
  for s in f['summaries']:by[s['week'],s['method']].append(s)
  m={}
  for method in [s['method'] for s in d['methods']]:
   queries=[];times=[];deltas=[];passed=complete=0
   for w in d['weeks']:
    a=by[w,method];b=by[w,'FULL'];assert len(a)==len(b)==d['repeats'];checks+=1
    avg=lambda rows,k:math.fsum(float(x[k]) for x in rows)/len(rows)
    same=all(x['steps']==y['steps'] and x['complete']==y['complete'] for x,y in zip(sorted(a,key=lambda z:z['repeat']),sorted(b,key=lambda z:z['repeat'])))
    both=all(x['complete'] for x in a+b)
    if both:deltas.append((avg(a,'cost')-avg(b,'cost'))/avg(b,'cost'))
    survival=all(x['complete'] if y['complete'] else x['steps']>=y['steps'] for x,y in zip(sorted(a,key=lambda z:z['repeat']),sorted(b,key=lambda z:z['repeat'])))
    per_repeat=all(not (x['complete'] and y['complete']) or x['cost']-y['cost']<=d['quality_threshold']*y['cost'] for x,y in zip(sorted(a,key=lambda z:z['repeat']),sorted(b,key=lambda z:z['repeat'])))
    passed+=int(survival and per_repeat);complete+=int(all(x['complete'] for x in a))
    if same:
     times.append((avg(b,'controller_s')-avg(a,'controller_s'))/avg(b,'controller_s'))
     if avg(b,'n1_forecasts')>0:queries.append((avg(b,'n1_forecasts')-avg(a,'n1_forecasts'))/avg(b,'n1_forecasts'))
   own=next(x for x in rev['summaries'] if x['method']==method);q=statistics.mean(queries) if queries else None;t=statistics.mean(times) if times else None
   kq='macro_query_reduction_full' if stage==65 else 'macro_query_reduction';kt='macro_time_reduction_full' if stage==65 else 'macro_time_reduction'
   for actual,expected in [(q,own[kq]),(t,own[kt])]:assert (actual is expected is None) or abs(actual-expected)<2e-12;checks+=1
   assert passed==own['quality_dates'];checks+=1
   m[method]={'quality_dates':passed,'complete_dates':complete,'query_saving':q,'time_saving':t,'max_complete_cost_change':max(deltas) if deltas else None}
  results[str(stage)]=m
 doc=Document(OUT/'ICAPS2027_中文全文修订稿_V5.docx');text='\n'.join(p.text for p in doc.paragraphs)+'\n'+'\n'.join(c.text for t in doc.tables for r in t.rows for c in r.cells)
 assert all(s in text for s in ['1 引言','2 方法','3 实验','4 结论','5 相关工作','6 局限','参考文献','P95','GLOBAL_MATCH','单参数'])
 assert len(doc._element.xpath('.//m:oMath'))==rec['method_equations_retained']==3
 assert '同站配置补全普遍优于' not in text
 PACK.mkdir(parents=True,exist_ok=True)
 for name in ['ICAPS2027_中文全文修订稿_V5.docx','ICAPS2027_中文全文修订稿_V5.md','references_checked.bib','revision_receipt.json','figure_workflow.json','same_state_mechanism.json','same_state_mechanism.csv','failure_diagnostic.json']:
  shutil.copy2(OUT/name,PACK/name)
 for stage in [66,67,68]:
  dest=PACK/f'GRID{stage}';dest.mkdir(exist_ok=True)
  for p in (ROOT/f'outputs/grid{stage}').iterdir():
   if p.is_file() and p.suffix in ('.csv','.json','.md') and p.name not in ('code_freeze.json',) and not p.name.startswith(('worker_result','interval')):shutil.copy2(p,dest/p.name)
 for p in (OUT/'figures').iterdir():
  dest=PACK/'figures';dest.mkdir(exist_ok=True);shutil.copy2(p,dest/p.name)
 o=results['65']['FRAME'];n=results['68']['FRAME'];pct=lambda x:'不可比' if x is None else f'{100*x:.2f}%'
 note=f'''# 本轮补强：先读这里

## 当前裁决

新增六日期没有通过冻结质量判据：FRAME质量4/6、完成5/6，而FULL完成6/6。7月9日提前116步结束；12月10日成本高0.6405%。66.64%查询减少和16.37%控制时间减少只涵盖另外五个等时域日期。当前V5是包含失效结果的阅读诊断稿，尚不宜直接作为质量主张成立的投稿版本。

## 三项交付

1. 已有70条回放：逐日期成本、每次耗时/标准差/范围、所有步骤与搜索步骤P95/P99、互斥计算分解；整理至中文V5与GRID66 CSV。
2. 参数敏感性24条：四旧开发日期，前缀64/128/256、停滞1/2/3，只改变一个参数；默认配置不变。
3. 新场景36条：六个本地未见控制/教师结果的日期，FULL/FRAME/等预算全局扩展各两次。全部日期和较差结果保留。

## 方法究竟有什么意义

FRAME把排序之后的候选预测组织为反馈驱动的渐进查询。它可直接接入已有混合控制器，保留连续控制和恢复，通过已查询反馈决定扩展，使用当前最佳结果复用已有计算。实际意义是减少昂贵的候选预测，并以闭环质量检验这种压缩是否可用。

既有组：质量{o['quality_dates']}/7、完成{o['complete_dates']}/7，查询减少{pct(o['query_saving'])}，完整控制时间减少{pct(o['time_saving'])}。
新增组：质量{n['quality_dates']}/6、完成{n['complete_dates']}/6，五个等时域日期查询减少{pct(n['query_saving'])}，完整控制时间减少{pct(n['time_saving'])}。提前结束的七月不计为省时或省查询。

## 哪些构成论文贡献

贡献主线是“面向混合电网控制的查询分配框架及闭环计算证据”。方法部分说明统一接口、渐进查询、最佳已观测结果保留、别名感知的一次补查与至多一次查询计量；实验部分同时报告质量、搜索查询和完整控制计算，并补上等预算、外部来源停止适配、参数和新增日期。

GNN不是本论文主实验的新贡献。既有等预算结果中，同站补全相对全局补查增量很小，不能把框架全部收益归为同站结构独有作用。新增结果按逐日期实测解释。框架组合与领域实例化的学术新颖性仍需作者在相关工作中判断；实验数量本身不会自动产生算法创新。

新增二月FRAME相对GLOBAL_MATCH的整周成本改善为FULL的3.3862%；四月与12月10日则分别差0.1311%与0.2082%。整周查询总数随轨迹变化；精确预算匹配针对相同状态的附加查询。结果支持结构选择有时重要，同时保留了方向相反的案例。

## 现在最需要解决的实际问题

七月首次动作分歧在第100步：FRAME首批128次直接返回动作18，预测负载率0.48525；FULL选动作741，预测负载率0.48055，两个动作属于不同变电站。两者均很低，简单把0.9改为略小阈值不能解释或消除这一分歧。12月首次分歧也来自首批直接返回。下一步优先检验这一分支的覆盖和后续风险；现有离线定位尚未证明只改一个早期动作就能修复整周失效。

## 数据资格与研究范围

此前GRID62将全部已解压日期保守地排除；本次区分了“数据格式检查/未入选清单”和“实际控制/教师结果”。实际结果使用记录、旧使用审计、训练与失败目录共同筛选后，剩余六个本地未回放日期。它们仍是同一个公开合成电网，外部作者先验训练覆盖未知；不写成跨电网或完全无外部训练交集的确认。

两个计时重复不是两个独立场景。参数实验单次计时只用于描述。保存向量和账目核验不等于独立AC重求解。

## 审计与版本

旧稿V4和用户修改材料未覆盖。物理终止会产生异常标记，新审计最初将它误与非法/歧义控制归零要求合并；显式补充入口仅纠正这一离线断言，保留原脚本、报错和全部运行。没有改任何方法、参数、日期或重跑已完成回放。

中文V5供通读与重写；英语和正式8页排版等中文确认后再制作。
'''
 (PACK/'先读_结果与贡献.md').write_text(note,encoding='utf-8');(OUT/'结果与贡献.md').write_text(note,encoding='utf-8')
 save={'passed':True,'independent_arithmetic_checks':checks,'summaries':results,'native_method_equations':3,'old_source_unchanged':True,'independent_ac_resolve':False,'render_gate':'Pending separate visual QA; this arithmetic check alone does not certify layout.'}
 (OUT/'paper_data_audit.json').write_text(json.dumps(save,ensure_ascii=False,indent=2),encoding='utf-8')
 shutil.copy2(OUT/'paper_data_audit.json',PACK/'paper_data_audit.json')
 print(json.dumps({'passed':True,'checks':checks,'package':str(PACK)},ensure_ascii=False))
if __name__=='__main__':main()
