from pathlib import Path
import os,subprocess,sys,ctypes
HERE=Path(__file__).resolve().parent
deps=Path('C:/Users/windows/.cache/codex-runtimes/codex-primary-runtime/dependencies')
renderer=Path('D:/Codex/GRL研究/work/grid_cn_draft/render_dependency/extracted/program/soffice.exe')
helper=Path('C:/Users/windows/.codex/plugins/cache/openai-primary-runtime/documents/26.1011.11113/skills/documents/render_docx.py')
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
temp=HERE/'tmp';temp.mkdir(exist_ok=True)
env=dict(os.environ,PATH=str(renderer.parent)+os.pathsep+str(deps/'python')+os.pathsep+str(deps/'native/poppler/Library/bin')+os.pathsep+os.environ.get('PATH',''),PYTHONUTF8='1',PYTHONIOENCODING='utf-8',TEMP=str(temp),TMP=str(temp))
symbolfont=renderer.parents[1]/'Fonts/opens___.ttf'
gdi=ctypes.WinDLL('gdi32',use_last_error=True)
gdi.AddFontResourceExW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint,ctypes.c_void_p]
gdi.RemoveFontResourceExW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint,ctypes.c_void_p]
registered=gdi.AddFontResourceExW(str(symbolfont),0,None)
try:
 with (out/'render.log').open('w',encoding='utf-8') as log:
  log.write('Temporary session font registration (OpenSymbol): '+str(registered)+'\n');log.flush()
  r=subprocess.run([str(deps/'python/python.exe'),str(helper),str(source),'--output_dir',str(out),'--emit_pdf','--dpi','105'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
finally:
 if registered:gdi.RemoveFontResourceExW(str(symbolfont),0,None)
print((out/'render.log').read_text(encoding='utf-8')[-1500:])
if r.returncode:raise SystemExit(r.returncode)
