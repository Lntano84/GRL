"""Frozen finite run, saved-data audit and publication; no adaptive experiment additions."""
from pathlib import Path
import datetime as dt,json,os,subprocess,sys,traceback
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid90_expert';REPO=ROOT/'work/GRL-results-integration'


def save(name,x):
    p=OUT/name;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');os.replace(t,p)


def main():
    assert not (OUT/'complete.json').exists()
    for phase,script,args in [('benchmark','run.py',[]),('audit','audit.py',[]),('archive','archive.py',['--phase','complete'])]:
        save('pipeline_state.json',dict(phase=phase,pid=os.getpid(),utc=dt.datetime.now(dt.timezone.utc).isoformat()))
        with (OUT/f'{phase}_pipeline.log').open('a',encoding='utf-8') as log:
            subprocess.run([sys.executable,'-u',str(W/script),*args],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    message=OUT/'push_message.txt';message.write_text('Publish audited FRAME versus ExpertOp heuristic comparison\n',encoding='utf-8')
    with (OUT/'push_pipeline.log').open('a',encoding='utf-8') as log:
        subprocess.run([str(REPO/'scripts/git_push.cmd'),str(message)],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
    head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
    remote=subprocess.check_output(['git','-C',str(REPO),'ls-remote','lntano-src','refs/heads/main'],text=True).split()[0];assert head==remote
    save('complete.json',dict(passed=True,review='outputs/grid90_expert/review.json',report='outputs/grid90_expert/GRID90_report.md',git_sha=head,remote_verified=True))
    save('pipeline_state.json',dict(phase='complete',pid=os.getpid(),git_sha=head))
    (OUT/'RUN_STATE.md').write_text('COMPLETE:24 runs, saved-data/native-ranking audit and archive/push verified.\n',encoding='utf-8')


if __name__=='__main__':
    try:main()
    except BaseException:
        save('pipeline_error.json',dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(),traceback=traceback.format_exc()));raise
