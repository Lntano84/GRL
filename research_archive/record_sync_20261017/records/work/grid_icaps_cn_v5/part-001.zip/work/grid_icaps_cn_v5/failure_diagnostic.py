"""Locate first divergence using saved vectors/feedback only. No new physics calls."""
from pathlib import Path
import gzip,json
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/grid_icaps_cn_v5'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def main():
 assert read(ROOT/'outputs/grid68/review.json')['passed_saved_data']
 subs=read(ROOT/'outputs/grid28/offline.json')['public_subids'];rows=[]
 for week in ['2035-07-09_2','2035-12-10_6']:
  folders={m:ROOT/f'outputs/grid68/runs/r0__{week}__{m}' for m in ['FULL','FRAME','GLOBAL_MATCH']}
  steps={}
  calls={m:[read(p) for p in sorted(f.glob('call[0-9][0-9][0-9].json'))] for m,f in folders.items()}
  for m,folder in folders.items():
   with gzip.open(folder/'steps.jsonl.gz','rt',encoding='utf-8') as f:steps[m]=[json.loads(l) for l in f]
  for m in ['FRAME','GLOBAL_MATCH']:
   n=next((i for i,(a,b) in enumerate(zip(steps[m],steps['FULL'])) if a['action_hash']!=b['action_hash'] or a['after_hash']!=b['after_hash']),None)
   assert n is not None
   step=steps[m][n]['step'];assert steps[m][n]['before_hash']==steps['FULL'][n]['before_hash']
   own=[c for c in calls[m] if c['step']==step];full=[c for c in calls['FULL'] if c['step']==step]
   detail=[]
   for a in own:
    b=next(c for c in full if c['state_hash']==a['state_hash']);assert a['order']==b['order']
    truth={r['pool_id']:r for r in b['outcomes']};fa=b['chosen_pool_id'];oa=a['chosen_pool_id'];seen={r['pool_id'] for r in a['outcomes']}
    detail.append({'same_observation_and_base':a['state_hash']==b['state_hash'],'policy':a['policy'],'stop_reason':a['stop_reason'],'queries':a['public_queries'],'full_queries':b['public_queries'],'shortlist_choice':a['shortlist_choice'],'own_choice':oa,'full_choice':fa,'full_choice_queried':fa in seen,'own_choice_rho':None if oa is None else truth[oa]['rho'],'full_choice_rho':None if fa is None else truth[fa]['rho'],'own_choice_reward':None if oa is None else truth[oa]['reward'],'full_choice_reward':None if fa is None else truth[fa]['reward'],'own_choice_substation':None if oa is None else subs[oa],'full_choice_substation':None if fa is None else subs[fa],'completion_budget':a['completion_budget'],'completion_changed_choice':oa!=a['pre_extra_choice']})
   rows.append({'date':week,'method':m,'first_divergence_step':step,'own_final_steps':len(steps[m]),'full_final_steps':len(steps['FULL']),'search_at_first_divergence':detail,'last_step_flags':{k:steps[m][-1][k] for k in ['done','complete','exceptions','illegal','ambiguous']},'interpretation':'First divergence identifies which search branch made a different choice. It does not prove that changing this one decision repairs the eventual full-week outcome.'})
 OUT.mkdir(exist_ok=True);result={'passed_saved_data':True,'rows':rows,'new_simulations':0,'new_model_fits':0,'scope':'Both new quality-failing dates, all two compressed policies, repeat0. Repeat1 physical paths already audited identical. No counterfactual physics or online full-feedback access.'}
 (OUT/'failure_diagnostic.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
