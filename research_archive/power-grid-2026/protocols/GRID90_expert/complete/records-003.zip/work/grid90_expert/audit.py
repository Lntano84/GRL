"""Saved vectors, all query types, native ranking replay and same-batch statistics."""
from pathlib import Path
from collections import defaultdict
import gzip,hashlib,importlib.util,json,math,os,statistics,sys
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid90_expert'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))


def save(name,v):(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')


def digest(v):
    import numpy as np
    return hashlib.sha256(np.ascontiguousarray(v).tobytes()).hexdigest()


def signature(steps):
    return hashlib.sha256(json.dumps([(r['before_hash'],r['action_hash'],r['after_hash'],r['raw_cost'],r['done'],r['complete']) for r in steps],separators=(',',':')).encode()).hexdigest()


def main():
    D=read(OUT/'design.json');S=read(OUT/'finished.json')['summaries'];assert len(S)==24
    for freeze in ['code_freeze.json','data_freeze.json']:
        for p,h in read(OUT/freeze).items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
    sys.path[:0]=[str(ROOT/'work/grid30'),str(ROOT/'work/grid29'),str(ROOT/'work/grid08'),str(ROOT/'work/grid28')]
    from common import grid2op,LightSimBackend,MaxRhoReward,operational_other_rewards,np,ResidualControl,action_vector
    from engine import Search
    spec=importlib.util.spec_from_file_location('expert_saved_audit',W/'adapter.py');A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)
    env=grid2op.make(str(ROOT/D['environment']),test=True,backend=LightSimBackend(),reward_class=MaxRhoReward,other_rewards=operational_other_rewards())
    obs0=env.reset();ctl=ResidualControl(env,obs0);search=Search(env,ctl,'STATIC_ID',128,None)
    baseline_class=type(obs0);had_local='simulate' in baseline_class.__dict__;original_simulate=baseline_class.simulate
    # Grid2Op's forecast observation class has extra vector fields. Build its
    # template once on the initial setup state, never re-solve a saved trajectory.
    future0=obs0.simulate(env.action_space(),time_step=1)[0]
    observed_highres=int(env.nb_highres_called);checks=defaultdict(int);checks['setup_template_forecasts']=1;rows=[];signatures={}
    full={r['week']:r for r in read(ROOT/'outputs/grid89_review/sealed/finished.json')['summaries'] if r['method']=='FULL' and r['repeat']==0}
    prior_frame={r['date']:r['trajectory_signature'] for r in read(ROOT/'outputs/grid89_review/review.json')['rows'] if r['phase']=='sealed' and r['method']=='FRAME_GUARD' and r['repeat']==0}
    try:
        for s in S:
            folder=OUT/'runs'/f"r{s['repeat']}__{s['week']}__{s['method']}"
            assert read(folder/'summary.json')==s and s['illegal']==s['ambiguous']==0
            with gzip.open(folder/'steps.jsonl.gz','rt',encoding='utf-8') as f:steps=[json.loads(x) for x in f]
            assert len(steps)==s['steps']
            assert abs(math.fsum(x['raw_cost'] for x in steps)-s['cost'])<1e-6
            assert abs(math.fsum(x['decision_s'] for x in steps)-s['controller_s'])<1e-6
            assert sum(x['simulations'] for x in steps)==s['public_forecasts']
            with np.load(folder/'vectors.npz') as z:
                assert len(z['action'])==len(z['observation'])==len(steps)
                for j,r in enumerate(steps):
                    assert digest(z['action'][j])==r['action_hash'] and digest(z['observation'][j])==r['after_hash']
                    if r['ledger'] is not None:assert abs(r['ledger']['recomputed_raw_cost']-r['raw_cost'])<=r['ledger_tolerance']
            sig=signature(steps);key=(s['week'],s['method'])
            if key in signatures:assert signatures[key]==sig;checks['repeat_trajectories']+=1
            else:signatures[key]=sig
            if s['method']=='FRAME_GUARD':assert sig==prior_frame[s['week']];checks['frame_prior_trajectories']+=1
            calls=[read(p) for p in sorted(folder.glob('call[0-9][0-9][0-9].json'))]
            assert len(calls)==s['n1_calls'] and sum(c['public_queries'] for c in calls)==s['n1_forecasts']
            analyses=candidates=unavailable=0
            for j,c in enumerate(calls):
                with np.load(folder/f'call{j:03d}_state.npz') as z:
                    obs=obs0.copy();obs.from_vect(z['observation']);base=env.action_space();base.from_vect(z['base_action'])
                eligible,reps,aliases,actions,changed=search.prepare(obs,base)
                assert reps==c['representatives'] and aliases=={int(k):int(v) for k,v in c['aliases'].items()}
                truth={r['pool_id']:r for r in c['outcomes']};assert len(truth)==len(c['outcomes'])
                for r in c['outcomes']:
                    assert r['strict_admissible']==bool(0<r['rho']<c['rho_limit'] and not r['done'] and not r['exceptions'] and not r['illegal'] and not r['ambiguous'])
                    assert r['combined_hash']==digest(action_vector(actions[r['pool_id']]+base))
                if c['chosen_pool_id'] is not None:
                    best=max((r for r in c['outcomes'] if r['strict_admissible']),key=lambda r:(float(np.float32(r['reward'])),-r['pool_id']))
                    assert best['pool_id']==c['chosen_pool_id']
                    assert digest(action_vector(actions[best['pool_id']]))==c['returned_action_hash']
                if s['method']=='FRAME_GUARD':
                    baseline_class.simulate=original_simulate
                    spec2=importlib.util.spec_from_file_location('expert_audit_frame_reference',ROOT/'work/grid70/policies.py')
                    P=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(P);seen=[]
                    def reveal(i,phase):
                        assert i in truth and i not in seen and truth[i]['phase']==phase;seen.append(i);return truth[i]
                    got=P.run(c['order'],reveal,'FRAME_GUARD',search.subids,aliases,limit=c['rho_limit'])
                    assert seen==[r['pool_id'] for r in c['outcomes']]
                    assert got['chosen_pool_id']==c['chosen_pool_id'] and got['public_queries']==c['public_queries']
                    candidates+=len(seen)
                else:
                    assert c['public_queries']==len(c['analysis_probes'])+len(truth)
                    assert len(c['analysis_probes'])<=3 and len(truth)<=75
                    with np.load(folder/f'call{j:03d}_expert_futures.npz') as z:
                        future={int(i):v.copy() for i,v in zip(z['pool_ids'],z['vectors'])}
                    assert set(future)==set(truth)
                    for i,v in future.items():assert digest(v)==truth[i]['future_hash']
                    trace=[];seen=set()
                    for probe,analysis in zip(c['analysis_probes'],c['expert_analyses']):
                        assert probe['lines']==[analysis['line']]
                        trace.append(('probe',probe))
                        assert probe['action_hash']==digest(np.asarray(probe['action_vector'],dtype=np.float32))
                        if analysis['status']=='ranked':
                            assert analysis['considered']<=25
                            pernode=defaultdict(int)
                            for rank in analysis['rankings']:
                                pernode[rank['node']]+=1;assert pernode[rank['node']]<=5
                                i=rank['pool_id']
                                if i not in seen:trace.append(('candidate',i));seen.add(i)
                        else:assert analysis['status']=='unavailable_public_probe';unavailable+=1
                    assert seen==set(truth)
                    cursor=[0]
                    def fake(observation,action,*args,**kw):
                        assert kw.get('time_step',1)==1
                        assert cursor[0]<len(trace)
                        kind,value=trace[cursor[0]];cursor[0]+=1
                        if kind=='probe':
                            r=value;assert digest(action_vector(action))==r['action_hash'];v=np.asarray(r['future_vector'],dtype=np.float32)
                        else:
                            r=truth[value];assert digest(action_vector(action))==r['combined_hash'];v=future[value]
                        after=future0.copy();after.from_vect(v)
                        return after,r['reward'],r['done'],dict(is_illegal=r['illegal'],is_ambiguous=r['ambiguous'],exception=r['exceptions'])
                    baseline_class.simulate=fake
                    search.policy='EXPERTOP_SHARED'
                    _,got,_,_=A.expert_search(search,obs,base,0.,rho_threshold=c['rho_limit'])
                    assert cursor[0]==len(trace)
                    for k in ['chosen_pool_id','public_queries','candidate_queries','analysis_queries','stop_reason','expert_considered']:
                        assert got[k]==c[k],(s['week'],j,k)
                    assert [r['pool_id'] for r in got['outcomes']]==[r['pool_id'] for r in c['outcomes']]
                    analyses+=len(c['analysis_probes']);candidates+=len(truth);checks['expert_native_ranking_replays']+=1
                checks['search_calls']+=1
            cp=read(folder/'components.json')
            optimizer=math.fsum(v['wall_s'] for v in cp['calls'] if v['in_control'])
            forecast=s['all_forecast_s'];nonforecast=s['n1_source_s']-s['n1_forecast_s'];remainder=s['controller_s']-optimizer-forecast-nonforecast
            assert min(optimizer,forecast,nonforecast,remainder)>=-1e-6
            ref=full[s['week']];delta=s['cost']/ref['cost']-1 if s['complete'] and ref['complete'] else None
            quality=bool((s['complete'] if ref['complete'] else s['steps']>=ref['steps']) and (delta is None or delta<=.005))
            active={c['step'] for c in calls};lat=[r['decision_s'] for r in steps];n1=[r['decision_s'] for r in steps if r['step'] in active]
            rows.append(dict(date=s['week'],method=s['method'],repeat=s['repeat'],steps=s['steps'],complete=s['complete'],
                cost=s['cost'],quality_pass=quality,cost_delta_full=delta,controller_s=s['controller_s'],queries=s['n1_forecasts'],
                candidate_queries=candidates,analysis_queries=analyses,unavailable_probes=unavailable,
                all_p95=float(np.percentile(lat,95)),all_p99=float(np.percentile(lat,99)),
                search_p95=float(np.percentile(n1,95)) if n1 else None,search_p99=float(np.percentile(n1,99)) if n1 else None,
                optimizer_s=optimizer,forecast_s=forecast,search_nonforecast_s=nonforecast,remainder_s=remainder,trajectory_signature=sig))
            checks['steps']+=len(steps)
        assert int(env.nb_highres_called)==observed_highres
    finally:
        if had_local:baseline_class.simulate=original_simulate
        else:delattr(baseline_class,'simulate')
        env.close()
    groups=[]
    for date in D['weeks']:
        for method in ['FRAME_GUARD','EXPERTOP_SHARED']:
            own=[r for r in rows if r['date']==date and r['method']==method];assert len(own)==2
            g={k:own[0][k] for k in ['date','method','steps','complete','cost','cost_delta_full','queries','candidate_queries','analysis_queries','unavailable_probes']}
            g['quality_pass']=all(r['quality_pass'] for r in own)
            for k in ['controller_s','all_p95','all_p99','optimizer_s','forecast_s','search_nonforecast_s','remainder_s']:
                g[k]=statistics.mean(r[k] for r in own)
            for k in ['search_p95','search_p99']:
                g[k]=statistics.mean(r[k] for r in own if r[k] is not None) if any(r[k] is not None for r in own) else None
            g['controller_min']=min(r['controller_s'] for r in own);g['controller_max']=max(r['controller_s'] for r in own)
            groups.append(g)
    save('review.json',dict(passed_saved_data=True,runs=24,checks=dict(checks),rows=rows,groups=groups,
                           independent_ac_resolve=False,new_training=0))
    compare=[]
    for date in D['weeks']:
        a=next(r for r in groups if r['date']==date and r['method']=='FRAME_GUARD')
        b=next(r for r in groups if r['date']==date and r['method']=='EXPERTOP_SHARED')
        equal=(a['steps'],a['complete'])==(b['steps'],b['complete'])
        compare.append(dict(date=date,same_horizon=equal,both_quality=a['quality_pass'] and b['quality_pass'],
             controller_reduction=1-a['controller_s']/b['controller_s'],
             query_reduction=1-a['queries']/b['queries'] if equal and b['queries'] else None,
             all_p95_reduction=1-a['all_p95']/b['all_p95'],
             search_p95_reduction=1-a['search_p95']/b['search_p95'] if a['search_p95'] is not None and b['search_p95'] else None))
    query=[r['query_reduction'] for r in compare if r['query_reduction'] is not None]
    repeat=[statistics.mean(1-next(r for r in rows if r['date']==d and r['repeat']==rep and r['method']=='FRAME_GUARD')['controller_s']/next(r for r in rows if r['date']==d and r['repeat']==rep and r['method']=='EXPERTOP_SHARED')['controller_s'] for d in D['weeks']) for rep in [0,1]]
    macro=statistics.mean(r['controller_reduction'] for r in compare)
    eligible=all(r['both_quality'] and r['same_horizon'] for r in compare)
    supported=bool(eligible and macro>=.05 and sum(r['controller_reduction']>0 for r in compare)>=4 and all(r>0 for r in repeat) and query and statistics.mean(query)>=.05)
    decision=dict(equal_quality_eligible=eligible,frame_same_quality_compute_advantage=supported,
        macro_controller_reduction=macro,macro_query_reduction=statistics.mean(query) if query else None,
        query_dates=len(query),repeat_macro_controller_reductions=repeat,dates=compare,
        all_results_retained=True,unavailable_public_counterfactuals=sum(r['unavailable_probes'] for r in rows),
        category='SUPPORTED_EQUAL_QUALITY_COMPUTE_ADVANTAGE' if supported else 'REPORT_QUALITY_COMPUTE_TRADEOFF_OR_COMPETITIVENESS',
        scope=D['scope'])
    save('decision.json',decision)
    lines=['# GRID90：FRAME与ExpertOp结构启发式比较','',
       '两方法使用同一电网、六个已暴露G2输入、合法候选库、基础控制器和普通一步预测接口，采用两次交错反向计时。ExpertOp使用原作者影响图和专家拓扑评分，限制在共有动作库，默认每条监测线路25候选、每站5候选、最多3条过载线路；未调参或训练。','',
       '原实现的保护参数覆盖、零步静态仿真、外围恢复/重连控制未带入公共控制器。适配版在公共控制器低于过载率1时触发搜索，则分析负载率最高的在线线路。它应称为ExpertOp4Grid任务适配，不能声称原方法完整复现。','',
       '| 方法 | 质量达标 | 完整周完成 | 查询合计/重复 | 完整控制秒/日期 | 最大可比完整周成本变化 |','|---|---:|---:|---:|---:|---:|']
    for method in ['FRAME_GUARD','EXPERTOP_SHARED']:
        own=[r for r in groups if r['method']==method];cost=[r['cost_delta_full'] for r in own if r['cost_delta_full'] is not None]
        lines.append(f"| {method} | {sum(r['quality_pass'] for r in own)}/6 | {sum(r['complete'] for r in own)}/6 | {sum(r['queries'] for r in own)} | {statistics.mean(r['controller_s'] for r in own):.3f} | {max(cost)*100:+.4f}% |")
    lines+=['',f'FRAME相对ExpertOp：完整控制时间逐日期宏平均减少{macro*100:+.3f}%；匹配活跃时域查询减少'+(f'{statistics.mean(query)*100:+.3f}%' if query else '不适用')+'。正值为FRAME更少，负值为FRAME更多。',
            f'双方全日期质量及时域匹配={eligible}；预先冻结的同质量计算优势判据={supported}。未达质量条件时，时间和查询只作描述，不称同质量提速。','',
            '| 日期 | FRAME质量/完成 | ExpertOp质量/完成 | FRAME成本差 | ExpertOp成本差 | FRAME控制秒 | ExpertOp控制秒 | FRAME查询 | ExpertOp候选+分析查询 |','|---|---|---|---:|---:|---:|---:|---:|---:|']
    fmt=lambda x:'—' if x is None else f'{x*100:+.4f}%'
    for date in D['weeks']:
        a=next(r for r in groups if r['date']==date and r['method']=='FRAME_GUARD');b=next(r for r in groups if r['date']==date and r['method']=='EXPERTOP_SHARED')
        lines.append(f"| {date} | {a['quality_pass']}/{a['complete']} | {b['quality_pass']}/{b['complete']} | {fmt(a['cost_delta_full'])} | {fmt(b['cost_delta_full'])} | {a['controller_s']:.3f} | {b['controller_s']:.3f} | {a['queries']} | {b['candidate_queries']}+{b['analysis_queries']} |")
    lines+=['','全部P95/P99、逐重复计时范围和优化/预测/搜索其余部分见review.json；建立影响图的诊断仿真计入查询和预测耗时。旧FULL只作质量/时域/完整周成本参照，不混入旧FULL时间。','',
            f"不可用的公共线路反事实共{decision['unavailable_public_counterfactuals']}次（含两个计时重复）。此类接口/信息条件受限单列；不能解释为原ExpertOp算法失败。保留所有较差、较慢及未完成场景。",
            '同一公开电网与已暴露生成时序；两次计时不是两个独立场景。审计检查保存向量、合法反馈、查询/结构排名重执行和成本账本，没有独立AC重求解。']
    (OUT/'GRID90_report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({k:v for k,v in decision.items() if k!='dates'}),flush=True)


if __name__=='__main__':main()
