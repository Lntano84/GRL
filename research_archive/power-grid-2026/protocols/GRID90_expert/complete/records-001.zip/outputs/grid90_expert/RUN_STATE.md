RUNNING:23/24 complete; one serial worker; all outcomes retained.
