"""Finite source-interface checks on old calibration inputs, never test selection."""
from pathlib import Path
import hashlib,json,os,sys,time,traceback
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[name]='1'
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid90_expert'
sys.path[:0]=[str(ROOT/'work/grid30'),str(ROOT/'work/grid29'),str(ROOT/'work/grid08'),str(ROOT/'work/grid28')]
from common import make_env,ResidualControl,np,action_vector
from engine import Search
import importlib.util
spec=importlib.util.spec_from_file_location('expert_qualification_adapter',W/'adapter.py');A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)


def save(name,x):(OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')


def main():
    OUT.mkdir(exist_ok=True)
    env=make_env();obs=env.reset();ctl=ResidualControl(env,obs);search=Search(env,ctl,'STATIC_ID',128,None)
    search.policy='EXPERTOP_SHARED'
    rows=[];initial_parameters=env.parameters.to_dict()
    try:
        for j in range(3):
            source=ROOT/f'outputs/grid18/runs/2035-07-23_10/call{j:03d}_state.npz'
            with np.load(source) as z:obs.from_vect(z['observation']);base=env.action_space();base.from_vect(z['base_action'])
            before=obs.to_vect().copy();count=int(env.nb_highres_called);start=time.perf_counter()
            selected,log,features,prior=A.expert_search(search,obs,base,0.)
            assert env.parameters.to_dict()==initial_parameters
            assert np.array_equal(before,obs.to_vect())
            assert int(env.nb_highres_called)-count==log['public_queries']
            assert len({r['pool_id'] for r in log['outcomes']})==len(log['outcomes'])
            assert log['public_queries']==log['candidate_queries']+log['analysis_queries']
            assert selected is None or log['chosen_pool_id'] in log['representatives']
            if selected is not None:
                best=max((r for r in log['outcomes'] if r['strict_admissible']),key=lambda r:(float(np.float32(r['reward'])),-r['pool_id']))
                assert best['pool_id']==log['chosen_pool_id']
            save(f'qualification_call{j:03d}.json',log)
            row=dict(id=f'2035-07-23_10__call{j:03d}',root_rho=float(obs.rho.max()),
                candidates=len(log['representatives']),candidate_queries=log['candidate_queries'],
                analysis_queries=log['analysis_queries'],chosen=log['chosen_pool_id'],
                statuses=[x['status'] for x in log['expert_analyses']],wall_s=time.perf_counter()-start)
            rows.append(row);print(json.dumps(row),flush=True)
        assert any(r['candidate_queries'] for r in rows),'No actual ranking path qualified'
        save('qualification.json',dict(passed=True,rows=rows,parameters_unchanged=True,
            root_vectors_unchanged=True,queries_fully_accounted=True,new_training=0,
            closed_loop_runs=0,scope='Three predetermined old calibration calls; no quality or parameter selection.'))
    finally:env.close()


if __name__=='__main__':
    try:main()
    except Exception:
        OUT.mkdir(exist_ok=True);save('qualification_error.json',dict(traceback=traceback.format_exc()));raise
