"""Preserve GRID25 diagnostic and freeze the corrected GRID26 protocol in Git."""
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT / "work/GRL-results-integration"
ARCHIVE = REPO / "research_archive/power-grid-2026"
SNAP = ARCHIVE / "protocols/GRID26_before_runs"
assert not SNAP.exists()
assert json.loads((ROOT / "outputs/grid25/pilot_audit.json").read_text())["passed"]
assert json.loads((ROOT / "outputs/grid26/preflight.json").read_text())["passed"]
assert json.loads((ROOT / "outputs/grid26/timer_preflight.json").read_text())["passed"]
status = {"status": "PILOT_INSTRUMENTATION_SUPERSEDED", "completed_runs": 4, "remaining_runs_started": 0,
    "action_quality_valid": True, "formal_speed_claim": False,
    "reason": "Per-observation bound-method restoration introduces an object reference cycle. Not proved to explain measured variation; removed before formal repeated timing.",
    "successor": "GRID26 class-level timer; same model, guard, candidate method and balanced 48-run matrix."}
o25 = ROOT / "outputs/grid25"
(o25 / "TIMING_PROTOCOL_STATUS.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
(o25 / "RUN_STATE.md").write_text("CLOSED AFTER FOUR PILOT RUNS. Valid saved-data quality audit. Timing instrumentation superseded; do not run remaining44. GRID26 is the corrected benchmark. No model failure, no new fits, no reserved families.\n", encoding="utf-8")
report = o25 / "GRID25_pilot_report.md"
report.write_text("**测量协议已修订：本报告仅作四条试点诊断，不认证真实提速。详见 TIMING_PROTOCOL_STATUS.json；正式重复改为 GRID26。**\n\n" + report.read_text(encoding="utf-8"), encoding="utf-8")
files = []
for stage in ["grid25", "grid26"]:
    for p in sorted((ROOT / "work" / stage).glob("*.py")):
        files.append(p)
    for p in sorted((ROOT / "outputs" / stage).iterdir()):
        if p.is_file() and p.suffix in [".md", ".json", ".csv"]:
            files.append(p)
records = []
for p in files:
    rel = p.relative_to(ROOT)
    target = SNAP / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, target)
    expected = hashlib.sha256(p.read_bytes()).hexdigest()
    assert hashlib.sha256(target.read_bytes()).hexdigest() == expected
    records.append({"path": rel.as_posix(), "bytes": p.stat().st_size, "sha256": expected})
(SNAP / "manifest.json").write_text(json.dumps({"files": records, "scope": "Immutable pre-benchmark protocol and GRID25 superseded pilot. Raw vectors stay local; no GRID26 rollout results yet."}, indent=2), encoding="utf-8")
(SNAP / "README.md").write_text("# GRID26 计时协议封存\n\nGRID25的四条试点保存数据审计通过，但其逐观测方法绑定增加对象循环引用；不把测量开销变化算作真实提速。GRID26换成类方法统一计时，代理调用和输入不变，104项动作接口核对与生命周期检查通过。\n\nGRID26冻结四个开发周×四种方法×三次串行计时，共48条；每周每重复共享环境种子，方法位置均衡，完整控制计时内不含候选日志压缩或验解。总时间、搜索时间、CPU、尾延迟分别报告。新训练0、预留评价0。\n\n这里是正式回放前的协议快照，不是实验结果或提速保证。\n", encoding="utf-8")
docs = REPO / "docs"
state = docs / "RESEARCH_STATE.md"
body = state.read_text(encoding="utf-8")
header, rest = body.split("\n", 1)
state.write_text(header+"\n\n- **当前：GRID26 串行提速核验**。模型和GRID24保护不变；48条完整开发回放的计时协议及104项接口核对已冻结。GRID25四条试点因对象生命周期测量问题仅作诊断，不认证提速；全部结果保留，质量没有失效。GRID26正式轨迹尚未开始。\n"+rest, encoding="utf-8")
next_steps = docs / "NEXT_STEPS.md"
body = next_steps.read_text(encoding="utf-8")
body = body.replace("GRID24质量补强完成，没有未结作业。", "GRID24质量补强完成；当前推进GRID26统一串行计时，先四条工程试点，再按冻结矩阵完成其余44条并审计。")
next_steps.write_text(body, encoding="utf-8")
with (docs / "EXPERIMENT_LOG.md").open("a", encoding="utf-8") as f:
    f.write("\n## 2026-10-10 — Controlled timing protocol and measurement repair\n\nGRID25: four March pilot trajectories,8068 physical steps,48319 public forecasts, saved-data audit passed; original models and costs retained. Per-observation simulate restoration can create a bound-method reference cycle, so timings are diagnostic and remaining44 were not started. This does not establish the cause of runtime variation. GRID26 freezes48 serial runs (four development weeks/four methods/three balanced repeats) with a class-level timer.104 prior-state equivalence checks,67276 fake feedback dispatches and a direct lifecycle test pass; no new AC queries or fits in preflight. [Immutable protocol](../research_archive/power-grid-2026/protocols/GRID26_before_runs/README.md).\n")
with (docs / "DECISIONS.md").open("a", encoding="utf-8") as f:
    f.write("\n## 2026-10-10 — Benchmark actual control cost without audit overhead\n\nHuman authorized continued speed validation. Preserve weights/rules and use balanced serial repetitions with candidate archival/verification outside act time. Remove per-instance method-binding measurement cycles before formal repetitions. Keep GRID25 diagnostic rather than selecting its favorable timings. Report source-search acceleration separately from total-control acceleration; do not attribute non-search variation to GNN. Reserved8 date families remain unopened until protocol is finalized.\n")
readme=ARCHIVE/"README.md"
readme.write_text("[当前 GRID26 提速核验协议（尚无正式结果）](protocols/GRID26_before_runs/README.md)\n\n"+readme.read_text(encoding="utf-8"),encoding="utf-8")
print(json.dumps({"protocol_files":len(records),"formal_rollouts_started":0,"fits":0}))
