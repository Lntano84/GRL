"""Correct a narrative count; measured outputs and frozen sources unchanged."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];REPO=ROOT/'work/GRL-results-integration'
ARCH=REPO/'research_archive/power-grid-2026';R=json.loads((ROOT/'outputs/grid29c/review.json').read_text())
counts=[p['matched_solver_calls'] for p in R['solver_path_comparisons']];assert counts==[340,340]
for p in [REPO/'docs/RESEARCH_STATE.md',REPO/'docs/EXPERIMENT_LOG.md',ARCH/'README.md']:
    text=p.read_text(encoding='utf-8');assert '682个配对solver' in text
    p.write_text(text.replace('682个配对solver','680个配对solver'),encoding='utf-8')
note='''# GRID29C 计数文案更正

两组各340个实际控制中的显式solver调用：153 DC +153安全QP +34作者QP。配对合计680，不是682。前一归档摘要把初始化DC混入了文字总计，但review.json逐组计数一直是340/340，完整组件与速度数值未改变。

修正仅更新摘要，保留原归档helper源码，不重跑科学实验或覆盖冻结文件。
'''
(ARCH/'protocols/GRID29C_completed/COUNT_CORRECTION.md').write_text(note,encoding='utf-8')
p=REPO/'docs/EXPERIMENT_LOG.md';p.write_text(p.read_text(encoding='utf-8')+'\n## GRID29C narrative count correction\n\n340+340=680paired explicit in-control solver calls; earlier682 narrative included initial DC incorrectly. Raw per-run statistics/review unchanged, no replay.\n',encoding='utf-8')
print(json.dumps({'correct_count':sum(counts),'raw_results_changed':False}))
