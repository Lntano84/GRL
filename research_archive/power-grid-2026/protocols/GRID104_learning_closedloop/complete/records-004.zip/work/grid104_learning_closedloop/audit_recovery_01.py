"""Recover failed result serialization, preserving original audit checks and frozen sources.

Only changes: serialize NumPy scalar values, load each immutable NPZ member once,
and emit progress after a fully checked run. No benchmark, training or forecasts.
"""
import json,os
import numpy as np
import registry as R

def scalar(value):
    if isinstance(value,np.generic):return value.item()
    raise TypeError(type(value).__name__)

def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp')
    with tmp.open('w',encoding='utf8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False,default=scalar)
        f.write('\n');f.flush();os.fsync(f.fileno())
    tmp.replace(path)

def main():
    assert not (R.OUT/'review.json').exists(),'Never repeat an accepted audit'
    assert json.loads(json.dumps(dict(n=np.int64(3),b=np.bool_(True),f=np.float64(.5)),default=scalar))==dict(n=3,b=True,f=.5)
    plan=R.read(R.OUT/'recovery_01.json')
    for path,h in plan['benchmark_files'].items():assert R.sha(R.ROOT/path)==h,path
    R.verify();R.save=save
    original=R.W/'audit.py';code=original.read_text(encoding='utf8')
    assert R.sha(original)==plan['frozen_audit_sha256']
    old="with np.load(folder/'vectors.npz') as z:"
    new="with np.load(folder/'vectors.npz') as zfile:\n                z={k:zfile[k] for k in ('action','observation')}"
    assert code.count(old)==1;code=code.replace(old,new)
    mark="runrows.append(row);checks['steps']+=len(rs)"
    addition=mark+"\n            save(OUT/'audit_recovery_progress.json',dict(validated_runs=len(runrows),planned=48,week=s['week'],method=s['method'],repeat=s['repeat'],checks=dict(checks)))\n            print('Validated saved run '+str(len(runrows))+'/48',flush=True)"
    assert code.count(mark)==1;code=code.replace(mark,addition)
    exec(compile(code,str(original),'exec'),{'__file__':str(original),'__name__':'__main__'})
    assert R.read(R.OUT/'review.json')['passed_saved_data']
    save(R.OUT/'recovery_01_audit_receipt.json',dict(passed=True,
        original_sources_unchanged=True,benchmark_files_unchanged=True,all_original_assertions_preserved=True,
        numpy_scalar_serializer_qualified=True,npz_member_cache_only=True,
        new_benchmark_runs=0,new_model_fits=0,new_forecasts=0,final_test_materialized=False,
        review_sha256=R.sha(R.OUT/'review.json'),decision_sha256=R.sha(R.OUT/'decision.json')))

if __name__=='__main__':main()
