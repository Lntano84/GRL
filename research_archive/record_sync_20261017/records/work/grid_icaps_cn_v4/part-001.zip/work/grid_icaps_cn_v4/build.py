from pathlib import Path
from copy import deepcopy
import sys,json,hashlib,re,csv,statistics
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from content import *

ROOT=Path('D:/Codex/GRL研究');OUT=ROOT/'outputs/grid_icaps_cn_v4';WORK=Path(__file__).resolve().parent
SOURCE=ROOT/'outputs/grid_icaps_v3/ICAPS2027_中文方法修订稿_V3.docx'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
originals=[SOURCE,ROOT/'outputs/grid_icaps_cn_v2/ICAPS2027_中文重写稿_v2.docx',ROOT/'outputs/grid_icaps_v3/ICAPS2027_English_Methods_V3.docx']
hashes={str(p):sha(p) for p in originals}
doc=Document(SOURCE);body=doc._element.body
start=next(p for p in doc.paragraphs if p.text=='2 方法')
end=next(p for p in doc.paragraphs if p.text=='3 实验')
method_nodes=[deepcopy(e) for e in list(body)[body.index(start._p):body.index(end._p)]]
method_hash=hashlib.sha256(b''.join(e.xml.encode() for e in method_nodes)).hexdigest()
# The prose refers to formula 2; attach visible numbers without changing math.
equation_count=0
for e in method_nodes:
 for equation in e.xpath('.//m:oMath'):
  equation_count+=1
  run=OxmlElement('m:r');pr=OxmlElement('m:rPr');pr.append(OxmlElement('m:nor'));run.append(pr)
  tx=OxmlElement('m:t');tx.set(qn('xml:space'),'preserve');tx.text=f'   （{equation_count}）';run.append(tx);equation.append(run)
assert equation_count==3
for e in list(body):
 if e.tag!=qn('w:sectPr'):body.remove(e)
section=doc.sections[0]
section.page_width=Cm(21);section.page_height=Cm(29.7)
section.top_margin=section.bottom_margin=Cm(2.1);section.left_margin=section.right_margin=Cm(2.2)
styles={'Normal':('宋体',11.5),'Title':('黑体',19),'Heading 1':('黑体',15),'Heading 2':('黑体',13),'Caption':('宋体',10)}
for name,(font,size) in styles.items():
 st=doc.styles[name];st.font.name='Arial';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0)
 st._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),font)
 st.paragraph_format.space_after=Pt(7)
 if name=='Normal':st.paragraph_format.line_spacing=1.25
for sec in doc.sections:
 for p in sec.header.paragraphs:p.clear()
 for p in sec.footer.paragraphs:p.clear()
 p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 f=OxmlElement('w:fldSimple');f.set(qn('w:instr'),'PAGE');p._p.append(f)

md=[];tables=[]
def para(text,style=None):
 p=doc.add_paragraph(text,style=style);p.paragraph_format.widow_control=True
 md.append(('# ' if style=='Title' else '## ' if style=='Heading 1' else '### ' if style=='Heading 2' else '- ' if style=='List Bullet' else '')+text+'\n')
 return p
def table(caption,headers,rows,widths):
 p=para(caption,'Caption');p.paragraph_format.keep_with_next=True
 t=doc.add_table(rows=1,cols=len(headers));t.style='Table Grid';t.autofit=False
 for i,h in enumerate(headers):t.rows[0].cells[i].text=h;t.columns[i].width=Cm(widths[i])
 for values in rows:
  cells=t.add_row().cells
  for i,v in enumerate(values):cells[i].text=str(v);cells[i].width=Cm(widths[i])
 for n,row in enumerate(t.rows):
  pr=row._tr.get_or_add_trPr();no=OxmlElement('w:cantSplit');pr.append(no)
  if n==0:rep=OxmlElement('w:tblHeader');pr.append(rep)
  frame='FRAME' in [c.text for c in row.cells]
  for c in row.cells:
   for p in c.paragraphs:
    if len(rows)<=4:p.paragraph_format.keep_with_next=n<len(t.rows)-1
    p.paragraph_format.space_after=Pt(4);p.paragraph_format.space_before=Pt(4);p.paragraph_format.line_spacing=1.1
    for r in p.runs:
     r.font.size=Pt(9.5);r.font.name='Arial';r._r.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'宋体');r.bold=n==0
   if n==0 or frame:
    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E9EEF1' if n==0 else 'EEF5F1');c._tc.get_or_add_tcPr().append(sh)
 md.append('| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(map(str,r))+' |' for r in rows)+'\n')
 tables.append({'caption':caption,'headers':headers,'rows':rows})
def figure(name,caption):
 p=doc.add_paragraph();p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(ROOT/f'outputs/grid_icaps_v3/figures/{name}.png'),width=Cm(16.4))
 p=para(caption,'Caption');p.alignment=WD_ALIGN_PARAGRAPH.LEFT
 md.append(f'![{caption}](../grid_icaps_v3/figures/{name}.png)\n')

def aggregate(stage,m):
 rows=list(csv.DictReader((ROOT/f'outputs/{stage}/per_run.csv').open(encoding='utf-8-sig')));vals=[]
 for w in sorted({r['week'] for r in rows}):
  f=[r for r in rows if r['week']==w and r['method']=='FULL'];a=[r for r in rows if r['week']==w and r['method']==m]
  avg=lambda rs,k:statistics.mean(float(r[k]) for r in rs)
  fq=avg(f,'n1_queries');aq=avg(a,'n1_queries')
  vals.append({'week':w,'queries':100*(1-aq/fq) if fq else None,'time':100*(1-avg(a,'controller_s')/avg(f,'controller_s')),'cost':100*(avg(a,'cost')/avg(f,'cost')-1) if all(r['complete']=='True' for r in f+a) else None})
 return {'time':statistics.mean(r['time'] for r in vals),'queries':statistics.mean(r['queries'] for r in vals if r['queries'] is not None),'cost':max(r['cost'] for r in vals if r['cost'] is not None),'dates':vals}
aggregates={stage:{m:aggregate(stage,m) for m in ['FULL','FIRST_SAFE_BEST','NO_LOCAL','FRAME']} for stage in ['grid61','grid62']}
def items(values):
 for x in values:
  if isinstance(x,str):para(x);continue
  k,v=x
  if k=='bullet':para(v,'List Bullet')
  elif k=='h2':para(v,'Heading 2')
  elif k=='policy_table':table('表1 共享排序与控制底座下的搜索策略',['策略','候选评估与返回规则'],[
   ['FULL','评估全部合法代表，返回预测奖励最高的可接纳候选。'],
   ['FIRST_SAFE_BEST','逐项评估，首个可接纳且预测负载率低于0.9的候选即返回；池耗尽时保留最佳可接纳项。'],
   ['NO_LOCAL','执行与FRAME相同的渐进评估和停止规则，关闭变电站补全。'],
   ['FRAME','渐进评估停止后，按条件补查当前最佳候选所属变电站的剩余配置。']], [3.6,13.0])
  elif k=='results_figure':figure('results','图3 搜索工作量、实际控制时间与完整周质量。左图比较候选查询减少；中图显示确认日期的两次原始计时和均值；右图比较各组最大完整周成本变化，虚线表示0.5%质量上限。FIRST表示FIRST_SAFE_BEST，斜线柱表示确认组。')
  elif k=='results_table':
   rows=[]
   for stage,label in [('grid61','开发'),('grid62','确认')]:
    for m,a in aggregates[stage].items():rows.append([label,m,f"{a['queries']:.2f}%",f"{a['time']:.2f}%",f"{a['cost']:+.3f}%"])
   table('表2 相对FULL的质量与计算结果',['组别','策略','查询减少','控制时间减少','最大整周成本变化'],rows,[1.3,3.5,3.1,3.8,4.9])
   para('查询均值排除FULL零查询日期；控制时间先平均同日期的两次重复，再对日期等权平均。成本仅在双方完成整周时计算。正的成本变化表示增加，负的时间减少表示变慢。','Caption')
  elif k=='dates_table':table('表3 FRAME的全部冻结确认日期',['日期','运行结果','整周成本变化','控制时间减少','查询 FULL→FRAME'],[
   ['2035-04-09_3','2017步，完成','−1.328%','4.080%','5445→1012'],
   ['2035-05-14_14','747步，提前结束','—','1.758%','0→0'],
   ['2035-11-19_0','2017步，完成','+0.014%','12.419%','2680→384']], [3.2,3.2,3.0,3.1,4.1])
  elif k=='case_figure':figure('completion_case','图4 局部补全找回排序前缀遗漏的动作。左图对应3月第1733步：FRAME在256次全局查询后增加198次同站查询，选中与FULL相同的动作309。右图对应3月完整周，展示去补全与完整框架的成本变化。')

para(TITLE,'Title');para('摘要','Heading 1');para(ABSTRACT);para('关键词：电网拓扑控制；在线搜索；计算分配；变电站补全')
para('1 引言','Heading 1');items(INTRO)
figure('motivation','图1 全局排名中的同站配置可能交错出现。完整搜索逐项比较全部候选；前缀停止留下排序后部的同站配置；FRAME在扩展停止后完成选定变电站内的剩余比较。该图表示搜索组织方式。')
for e in method_nodes:body.insert(len(body)-1,deepcopy(e))
md.append((ROOT/'outputs/grid_icaps_v3/Methods_中文.md').read_text(encoding='utf-8').replace('(figures/method.png)','(../grid_icaps_v3/figures/method.png)')+'\n')
para('3 实验','Heading 1');para('3.1 实验设置','Heading 2');items(SETUP)
para('3.2 评价指标与统计方式','Heading 2');items(METRICS)
para('3.3 质量保持与查询减少','Heading 2');items(MAIN)
para('3.4 变电站补全消融','Heading 2');items(ABLATION)
para('3.5 动作级案例分析','Heading 2');items(CASE)
para('3.6 实际计算开销与运行差异','Heading 2');items(EFFICIENCY)
para('4 结论','Heading 1');para(CONCLUSION)
para('5 相关工作','Heading 1');items(RELATED)
para('6 局限','Heading 1');items(LIMITS)
para('参考文献','Heading 1')
for text in REFERENCES:
 p=para(text);p.paragraph_format.first_line_indent=Pt(-15);p.paragraph_format.left_indent=Pt(15)
doc.core_properties.author='';doc.core_properties.last_modified_by='';doc.core_properties.title=TITLE
OUT.mkdir(exist_ok=True);dest=OUT/'ICAPS2027_中文全文修订稿_V4.docx';doc.save(dest)
(OUT/'ICAPS2027_中文全文修订稿_V4.md').write_text('\n'.join(md),encoding='utf-8')
assert all(sha(Path(p))==h for p,h in hashes.items())
receipt={'source_hashes_unchanged':hashes,'method_prose_and_mathematics_preserved':True,'method_change':'Added visible equation numbers 1-3 only','method_source_body_sha256':method_hash,'new_scientific_runs':0,'new_model_fits':0,'english_manuscripts_generated':0,'aggregation':'mean within-date repeats then equal-weight date ratios','aggregates':aggregates,'tables':tables,'output_sha256':sha(dest)}
(OUT/'revision_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(dest)
