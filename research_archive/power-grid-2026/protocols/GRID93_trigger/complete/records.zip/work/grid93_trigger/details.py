"""Locate the first actual divergence of every lost-quality case."""
from pathlib import Path
import gzip,hashlib,json
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/grid93_trigger'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))


def main():
    R=read(OUT/'review.json');D=read(OUT/'design.json');cases=[]
    for entry in [r for r in R['comparisons'] if r['lost_quality']]:
        ref=next(r for r in D['references'] if r['week']==entry['week'])
        folders=[ROOT/ref['frame'],OUT/'runs'/f"r0__{entry['week']}__SUPPORT_GATE"]
        rows=[]
        for folder in folders:
            with gzip.open(folder/'steps.jsonl.gz','rt',encoding='utf-8') as f:rows.append([json.loads(s) for s in f])
        j=next(j for j,(a,b) in enumerate(zip(*rows)) if a['action_hash']!=b['action_hash'])
        keys=['before_hash','action_hash','after_hash','raw_cost']
        assert all([a[k] for k in keys]==[b[k] for k in keys] for a,b in zip(rows[0][:j],rows[1][:j]))
        assert rows[0][j]['before_hash']==rows[1][j]['before_hash']
        matches=[]
        for folder in folders:
            pp=[(p,read(p)) for p in sorted(folder.glob('call[0-9][0-9][0-9].json'))]
            at=[(p,c) for p,c in pp if c['step']==rows[0][j]['step']];assert len(at)==1;matches.append(at[0])
        (pa,a),(pb,b)=matches;truth={r['pool_id']:r for r in a['outcomes']}
        assert b['chosen_pool_id']==a['pre_extra_choice'] and b['trigger_support']['veto']
        no=read(ROOT/'outputs/grid91_mechanism/runs'/f"r0__{entry['week']}__NO_LOCAL_FINAL"/'summary.json')
        cases.append(dict(comparison=entry,first_action_divergence_step=rows[0][j]['step'],same_physical_prefix=True,
                          original_choice=a['chosen_pool_id'],gated_choice=b['chosen_pool_id'],
                          old_candidate=truth[a['pre_extra_choice']],completed_candidate=truth[a['chosen_pool_id']],
                          original_local_queries=a['local_queries'],gate_support=b['trigger_support'],
                          first_frame_step=rows[0][j],first_gate_step=rows[1][j],gate_last_step=rows[1][-1],
                          historical_no_local_complete=no['complete'],historical_no_local_steps=no['steps'],
                          sources=[dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [pa,pb,folders[0]/'steps.jsonl.gz',folders[1]/'steps.jsonl.gz']]))
    (OUT/'failure_analysis.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(cases=len(cases),first_divergences=[c['first_action_divergence_step'] for c in cases])))


if __name__=='__main__':main()
