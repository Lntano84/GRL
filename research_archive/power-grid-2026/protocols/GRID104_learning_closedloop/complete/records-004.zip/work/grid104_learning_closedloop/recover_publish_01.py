"""Continue only the failed saved-data audit and publication; cannot launch benchmarks."""
import ctypes,os,subprocess,sys,traceback
import registry as R

def main():
    assert not (R.OUT/'complete.json').exists()
    R.verify();assert R.read(R.OUT/'finished.json')['runs']==48
    K=ctypes.windll.kernel32;K.CreateMutexW.restype=ctypes.c_void_p
    mutex=K.CreateMutexW(None,True,'GRL_GRID104_RECOVERY_PUBLICATION')
    assert K.GetLastError()!=183,'Another recovery exists'
    K.SetThreadExecutionState(0x80000001)
    try:
        for phase,script in [('audit_recovery','audit_recovery_01.py'),('finalize','finalize.py'),('archive','archive.py')]:
            R.save(R.OUT/'pipeline_state.json',dict(phase=phase,pid=os.getpid(),completed=48,planned=48,utc=R.utc(),recovery='serialization_01'))
            with (R.OUT/f'{phase}_resume01.log').open('x',encoding='utf8') as log:
                subprocess.run([sys.executable,'-u',str(R.W/script)],cwd=R.ROOT,stdout=log,stderr=subprocess.STDOUT,
                    check=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=1800)
        environment=os.environ.copy();environment['TEMP']=str(R.ROOT/'tmp/grid100');environment['TMP']=environment['TEMP']
        status=subprocess.check_output(['git','-C',str(R.REPO),'status','--porcelain'],text=True)
        allowed=['docs/','research_archive/power-grid-2026/protocols/GRID104_learning_closedloop/','research_archive/power-grid-2026/README.md']
        assert all(any(line[3:].startswith(p) for p in allowed) for line in status.splitlines()),'Unrelated Git changes'
        with (R.OUT/'push_resume01.log').open('x',encoding='utf8') as log:
            subprocess.run([str(R.REPO/'scripts/git_push.cmd'),'Publish GRID104 development results and serialization recovery'],cwd=R.REPO,
                stdout=log,stderr=subprocess.STDOUT,env=environment,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
        head=subprocess.check_output(['git','-C',str(R.REPO),'rev-parse','HEAD'],text=True).strip()
        remote=subprocess.check_output(['git','-C',str(R.REPO),'ls-remote','lntano-src','refs/heads/main'],text=True).split()[0]
        assert head==remote
        decision=R.read(R.OUT/'decision.json')
        R.save(R.OUT/'complete.json',dict(passed=True,git_sha=head,remote_verified=True,ready_to_scale=decision['ready_to_scale'],
            report='outputs/grid104_learning_closedloop/GRID104_report.md',final_test_materialized=False,new_model_fits=0,
            recovery='serialization_01',utc=R.utc()))
        R.save(R.OUT/'pipeline_state.json',dict(phase='complete',completed=48,planned=48,ready_to_scale=decision['ready_to_scale'],git_sha=head,utc=R.utc()))
        (R.OUT/'RUN_STATE.md').write_text('COMPLETE:48 original runs retained; original-assertion saved audit recovered, report/archive/push done; no scaling.\n',encoding='utf8')
    finally:
        K.SetThreadExecutionState(0x80000000);K.ReleaseMutex.argtypes=[ctypes.c_void_p];K.CloseHandle.argtypes=[ctypes.c_void_p]
        K.ReleaseMutex(mutex);K.CloseHandle(mutex)
if __name__=='__main__':
    try:main()
    except BaseException:R.save(R.OUT/'recovery_01_error.json',dict(utc=R.utc(),traceback=traceback.format_exc()));raise
