RUNNING sealed 72/72; one serial worker; all outcomes retained.
