"""One finite serial run, audit, report and publication; no adaptive extensions."""
from pathlib import Path
import ctypes,datetime as dt,gzip,hashlib,json,os,subprocess,sys,time,traceback
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid91_mechanism';REPO=ROOT/'work/GRL-results-integration'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))


def save(name,x):
    p=OUT/name;t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8');os.replace(t,p)


def verify_freeze():
    for name in ['code_freeze.json','data_freeze.json']:
        for rel,want in read(OUT/name).items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==want,rel


def validate(folder,result):
    s=read(folder/'summary.json');assert s==read(result)
    for name in ['components.json','vectors.npz','metadata.json']:assert (folder/name).exists()
    with gzip.open(folder/'steps.jsonl.gz','rt',encoding='utf-8') as f:assert sum(1 for _ in f)==s['steps']
    return s


def main():
    assert not (OUT/'complete.json').exists()
    mutex=ctypes.windll.kernel32.CreateMutexW(None,True,'GRL_GRID91_SERIAL_MECHANISM')
    assert ctypes.windll.kernel32.GetLastError()!=183,'Another GRID91 runner exists'
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:
        verify_freeze();D=read(OUT/'design.json');start=time.perf_counter()
        summaries=read(OUT/'manifest.json')['summaries'];existing={(s['week'],s['method']) for s in summaries}
        for index,item in enumerate(D['execution_order']):
            if (item['week'],item['method']) in existing:continue
            assert time.perf_counter()-start<D['caps']['wall_s']
            folder=OUT/'runs'/f"r0__{item['week']}__{item['method']}";result=OUT/f'worker_result_{index:02d}.json'
            if folder.exists():
                if result.exists():
                    s=validate(folder,result);summaries.append(s);existing.add((s['week'],s['method']));save('manifest.json',dict(planned=28,summaries=summaries));continue
                raise RuntimeError(f'Partial output needs recovery review; never delete or rerun complete items: {folder}')
            save('pipeline_state.json',dict(phase='benchmark',pid=os.getpid(),completed=len(summaries),planned=28,index=index,item=item,utc=dt.datetime.now(dt.timezone.utc).isoformat()))
            with (OUT/f'worker_{index:02d}.log').open('x',encoding='utf-8') as log:
                child=subprocess.Popen([sys.executable,'-u',str(W/'worker.py'),'--index',str(index)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                save('active_worker.json',dict(pid=child.pid,parent=os.getpid(),index=index,item=item))
                try:ret=child.wait(timeout=D['caps']['episode_s']+120)
                except subprocess.TimeoutExpired:
                    subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT);child.wait();raise
            assert ret==0,(index,ret)
            s=validate(folder,result);summaries.append(s);existing.add((s['week'],s['method']))
            assert sum(x['steps'] for x in summaries)<=D['caps']['physical_steps']
            assert sum(x['public_forecasts'] for x in summaries)<=D['caps']['public_forecasts']
            if item['purpose']=='environment_qualification':
                # Fail before deletion tests if a cohort's old controller path did not reproduce.
                from audit import trajectory_signature
                ref=next(r for r in D['references'] if r['week']==s['week'])
                assert trajectory_signature(folder)==trajectory_signature(ROOT/ref['frame']),'Qualification trajectory mismatch'
            save('manifest.json',dict(planned=28,summaries=summaries))
            print(json.dumps(dict(completed=len(summaries),planned=28,method=s['method'],week=s['week'])),flush=True)
        save('finished.json',dict(passed_engineering=True,runs=28,summaries=summaries))
        for phase,script in [('audit','audit.py'),('finalize','finalize.py'),('archive','archive.py')]:
            save('pipeline_state.json',dict(phase=phase,pid=os.getpid(),completed=28,planned=28))
            with (OUT/f'{phase}_pipeline.log').open('a',encoding='utf-8') as log:
                subprocess.run([sys.executable,'-u',str(W/script)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
        with (OUT/'push_pipeline.log').open('a',encoding='utf-8') as log:
            subprocess.run([str(REPO/'scripts/git_push.cmd'),'Publish final FRAME mechanism deletion audit'],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
        head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
        remote=subprocess.check_output(['git','-C',str(REPO),'ls-remote','lntano-src','refs/heads/main'],text=True).split()[0]
        assert head==remote
        save('complete.json',dict(passed=True,git_sha=head,remote_verified=True,report='outputs/grid91_mechanism/GRID91_report.md',review='outputs/grid91_mechanism/review.json'))
        save('pipeline_state.json',dict(phase='complete',pid=os.getpid(),completed=28,planned=28,git_sha=head))
        (OUT/'RUN_STATE.md').write_text('COMPLETE:28 runs, saved-data audit, mechanism verdict and publication; no second-grid or learning work started.\n',encoding='utf-8')
    finally:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        ctypes.windll.kernel32.ReleaseMutex(mutex);ctypes.windll.kernel32.CloseHandle(mutex)


if __name__=='__main__':
    try:main()
    except BaseException:
        save('pipeline_error.json',dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(),traceback=traceback.format_exc()));raise
