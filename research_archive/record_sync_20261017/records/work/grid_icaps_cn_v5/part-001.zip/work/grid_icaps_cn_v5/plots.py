"""Publication-size vector charts, generated only after frozen timing finishes."""
from pathlib import Path
import csv,json,statistics
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/grid_icaps_cn_v5';FIG=OUT/'figures'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def csvread(p):
 with p.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def val(x):return None if x in ('','None',None) else float(x)
def save(fig,name):
 for ext in ['svg','pdf','png']:fig.savefig(FIG/f'{name}.{ext}',dpi=300,bbox_inches='tight')
 plt.close(fig)
def main():
 assert all((ROOT/f'outputs/grid{x}/review.json').exists() for x in (67,68))
 assert not any((ROOT/f'outputs/grid{x}/RUN.lock').exists() for x in (67,68))
 FIG.mkdir(parents=True,exist_ok=True)
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'xtick.labelsize':9,'ytick.labelsize':9,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.axisbelow':True})
 blue='#4C7899';green='#5B8E7D';sand='#C09764';gray='#9AA4AE';red='#A45757'
 fresh=csvread(ROOT/'outputs/grid68/per_family.csv');a=[x for x in fresh if x['method']=='FRAME'];x=np.arange(len(a));labels=[r['date'][5:10] for r in a]
 fig,axs=plt.subplots(1,3,figsize=(7.2,2.65))
 for ax,key,title in zip(axs,['query_reduction_full','time_reduction_full','cost_delta_full'],['(a) N-1 query saving','(b) Controller time saving','(c) Full-week cost change']):
  for i,row in enumerate(a):
   v=val(row[key])
   if v is None:ax.text(i,0,'N/A',ha='center',va='bottom',rotation=90,color=gray,fontsize=7)
   else:ax.bar(i,100*v,width=.62,color=blue if key!='cost_delta_full' else green if v<=.005 else red)
  ax.axhline(0,color='#59636C',lw=.6);ax.set_xticks(x,labels,rotation=45,ha='right');ax.set_title(title);ax.set_ylabel('% relative to FULL');ax.grid(axis='y',color='#E5E8EB',lw=.6)
  if key=='cost_delta_full':
   ax.axhline(.5,color=red,ls='--',lw=.9);ax.text(.02,.5,'0.5% limit',transform=ax.get_yaxis_transform(),fontsize=8,va='bottom',color=red)
 fig.tight_layout(w_pad=1.5);save(fig,'fresh_scenes')
 old=csvread(ROOT/'outputs/grid66/historical_date_metrics.csv');fig,axs=plt.subplots(1,2,figsize=(7.2,2.9),gridspec_kw={'width_ratios':[.9,1.4]})
 labels2=['FULL','FRAME'];bottom=np.zeros(2)
 categories=[('N-1 candidate forecasts',['n1_forecast_s_mean'],blue),('Other forecasts',['other_forecast_s_mean'],sand),('Continuous / restoration QPs',['dc_s_mean','safe_qp_s_mean','unsafe_qp_s_mean'],green),('Other control',['other_control_s_mean'],gray)]
 for name,keys,color in categories:
  values=[statistics.mean(sum(float(r[k]) for k in keys) for r in old if r['method']==m) for m in labels2]
  axs[0].bar(labels2,values,bottom=bottom,color=color,label=name,width=.55);bottom+=values
 axs[0].set_ylabel('Controller time (s/date)');axs[0].set_title('(a) Control computation');axs[0].legend(frameon=False,fontsize=8,loc='upper left',bbox_to_anchor=(0,-.2));axs[0].grid(axis='y',color='#E5E8EB',lw=.6)
 dates=list(dict.fromkeys(r['date'] for r in old));ys=np.arange(len(dates))
 for i,d in enumerate(dates):
  f=next(r for r in old if r['date']==d and r['method']=='FULL');g=next(r for r in old if r['date']==d and r['method']=='FRAME');v=val(f['search_p95_s_mean']);w=val(g['search_p95_s_mean'])
  if v is None:axs[1].text(.01,i,'No N-1 search',fontsize=8,color=gray);continue
  axs[1].plot([v,w],[i,i],color='#C9D0D6',lw=1.4);axs[1].scatter(v,i,color=gray,s=23,label='FULL' if i==0 else None);axs[1].scatter(w,i,color=blue,s=23,label='FRAME' if i==0 else None)
 axs[1].set_yticks(ys,[d[5:10] for d in dates]);axs[1].invert_yaxis();axs[1].set_xlim(left=0);axs[1].set_xlabel('Search-active decision P95 (s)');axs[1].set_title('(b) Tail latency on search steps');axs[1].legend(frameon=False,fontsize=8);axs[1].grid(axis='x',color='#E5E8EB',lw=.6)
 fig.tight_layout(w_pad=2);save(fig,'computation_latency')
 rows=read(ROOT/'outputs/grid67/review.json')['summaries'];methods=['FRAME_P64','FRAME','FRAME_P256','FRAME_S1','FRAME_S3'];labels3=['p=64','Default\np=128,H=2','p=256','H=1','H=3']
 fig,axs=plt.subplots(1,2,figsize=(7.2,2.7));pos=np.arange(5)
 for ax,key,title in zip(axs,['macro_query_reduction','max_complete_cost_delta'],['(a) Query saving across four dates','(b) Worst complete-week cost change']):
  values=[next(r for r in rows if r['method']==m)[key] for m in methods]
  for i,(m,v) in enumerate(zip(methods,values)):
   if v is not None:ax.bar(i,100*v,color=blue if m=='FRAME' else gray,width=.58)
  ax.set_xticks(pos,labels3);ax.set_ylabel('% relative to same-batch FULL');ax.set_title(title);ax.axhline(0,color='#59636C',lw=.6);ax.grid(axis='y',color='#E5E8EB',lw=.6)
  if key=='max_complete_cost_delta':ax.axhline(.5,color=red,ls='--',lw=.9)
 fig.tight_layout(w_pad=2);save(fig,'sensitivity')
 plan={'workflow':'Caption first, then data elements/axes, fixed panel layout, consistent method naming and low-saturation colors. Charts use actual date summaries; no synthetic error bars. Each SVG retains editable text; PDF is vector; PNG is 300dpi.',
 'figures':{'fresh_scenes':'Six newly evaluated local date families: retain quality, query and complete-controller effects separately; missing full-week comparisons marked N/A.','computation_latency':'Candidate prediction is a component of controller cost; continuous/restoration work remains, and tail latency is measured on actual search-active steps.','sensitivity':'Single-axis prefix/patience variants are reported without choosing a replacement default.'},'legacy_figures':'Retain V3 editable motivation/method/case assets; captions treat structural completion as procedure and a specific case, not unique causal superiority.',
 'source_tables':['outputs/grid68/per_family.csv','outputs/grid66/historical_date_metrics.csv','outputs/grid67/review.json'],'publication_width_inches':7.2,'font_pt':9,'docx_insertion_width_cm':16.4}
 (OUT/'figure_workflow.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Three scientific figures exported in SVG/PDF/PNG.')
if __name__=='__main__':main()
