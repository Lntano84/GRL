"""Predeclare the finite deletion test and verify existing assets; no new fits."""
from pathlib import Path
import datetime as dt, gzip, hashlib, importlib.util, json, sys
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid91_mechanism'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def save(name,obj):
    (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def load(name,path):
    s=importlib.util.spec_from_file_location(name,ROOT/path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m


def signature(g):
    return ([ (r['pool_id'],r['phase']) for r in g['outcomes']],g['chosen_pool_id'],
            g['stop_reason'],g['shortlist_choice'],g['completion_candidate_ids'],g['events'])


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    assert not (OUT/'design.json').exists(),'Never overwrite a frozen protocol'
    P=load('grid91_preflight', 'work/grid91_mechanism/policies.py')
    R=load('grid91_original', 'work/grid70/policies.py')
    V=load('grid91_parameterized', 'work/grid89_review/policies.py')
    I=load('grid91_independent', 'work/grid89_review/reference_logic.py')
    with gzip.open(ROOT/'outputs/grid85_mechanism/mechanism_feedback.json.gz','rt',encoding='utf-8') as f:pack=json.load(f)
    cases=[]
    for source,c in pack['records'].items():
        cc=dict(c,outcomes=[dict(zip(pack['fields'],r)) for r in c['outcomes']])
        cases.append((source,cc))
    for p in sorted((ROOT/'outputs/grid89_review/sealed/runs').glob('r0__*__FULL/call[0-9][0-9][0-9].json')):
        cases.append((p.relative_to(ROOT).as_posix(),read(p)))
    checked=hidden=none_checked=0
    for source,c in cases:
        truth={r['pool_id']:r for r in c['outcomes']};aliases={int(k):int(v) for k,v in c['aliases'].items()}
        def execute(module,policy,table):
            seen=[]
            def reveal(i,phase):
                assert i in table and i not in seen;seen.append(i);return dict(table[i],phase=phase)
            return module.run(c['order'],reveal,policy,pack['subids'],aliases,limit=c['rho_limit'])
        a=execute(P,'FRAME_GUARD',truth);b=execute(R,'FRAME_GUARD',truth)
        assert signature(a)==signature(b),source;checked+=1
        no=execute(P,'NO_LOCAL',truth);oldno=execute(V,'NO_LOCAL',truth)
        assert signature(no)==signature(oldno),source
        plan,choice,budget=I.replay(c['order'],truth,pack['subids'],aliases,'NO_LOCAL',dict(V.DEFAULT,qmin=0))
        assert plan==[r['pool_id'] for r in no['outcomes']] and choice==no['chosen_pool_id'] and budget==no['completion_budget'];none_checked+=1
        if len(c['outcomes'])==len(c['order']):
            observed={r['pool_id'] for r in a['outcomes']}
            mutated={i:dict(r,reward=1e6,rho=.01,strict_admissible=True) if i not in observed else r for i,r in truth.items()}
            assert signature(execute(P,'FRAME_GUARD',mutated))==signature(a);hidden+=1
    assert checked==316
    boundary=0
    for n in [0,1,63,64,127,128,129,191,192,193,255,256,257,319,320,321,512,909,1000]:
        for pattern in ['flat_unsafe','flat_safe','late_gain','none_admissible','safe_after_192','continuing_gain']:
            truth={i:dict(pool_id=i,reward=float(i//64) if pattern=='continuing_gain' else 2. if pattern=='late_gain' and i==n-1 else 1.,rho=.8 if pattern=='flat_safe' or pattern=='safe_after_192' and i>=192 else 1.1,strict_admissible=pattern!='none_admissible') for i in range(n)}
            order=list(range(n));aliases={i:i for i in order};subs=[i%3 for i in order]
            for policy in ['FRAME_GUARD','NO_LOCAL']:
                outputs=[]
                for mod in [P,V]:
                    seen=set()
                    def reveal(i,phase):
                        assert i not in seen;seen.add(i);return dict(truth[i],phase=phase)
                    outputs.append(mod.run(order,reveal,policy,subs,aliases))
                assert signature(outputs[0])==signature(outputs[1]),(n,pattern,policy)
            boundary+=1

    groups=[('old13',ROOT/'outputs/grid70/design.json','weeks','work/grid03/formal_env_initialized',
             'outputs/grid88/runs','outputs/grid65/runs'),
            ('G1',ROOT/'outputs/grid81/design.json','weeks','work/grid80/fresh_env',
             'outputs/grid86/runs','outputs/grid81/runs'),
            ('G2',ROOT/'outputs/grid89_review/sealed/design.json','weeks','work/grid89_review/fresh_env',
             'outputs/grid89_review/sealed/runs','outputs/grid89_review/sealed/runs')]
    refs=[]
    for cohort,path,key,environment,framebase,fullbase in groups:
        for week in read(path)[key]:
            frame=ROOT/framebase/f'r0__{week}__FRAME_GUARD'
            full=ROOT/fullbase/f'r0__{week}__FULL'
            if not full.exists() and cohort=='old13':full=ROOT/'outputs/grid68/runs'/f'r0__{week}__FULL'
            for folder in [frame,full]:
                for name in ['summary.json','steps.jsonl.gz','vectors.npz','metadata.json']:assert (folder/name).exists(),folder/name
            refs.append(dict(cohort=cohort,week=week,environment=environment,
                             frame=frame.relative_to(ROOT).as_posix(),full=full.relative_to(ROOT).as_posix()))
    assert len(refs)==25
    shared=dict(rule='STATIC_ID',budget=128,checkpoint=None,cache_dc=True,cache_safe=True,order_mode='STATIC_ID',repeat=0,stage_phase='all')
    items=[]
    for cohort in ['old13','G1','G2']:
        r=next(x for x in refs if x['cohort']==cohort)
        items.append(dict(shared,**{k:r[k] for k in ['cohort','week','environment']},method='FRAME_GUARD',policy='FRAME_GUARD',purpose='environment_qualification'))
    for r in refs:
        items.append(dict(shared,**{k:r[k] for k in ['cohort','week','environment']},method='NO_LOCAL_FINAL',policy='NO_LOCAL',purpose='completion_deletion'))
    design=dict(stage='GRID91_FINAL_MECHANISM_DELETION_AND_SIMPLIFICATION',frozen_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                authorization='2026-10-20 user: 把1做完后给我汇报，主要把昨天的几个问题解决好',
                parameters=P.DEFAULT,removed_redundant_condition='qmin256, proven default-equivalent; no other threshold/order/model change',
                references=refs,weeks=[r['week'] for r in refs],execution_order=items,
                planned_new_replays=28,qualification_replays=3,deletion_replays=25,
                timing='Single fresh serial replay; full-controller timers retained for description. Historical FRAME is reused for deterministic quality/query comparison only; no new cross-batch timing advantage claimed.',
                quality_threshold=.005,
                decision='Retain completion as a conditional quality safeguard if removal fails the pre-existing FULL quality threshold on any case passed by FRAME; otherwise do not claim it necessary for that threshold. Report every cost/survival/query benefit and regression, including cases where NO_LOCAL is cheaper or better. This finite exposed-data regression does not prove universal superiority. No tuning, resampling, replacement dates, or extra arms after results.',
                pending_beyond_scope=['second grid','proportional budget validation','CCMA training/comparison','learning or agent extension'],
                caps=dict(episode_s=1200,wall_s=10800,physical_steps=28*2017,public_forecasts=250000),
                environment='per item, exactly the recorded cohort source',new_fits=0,repeats=1)
    save('design.json',design)
    save('preflight.json',dict(passed=True,saved_frame_replays=checked,saved_no_local_independent=none_checked,
                               hidden_suffix_perturbations=hidden,boundary_cases=boundary,boundary_policy_pairs=boundary*2,known_short_pool_log_label_difference='Preserved historical labels; new core agrees with parameterized implementation on114 synthetic boundaries',
                               new_predictions=0,new_fits=0))
    codes=read(ROOT/'outputs/grid89_review/code_freeze.json')
    for p,h in codes.items():assert sha(ROOT/p)==h,p
    data=read(ROOT/'outputs/grid89_review/data_freeze.json')
    for p,h in data.items():assert sha(ROOT/p)==h,p
    # Preserve all original source assets and deterministic comparison records.
    for r in refs:
        for label in ['frame','full']:
            for p in (ROOT/r[label]).rglob('*'):
                if p.is_file():data[p.relative_to(ROOT).as_posix()]=sha(p)
    for p in W.glob('*.py'):codes[p.relative_to(ROOT).as_posix()]=sha(p)
    for name in ['design.json','preflight.json']:
        codes[(OUT/name).relative_to(ROOT).as_posix()]=sha(OUT/name)
    save('data_freeze.json',data)
    codes[(OUT/'data_freeze.json').relative_to(ROOT).as_posix()]=sha(OUT/'data_freeze.json')
    save('code_freeze.json',codes)
    save('manifest.json',dict(planned=28,summaries=[]))
    (OUT/'RUN_STATE.md').write_text('FROZEN: 3 FRAME environment qualification replays then25 NO_LOCAL deletion replays, serial. No fitting or new grids.\n',encoding='utf-8')
    print(json.dumps(dict(preflight=read(OUT/'preflight.json'),code_items=len(codes),data_items=len(data),planned=28),ensure_ascii=False))


if __name__=='__main__':main()
