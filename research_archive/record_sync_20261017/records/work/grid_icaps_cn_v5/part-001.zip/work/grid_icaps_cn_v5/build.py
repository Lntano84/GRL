"""New Chinese reading manuscript, preserve all earlier drafts and native method equations."""
from pathlib import Path
from copy import deepcopy
import csv,hashlib,json,math,shutil,statistics,sys
from docx import Document
from docx.shared import Cm,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/grid_icaps_cn_v5';SRC=ROOT/'outputs/grid_icaps_cn_v4/ICAPS2027_中文全文修订稿_V4.docx'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def csvread(p):
 with p.open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def fv(x):return None if x in ('',None,'None') else float(x)
def pct(x,d=2):return '—' if x is None else f'{100*x:+.{d}f}%'
def savejson(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def main():
 assert not any((ROOT/f'outputs/grid{s}/RUN.lock').exists() for s in [67,68])
 reviews={s:read(ROOT/f'outputs/grid{s}/review.json') for s in [65,67,68]};assert all(x['passed_saved_data'] for x in reviews.values())
 original_hash=sha(SRC);assert original_hash==read(Path(__file__).parent/'source_snapshot.json')['sha256'],'User source changed: re-read author edits before generating V5'
 doc=Document(SRC);body=doc._element.body
 start=next(p for p in doc.paragraphs if p.text=='2 方法');end=next(p for p in doc.paragraphs if p.text=='3 实验')
 method=[deepcopy(e) for e in list(body)[body.index(start._p):body.index(end._p)]]
 method_hash=hashlib.sha256(''.join(e.xml for e in method).encode()).hexdigest()
 refs=[];ref_start=False
 for p in doc.paragraphs:
  if p.text=='参考文献':ref_start=True;continue
  if ref_start and p.text.strip():refs.append(p.text)
 assert len(refs)==7
 for e in list(body):
  if e.tag!=qn('w:sectPr'):body.remove(e)
 OUT.mkdir(exist_ok=True);FIG=OUT/'figures';FIG.mkdir(exist_ok=True)
 for name in ['motivation','method','completion_case']:
  for ext in ['png','svg','pdf','drawio']:
   p=ROOT/f'outputs/grid_icaps_v3/figures/{name}.{ext}'
   if p.exists():shutil.copy2(p,FIG/p.name)
 md=[];tables=[]
 def para(t,style=None):
  p=doc.add_paragraph(t,style=style);p.paragraph_format.widow_control=True
  md.append(('# ' if style=='Title' else '## ' if style=='Heading 1' else '### ' if style=='Heading 2' else '- ' if style=='List Bullet' else '')+t+'\n');return p
 def table(caption,headers,rows,widths):
  p=para(caption,'Caption');p.paragraph_format.keep_with_next=True
  t=doc.add_table(rows=1,cols=len(headers));t.style='Table Grid';t.autofit=False
  for i,h in enumerate(headers):t.rows[0].cells[i].text=h;t.columns[i].width=Cm(widths[i])
  for values in rows:
   cells=t.add_row().cells
   for i,v in enumerate(values):cells[i].text=str(v);cells[i].width=Cm(widths[i])
  for j,row in enumerate(t.rows):
   pr=row._tr.get_or_add_trPr();pr.append(OxmlElement('w:cantSplit'))
   if j==0:pr.append(OxmlElement('w:tblHeader'))
   for ci,c in enumerate(row.cells):
    c.width=Cm(widths[ci])
    tc=c._tc.get_or_add_tcPr();b=OxmlElement('w:tcBorders')
    for edge in ['top','left','bottom','right']:
     z=OxmlElement('w:'+edge);z.set(qn('w:val'),'single');z.set(qn('w:sz'),'4');z.set(qn('w:color'),'D9D9D9');b.append(z)
    tc.append(b)
    if j==0:
     sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E9EEF1');tc.append(sh)
    for p in c.paragraphs:
     p.paragraph_format.space_before=Pt(4);p.paragraph_format.space_after=Pt(4);p.paragraph_format.line_spacing=1.08;p.paragraph_format.keep_with_next=j==0
     p.alignment=WD_ALIGN_PARAGRAPH.LEFT if ci==0 or len(c.text)>50 else WD_ALIGN_PARAGRAPH.CENTER
     for r in p.runs:r.font.size=Pt(9.3);r.bold=j==0
  md.append('| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(str(x).replace(chr(10),'<br>') for x in row)+' |' for row in rows)+'\n');tables.append({'caption':caption,'headers':headers,'rows':rows})
 def figure(name,caption):
  p=doc.add_paragraph();p.paragraph_format.keep_with_next=True;p.add_run().add_picture(str(FIG/(name+'.png')),width=Cm(16.4))
  para(caption,'Caption');md.append(f'![{caption}](figures/{name}.png)\n')
 old=reviews[65];fresh=reviews[68];sens=reviews[67]
 O=next(s for s in old['summaries'] if s['method']=='FRAME');N=next(s for s in fresh['summaries'] if s['method']=='FRAME')
 old_q=O['macro_query_reduction_full'];old_t=O['macro_time_reduction_full'];new_q=N['macro_query_reduction'];new_t=N['macro_time_reduction'];new_quality=N['quality_dates'];new_complete=N['complete_dates']
 title='FRAME：面向电网在线控制的反馈驱动渐进拓扑搜索'
 abstract=(f'电网在线控制通过预测仿真比较拓扑候选，逐项评估整个候选池会增加决策计算。本文提出FRAME，将查询反馈用于渐进扩展与停止，并通过一次同站配置补全保留已有搜索结果。框架共享原控制器的候选准入、连续优化和恢复逻辑，以更少预测查询产生拓扑提案。'
 f'在一个公开118变电站电网的13个日期上，既有七日期实验中，FRAME全部达到预设闭环质量标准，查询与实际控制时间分别减少{100*old_q:.2f}%和{100*old_t:.2f}%；新增六日期中，质量通过{new_quality}/6，其中一个日期提前结束。在新增组的五个等时域日期，查询与控制时间分别减少{100*new_q:.2f}%和{100*new_t:.2f}%。'
 '等预算全局扩展、论文来源自适应停止对照及参数实验进一步检验了质量、搜索范围与计算收益之间的关系。结果明确了该框架的查询压缩作用，也揭示了短前缀直接返回分支仍存在跨日期闭环质量风险。')
 para(title,'Title');para('作者阅读稿：包含GRID68新增场景质量失败，供修复与重写使用。','Caption');para('摘要','Heading 1');para(abstract);para('关键词：电网拓扑控制；渐进搜索；计算分配；闭环评价')
 para('1 引言','Heading 1')
 for t in [
 '电网拓扑控制通过改变线路、发电机和负荷的母线连接关系缓解拥塞。在线控制还需要协调再调度、弃电、储能与恢复操作，持续响应负荷和可再生发电变化。Grid2Op为这一序贯决策任务提供了公开环境和预测仿真接口[1]。候选评估需要调用潮流预测；减少实际派发的候选查询，是降低在线搜索计算的直接途径。',
 '混合控制与学习排序已经提供了高质量动作选择的基础。LJN结合拓扑决策和连续优化[2]；SoftGNN与相关图模型利用动作偏好及电网结构安排候选顺序[3,4]。排序之后还存在独立的计算决策：查询多少候选、何时停止，以及返回提案前再比较哪些配置。本文围绕这一层搜索组织展开。',
 '全局前缀可以较早找到有效动作，但固定的短前缀会遗漏后部候选；完整扫描则继续为大量未改变当前最佳结果的候选付费。FRAME先评估短前缀，再根据已经获得的奖励改善和预测负载率分批扩展。全局阶段结束后，框架固定当前最佳动作所在的变电站，补查其尚未查询的配置。所有新反馈都与当前最佳候选比较，已获得的有效结果始终保留。',
 '我们把FRAME接入现成混合控制器，在相同排序、动作准入、连续控制和预测接口下比较闭环结果。等预算全局扩展用于检验补查范围本身的增量，论文来源的元停止策略用于比较反馈驱动的计算分配。逐日期运行成本、存活、查询、完整控制时间与尾部延迟共同构成评价，避免将查询减少直接换算成整套控制提速。',
 f'既有七日期实验中，FRAME质量标准通过7/7，完整周完成5/7，与完整搜索一致；新增六日期通过{new_quality}/6、完成{new_complete}/6。本文还在四个开发日期上改变查询前缀与停滞批数，保持默认配置不变，检查对单个参数设置的依赖。'] :para(t)
 para('本文主要贡献如下：')
 for t in [
 '构建反馈驱动的渐进拓扑搜索框架，将候选准入、分批扩展、已有最佳结果保留和一次配置补全统一接入混合控制器；基于原始动作别名恢复物理等价合并后的结构归属。',
 '给出覆盖闭环质量、查询成本与实际控制计算的实证评价，通过等预算全局扩展、论文来源元停止、参数敏感性及新增日期检验框架作用，并定位连续优化与恢复带来的剩余计算开销。']:para(t,'List Bullet')
 figure('motivation','图1 候选查询的组织问题。完整搜索扫描整个代表池；前缀评估可能遗漏后部配置；FRAME通过反馈扩展与一次配置补查组织查询。图示解释算法流程，具体结构增量由等预算实验检验。')
 for e in method:body.insert(len(body)-1,deepcopy(e))
 md.append((ROOT/'outputs/grid_icaps_v3/Methods_中文.md').read_text(encoding='utf-8')+'\n')
 para('3 实验','Heading 1');para('3.1 实验对象与评价分组','Heading 2')
 para('采用公开l2rpn_idf_2023合成场景和LightSim2Grid潮流后端，电网含118个变电站、186条线路、99个负荷与62台发电机。原始拓扑库含909个动作，各时刻经过合法性筛选和物理等价合并后得到可查询代表池。各臂共享作者频次排序、基础连续动作、恢复规则及DC/safe-QP缓存；本轮不训练排序模型。')
 para('既有组包含七个已经暴露的日期，最新同批比较为GRID65的五种方法、两次计时重复，共70条回放。GRID63另有三次计时的等预算比较，物理结果复现；正文主计时采用GRID65同批记录，分开保留旧批结果。新增组使用六个本地尚无控制或教师结果的日期，三种方法各运行两次，共36条回放。参数组在四个旧开发日期运行六种配置，共24条回放；这些运行用于单参数检查，不作为新的独立场景。')
 para('新增日期为2035-01-01、02-19、04-02、07-09、12-10与12-17。来源审计排除所有已执行的训练、开发、评估和失败回放日期；场景此前可以仅做过数据格式检查，或出现在未入选的候选清单中。六日期在任何新控制结果产生前全部固定，使用已有解压副本中的固定哈希选择序列，不按收益重抽。作者公开先验的原始训练日期覆盖未知，本文将其表述为本地新场景评价。')
 para('实验主机为AMD Ryzen 9 8940HX、Windows 11；软件为Python 3.12.14、Grid2Op 1.12.5、LightSim2Grid 1.1.0、CVXPY 1.9.3、Clarabel 0.11.1和OSQP 1.1.3。环境种子为0，正式计时串行执行，数值库单线程。两次计时采用反序方法安排；计时期间不并行训练或重型审计。初始化、物理环境步进和落盘独立计量。')
 para('3.2 方法、指标与计量','Heading 2')
 table('表1 共享排序与控制底座的主要比较方法',['方法','查询与停止规则'],[
 ['FULL','评估当前全部合法代表，保留奖励最高的可接纳动作。'],['FRAME','128候选前缀，64个一批扩展；使用负载率与停滞反馈停止，随后执行一次同站补全。'],['GLOBAL_MATCH','与FRAME共用全局阶段；在新增反馈前计算同站剩余代表数q，按全局顺序继续查询q个候选。'],['META-DQN（种子0/1）','ICAPS 2022官方Double DQN核心的停止/继续领域适配；从已查询反馈选择继续或返回。']],[4.3,12.1])
 para('GLOBAL_MATCH的附加预算在相同状态、相同全局前缀上与FRAME精确相等。闭环轨迹分叉后，各自后续状态的可用池和触发次数可以不同，因此不强制整周总数相等。该比较把“补查更多候选”的作用与“按同站归属选择候选”的作用分开观察。')
 para('质量先于计算评价。要求相对同批FULL不更早失败，并在双方共同完成整周时满足成本增幅不超过0.5%。运行成本采用现有L2RPNSandBoxScore计量，包含损失、再调度、弃电变化和储能吞吐。单个预测动作的可接纳性由方法中的已观测准入规则确定。未完成周保留存活步数，完整周成本的表格单元留空。')
 para('查询数仅统计实际派发的N-1候选预测；完整控制时间包含候选准备、排序、预测、连续优化及恢复。先平均同日期计时重复，再计算相对FULL的比例，最后按日期等权平均；时间只比较等时域，FULL零查询日期从查询比例均值中排除并单列。P95/P99采用每条回放决策延迟的线性插值分位数，分别统计所有控制步骤和实际触发N-1搜索的步骤。两次重复的标准差与范围表示计时离散度。')
 para('3.3 闭环质量、查询与实际计算','Heading 2')
 table('表2 同批评价的总体结果',['组别／方法','质量／日期','完整周','查询减少','控制时间减少','最坏整周成本变化'],
  [['既有／'+s['method'],f"{s['quality_dates']}/7",f"{s['completed_dates']}/7",pct(s['macro_query_reduction_full']),pct(s['macro_time_reduction_full']),pct(s['max_complete_cost_delta_full'],3)] for s in old['summaries']]+
  [['新增／'+s['method'],f"{s['quality_dates']}/6",f"{s['complete_dates']}/6",pct(s['macro_query_reduction']),pct(s['macro_time_reduction']),pct(s['max_complete_cost_delta'],3)] for s in fresh['summaries']], [4.1,2.0,1.6,2.5,2.8,3.4])
 para(f'FRAME在既有七日期上全部达到预设质量标准，减少{100*old_q:.2f}%的候选查询和{100*old_t:.2f}%的完整控制时间。新增组质量通过{new_quality}/6、完成{new_complete}/6；在五个等时域日期，查询减少{100*new_q:.2f}%，实际控制时间减少{100*new_t:.2f}%。表3与表4保留每个日期的成本、查询和原始计时范围，图3分别展示新增日期的三项主要指标。')
 para('新增组没有通过冻结质量判据。7月9日FULL完成2017步，FRAME在1901步结束，少存活116步；12月10日FRAME完成整周，但成本增幅0.641%，超过0.5%尺度。七月的较短运行没有计入查询和时间减少均值。两次重复的物理轨迹完全一致，因此这两项质量问题在本批重复中均存在。')
 figure('fresh_scenes','图3 六个新增本地日期的结果。左：N-1候选查询减少；中：实际完整控制时间减少；右：双方共同完成整周的成本变化。成本虚线为0.5%质量筛查上限；不可比项标为N/A。')
 for stage,label in [(65,'既有七日期'),(68,'新增六日期')]:
  families=csvread(ROOT/f'outputs/grid{stage}/per_family.csv');rows=[]
  for date in read(ROOT/f'outputs/grid{stage}/design.json')['weeks']:
   f=next(r for r in families if r['date']==date and r['method']=='FULL');g=next(r for r in families if r['date']==date and r['method']=='FRAME')
   ckey='cost_delta_full';tkey='controller_mean_s';qkey='queries_mean' if stage==65 else 'queries'
   summaries=read(ROOT/f'outputs/grid{stage}/finished.json')['summaries']
   ns=lambda method:next(s['steps'] for s in summaries if s['week']==date and s['method']==method)
   steps=f"{ns('FULL')}→{ns('FRAME')}"
   tf=f"{float(f[tkey]):.2f}\n[{float(f['controller_min_s']):.2f}, {float(f['controller_max_s']):.2f}]"
   tg=f"{float(g[tkey]):.2f}\n[{float(g['controller_min_s']):.2f}, {float(g['controller_max_s']):.2f}]"
   rows.append([date,steps,pct(fv(g[ckey]),3),f"{int(float(f[qkey]))}→{int(float(g[qkey]))}",tf,tg])
  table(f'表{3 if stage==65 else 4} {label}的FRAME对FULL结果',['日期／序列','步数 FULL→FRAME','整周成本变化','查询 FULL→FRAME','FULL控制秒 均值[范围]','FRAME控制秒 均值[范围]'],rows,[3.1,2.2,2.0,2.7,3.2,3.2])
 para('3.4 论文来源的自适应停止对照','Heading 2')
 para('META-DQN依据Bhatia等人的ICAPS 2022元推理工作[5]及官方实现移植Double DQN核心，动作限定为停止与继续。输入只含查询前缀的质量、改善和规模等12个可见量；训练效用使用一步N-1奖励与查询价格。18个非评价日期家族拆为14个训练家族和4个校准家族，三个预定价格、两个随机种子共六次固定拟合，耗时202.76秒；两种子共享校准选出的价格，在线不训练。')
 para('该对照在既有七日期的质量通过分别为6/7和5/7，查询分别减少69.28%和63.05%。FRAME的主要优势体现在质量和查询数量。相对两个元策略种子，FRAME宏平均完整控制时间仅少0.06%和1.74%；按总秒数汇总，对种子0反而多0.63%，对种子1近乎相同。论文据此将计算优势定位于相对完整搜索的改善，保留元停止策略的竞争结果。')
 para('此实现是原论文机制的电网停止子任务适配，未重现原A*/RRT*任务或其参数调节动作。Budd等人的上下文元MDP也采用学习式计算分配[7]；本文没有把手写阈值当作其完整方法复现。')
 para('3.5 等预算补查与结构归因','Heading 2')
 para('在既有七日期上，GLOBAL_MATCH与FRAME都质量通过7/7、完成5/7，候选查询总量相同。FRAME相对GLOBAL_MATCH的整周成本改善在3月为FULL的0.04677%，4月为0.00782%，其余三个共同完成日期为零。新增六日期继续保留这一对照，全部逐日期结果见配套表；该比较检验一次局部补查的结构增量，不预设FRAME必须获胜。')
 extra=[];fam=csvread(ROOT/'outputs/grid68/per_family.csv')
 for date in read(ROOT/'outputs/grid68/design.json')['weeks']:
  f=next(r for r in fam if r['date']==date and r['method']=='FULL');a=next(r for r in fam if r['date']==date and r['method']=='FRAME');b=next(r for r in fam if r['date']==date and r['method']=='GLOBAL_MATCH')
  if all(x['complete']=='True' for x in [f,a,b]):extra.append((date,(float(b['cost'])-float(a['cost']))/float(f['cost'])))
 para('新增日期中，FRAME相对等预算全局扩展的完整周成本差（正值为FRAME更好）为：'+('；'.join(d[5:10]+' '+pct(v,4) for d,v in extra) if extra else '没有双方共同完成的可比较日期')+'。')
 para('这些结果将框架的作用定位在反馈驱动的查询压缩和保留已观测最佳结果。一次同站补全提供了可实现的结构化查询集合；其相对同额全局补查的稳定质量优势，需要由上述逐日期结果支持。旧NO_LOCAL消融中增加查询与改变补查范围同时发生，不能独自承担这一归因。')
 para('3.6 单参数敏感性','Heading 2')
 para('保持四个旧开发日期和其余模块不变，分别将初始前缀从128改为64或256，将停滞批数阈值从2改为1或3。这里用H表示阈值，算法中的h仍为连续未改善计数器，停止条件为h≥H，默认H=2。批量64、最少查询256、负载率阈值0.9保持固定，不运行参数交叉网格。默认参数在这组实验后保持不变；新增日期没有用于选择任何设置。')
 sr=[]
 names={'FRAME':'默认 p=128,H=2','FRAME_P64':'前缀 p=64','FRAME_P256':'前缀 p=256','FRAME_S1':'停滞阈值 H=1','FRAME_S3':'停滞阈值 H=3'}
 for s in sens['summaries']:
  if s['method']=='FULL':continue
  sr.append([names[s['method']],f"{s['quality_dates']}/4",pct(s['macro_query_reduction']),pct(s['max_complete_cost_delta'],3)])
 table('表5 查询前缀与停滞参数敏感性',['配置','质量日期','查询减少/FULL','最坏整周成本变化'],sr,[5.2,2.7,4.0,4.5])
 figure('sensitivity','图4 单参数敏感性。左：四日期等权查询减少；右：共同完成日期的最大成本变化，虚线表示0.5%质量尺度。蓝柱为固定默认配置；其他柱为单轴改变，不据图选择新默认值。')
 para('前缀增加至256以及停滞批数改为1或3时，四个日期都通过质量标准；查询减少分别为57.94%、70.11%和65.87%。前缀缩短至64时，查询减少72.87%，质量通过3/4，最坏完整周成本增幅为0.530%，略高于0.5%尺度。结果显示默认附近存在可用设置，同时揭示过短初始前缀的质量风险。')
 para('参数组每格只进行一次闭环回放，主要检查确定性的质量和查询路径；单次耗时保存在数据表中，不承担稳定提速主张。未完成周的成本不进入最大完整周变化。质量未通过的参数与对应日期完整保留。')
 para('3.7 计算分解与尾部延迟','Heading 2')
 para('图5将完整控制时间拆为互斥组成：N-1候选预测、其他预测、连续优化与恢复、其余控制。QP后端求解和编译计时嵌套在优化调用内，未再次相加。候选预测减少后，连续优化、恢复及其他预测仍然执行，因此查询节省与完整控制时间减少有不同幅度。各分量也随闭环轨迹变化，这组分解用于定位计算热点。')
 figure('computation_latency','图5 计算开销与搜索步骤尾部延迟。左：既有七日期的互斥控制时间分解，按日期等权平均；右：逐日期、逐回放先计算再平均的搜索步骤P95。没有N-1搜索的日期单列。')
 metrics=csvread(ROOT/'outputs/grid66/historical_date_metrics.csv');lat=[]
 for d in read(ROOT/'outputs/grid65/design.json')['weeks']:
  f=next(x for x in metrics if x['date']==d and x['method']=='FULL');a=next(x for x in metrics if x['date']==d and x['method']=='FRAME')
  fmt=lambda x:'—' if fv(x) is None else f'{float(x)*1000:.2f}'
  fmt2=lambda x:'—' if fv(x) is None else f'{float(x):.3f}'
  lat.append([d,fmt(f['all_p95_s_mean'])+'→'+fmt(a['all_p95_s_mean']),fmt2(f['search_p95_s_mean'])+'→'+fmt2(a['search_p95_s_mean']),fmt2(f['search_p99_s_mean'])+'→'+fmt2(a['search_p99_s_mean']),f['search_steps_per_repeat']+'→'+a['search_steps_per_repeat']])
 fresh_latency=csvread(ROOT/'outputs/grid68/latency.csv')
 for d in read(ROOT/'outputs/grid68/design.json')['weeks']:
  f=[x for x in fresh_latency if x['date']==d and x['method']=='FULL'];a=[x for x in fresh_latency if x['date']==d and x['method']=='FRAME']
  avg=lambda rows,k:statistics.mean([float(x[k]) for x in rows if fv(x[k]) is not None]) if any(fv(x[k]) is not None for x in rows) else None
  fm=lambda v,m:'—' if v is None else f'{v*m:.3f}'
  number=lambda rows:'/'.join(dict.fromkeys(x['search_steps'] for x in rows))
  lat.append([d,fm(avg(f,'p95_s'),1000)+'→'+fm(avg(a,'p95_s'),1000),fm(avg(f,'search_p95_s'),1)+'→'+fm(avg(a,'search_p95_s'),1),fm(avg(f,'search_p99_s'),1)+'→'+fm(avg(a,'search_p99_s'),1),number(f)+'→'+number(a)])
 table('表6 全部13日期的延迟（FULL→FRAME）',['日期','所有步骤P95 / ms','搜索步骤P95 / s','搜索步骤P99 / s','每次搜索步数 FULL→FRAME'],lat,[3.1,3.8,3.4,3.4,2.7])
 para('N-1搜索仅在部分控制步骤发生，所以所有步骤P95可能主要反映基础控制，并随轨迹和优化调用发生波动。本文保留该指标，同时单列搜索活跃步骤P95/P99。每个日期两次原始控制计时、标准差、极值和新增日期延迟均在可编辑补充表中提供。')
 para('新增七月日期的运行时域不同，表6仅保留各自原始延迟分位数，不将其差值计入性能节省。')
 para('3.8 同状态搜索行为','Heading 2')
 diagnostic=read(OUT/'same_state_mechanism.json');assert diagnostic['passed']
 rows=[]
 for x in diagnostic['groups']:
  rows.append(['既有' if x['stage']==65 else '新增',x['full_search_states'],x['exact_full_choice'],x['initial_short_paths'],x['completion_triggers'],x['local_choice_changes'],f"{x['max_frame_fp32_reward_loss']:.5f}" if x['max_frame_fp32_reward_loss'] is not None else '—'])
 table('表7 FULL轨迹上全部搜索状态的离线重放',['组别','搜索状态','FRAME与FULL同动作','首批短路径','补全触发','补全改变动作','最大一步奖励差'],rows,[1.3,1.6,3.4,2.1,2.1,2.4,3.5])
 para('这一诊断使用每个日期第一次FULL回放的全部搜索状态，已知完整反馈仅用于离线重放冻结查询规则。统计显示哪些状态可由短路径处理，以及补查是否改变返回动作；它同时保留提前停止遗漏最优一步动作的情形。样本来自FULL的状态分布，正式控制器始终只能看到实际查询反馈。长期效果采用前述闭环结果评价。')
 para('3.9 补全动作案例','Heading 2')
 para('3月第1733步中，FRAME在256个全局候选后补查198个同站配置，找回与完整909候选搜索相同的动作309。去补全的NO_LOCAL在该日期整周成本增幅为4.810%，FRAME为0.372%。这一案例展示具体查询与闭环后果；同额全局扩展在该日期也已接近FRAME，其差异由3.5节另行量化。')
 figure('completion_case','图6 一次补全的动作级案例。左：3月第1733步的查询与选择；右：同日期整周成本变化。动作案例用于说明补全如何工作，结构增量采用等预算对照。')
 para('3.10 新增质量失效的首次分歧','Heading 2')
 para('只读保存记录可将两个质量失效日期的首次动作分歧定位到首批直接返回分支。7月第100步，FRAME查询128个候选后返回动作18，预测负载率0.48525；FULL查询909个候选并选中动作741，预测负载率0.48055。两者来自不同变电站，当时均远低于0.9阈值，局部补全没有触发。该轨迹最终在1901步因电网断连导致潮流求解终止。')
 para('12月10日的首次分歧发生在1122步，同样是128候选后的直接返回：FRAME动作23的预测负载率为0.83871，FULL动作209为0.83796。后续闭环中FRAME与GLOBAL_MATCH还会分叉；后者该日期成本增幅0.432%，通过质量尺度。首次分歧定位不证明单次动作替换就能修复整周结果，现有记录提供了下一步检验返回条件与后续风险的具体位置。')
 para('4 结论','Heading 1')
 para(f'FRAME将候选排序后的评估过程组织为反馈驱动的渐进查询和一次配置补查。既有七日期实验中，它在保持预设闭环质量的同时减少{100*old_q:.2f}%的候选查询和{100*old_t:.2f}%的实际控制时间；新增六日期中质量通过{new_quality}/6，在五个等时域日期查询与控制时间分别减少{100*new_q:.2f}%和{100*new_t:.2f}%。这轮补充验证了查询与计算压缩的实际存在，同时定位了跨日期质量缺口。当前版本尚未满足新增组的质量要求，后续改进应优先处理首批直接返回的风险，并继续保留相同查询预算的全局对照。')
 para('5 相关工作','Heading 1');para('5.1 电网混合控制与学习排序','Heading 2')
 para('Grid2Op支持公开闭环电网控制研究[1]。LJN通过拓扑决策、连续优化和恢复逻辑构造混合控制器[2]；SoftGNN使用软标签表达多个有效动作的偏好[3]，de Jong等人研究图表示与拓扑泛化[4]。这些研究为候选顺序和基础控制提供支持。FRAME接在排序与仿真之间，管理实际查询集合，可沿用固定或学习排序。本文主实验采用共同频次先验，框架结果不归于新增图编码能力。')
 para('5.2 元推理与计算分配','Heading 2')
 para('元推理研究何时继续计算、何时执行当前方案。Bhatia等人通过强化学习联合处理停止和参数调节[5]；Milli等人从有界计算角度研究此类决策[6]；Budd等人将在线计算分配建模为上下文元MDP[7]。FRAME在电网候选查询层使用反馈停止，并显式构造一次附加配置集合。实验提供公开来源的停止限定适配对照，与完整搜索和等预算扩展共同定位其应用效果。')
 para('5.3 配置比较与领域结构','Heading 2')
 para('以局部邻域补充全局搜索是规划与组合优化中的常见组织方式。本文将这一思路具体落实到拓扑动作的变电站归属，并在物理等价合并后通过原始别名构造剩余配置集合。技术重点是查询集合与实际执行记录一致、保留已有结果并避免重复仿真。领域结构对成本的额外收益以等预算比较为准。')
 para('6 局限','Heading 1')
 for t in [
 '评价覆盖一个公开合成电网。新增六个日期覆盖四个季度，补充了原有七日期评价；多电网验证留待后续。重复运行用于计时，不能当作额外日期。外部作者频次先验与PPO训练覆盖尚不明确。',
 '负载率准入与当前最佳结果保留约束一步预测选择，长期成本和存活由闭环实验检验。共同失败的周保留实际步数，质量筛查通过数与完整周完成数分别报告。0.5%是本研究事先固定的实用尺度。',
 '参数实验只检查两个参数的单轴变化，未覆盖全部交互。元停止基线是明确标注的领域适配，未覆盖所有计算分配方法。查询减少后的整套控制提速受其余优化与恢复开销限制。',
 '审计核对保存观测、动作向量、反馈和成本账目，并非独立重新求解AC潮流。原始记录、所有较差配置、失败与运行波动保留在研究归档中。']:para(t)
 para('参考文献','Heading 1')
 for t in refs:para(t)
 doc.core_properties.title=title;doc.core_properties.author='';doc.core_properties.last_modified_by=''
 target=OUT/'ICAPS2027_中文全文修订稿_V5.docx';doc.save(target);(OUT/'ICAPS2027_中文全文修订稿_V5.md').write_text('\n'.join(md),encoding='utf-8')
 assert sha(SRC)==original_hash
 savejson(OUT/'revision_receipt.json',{'source':str(SRC),'source_sha256_unchanged':original_hash,'method_body_sha256':method_hash,'method_equations_retained':sum(len(e.xpath('.//m:oMath')) for e in method),'tables':tables,'new_primary_dates':6,'total_primary_dates':13,'no_new_training':True,'results':[{'stage':s,'review_sha256':sha(ROOT/f'outputs/grid{s}/review.json')} for s in [65,67,68]],'docx_sha256':sha(target)})
 shutil.copy2(ROOT/'outputs/grid_icaps_cn_v4/references_checked.bib',OUT/'references_checked.bib')
 print(target)
if __name__=='__main__':main()
