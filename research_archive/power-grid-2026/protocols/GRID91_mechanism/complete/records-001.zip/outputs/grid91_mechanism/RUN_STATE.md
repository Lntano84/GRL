FROZEN: 3 FRAME environment qualification replays then25 NO_LOCAL deletion replays, serial. No fitting or new grids.
