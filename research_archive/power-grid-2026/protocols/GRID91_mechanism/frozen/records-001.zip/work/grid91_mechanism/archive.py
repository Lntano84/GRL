"""Archive the bounded protocol/results; keep large vectors locally with hashes."""
from pathlib import Path
import argparse,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid91_mechanism';REPO=ROOT/'work/GRL-results-integration'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def append_once(path,key,text):
    old=path.read_text(encoding='utf-8')
    if key not in old:path.write_text(old.rstrip()+'\n\n'+text.strip()+'\n',encoding='utf-8')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['frozen','complete'],default='complete');args=ap.parse_args()
    if args.phase=='complete':assert read(OUT/'review.json')['passed_saved_data']
    dest=REPO/'research_archive/power-grid-2026/protocols/GRID91_mechanism'/args.phase
    if (dest/'archive_receipt.json').exists():
        for z in read(dest/'archive_receipt.json')['archives']:assert sha(REPO/z['path'])==z['sha256']
        print('Existing immutable archive verified');return
    dest.mkdir(parents=True,exist_ok=True)
    files=list(W.glob('*.py'));excluded=[]
    for p in OUT.rglob('*'):
        if not p.is_file():continue
        if p.suffix in ('.json','.md','.log','.txt','.csv') or p.name.endswith('.jsonl.gz'):files.append(p)
        elif p.suffix=='.npz':excluded.append(dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=sha(p),reason='Large saved vector arrays preserved on D; hash indexed here'))
    batches=[];current=[];size=0
    for p in sorted(set(files)):
        if current and size+p.stat().st_size>24*1024*1024:batches.append(current);current=[];size=0
        current.append(p);size+=p.stat().st_size
    if current:batches.append(current)
    entries=[];archives=[]
    for index,batch in enumerate(batches):
        zpath=dest/f'records-{index+1:03d}.zip';batch_entries=[]
        with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for p in batch:
                data=p.read_bytes();member=p.relative_to(ROOT).as_posix();z.writestr(member,data)
                batch_entries.append(dict(path=member,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),archive=zpath.name))
        with zipfile.ZipFile(zpath) as z:
            assert z.testzip() is None
            for e in batch_entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
        entries.extend(batch_entries);archives.append(dict(path=zpath.relative_to(REPO).as_posix(),bytes=zpath.stat().st_size,sha256=sha(zpath)))
    (dest/'files.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (dest/'archive_receipt.json').write_text(json.dumps(dict(phase=args.phase,archives=archives,files=len(entries),crc_and_hashes_verified=True,large_vectors_preserved_on_D=excluded),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for name in ['design.json','preflight.json','review.json','decision.json','first_divergences.json','per_scenario.csv','GRID91_report.md','精简方法说明_中文.md']:
        if (OUT/name).exists():shutil.copy2(OUT/name,dest/name)
    key='GRID91_MECHANISM_'+args.phase
    if args.phase=='frozen':
        note='用户授权完成第1项机制去留。最终规则另存为模块化纯策略，默认删除冗余qmin条件；原13/G1/G2共25场景做NO_LOCAL删除测试，另3条FRAME分别资格验证三组环境。共28条串行、单次描述性计时；历史FRAME只复用质量和查询，不跨批声称提速。全部输入、日期、模型、阈值和运行上限冻结；不训练、不换网、不扩对照。'
    else:
        d=read(OUT/'decision.json');note='第1项28条回放及保存向量/反馈/成本/独立策略审计完成，3个FRAME环境资格轨迹重现。最终补查删除判读：'+d['category']+'；移除后失去预设质量条件的场景'+str(len(d['completion_prevents_quality_failure_cases']))+'个。前缀作为初始化，反馈核查为核心，冗余默认qmin作为派生量。所有不利结果保留，无新学习或第二网。'
    for name in ['docs/DECISIONS.md','docs/EXPERIMENT_LOG.md']:
        append_once(REPO/name,key,'## 2026-10-20 — '+key+'\n\n'+note)
    state=REPO/'docs/RESEARCH_STATE.md';old=state.read_text(encoding='utf-8')
    if key not in old:
        first,rest=old.split('\n',1);state.write_text(first+'\n\n- **'+key+'：** '+note+'\n'+rest,encoding='utf-8')
    append_once(REPO/'research_archive/power-grid-2026/README.md',key,'## '+key+'\n\n'+note+'\n\n[方案与结果](protocols/GRID91_mechanism/'+args.phase+'/)')
    if args.phase=='complete':
        collab=ROOT/'论文协作资料/FRAME_机制去留与精简_20261020';collab.mkdir(exist_ok=True)
        for name in ['GRID91_report.md','精简方法说明_中文.md','design.json','decision.json','review.json','first_divergences.json','per_scenario.csv']:
            shutil.copy2(OUT/name,collab/name);assert sha(OUT/name)==sha(collab/name)
        append_once(REPO/'docs/NEXT_STEPS.md',key,'## '+key+'\n\n第1项已完成，先向用户汇报机制取舍及边界；第二电网、比例预算与CCMA不自动启动。')
    print(json.dumps(dict(phase=args.phase,files=len(entries),archives=len(archives)),ensure_ascii=False))


if __name__=='__main__':main()
