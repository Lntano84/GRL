"""Prespecified diagnostic on every repeat-0 FULL search state; no extra simulation."""
from pathlib import Path
import csv,importlib.util,json,statistics,struct
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/grid_icaps_cn_v5'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sp=importlib.util.spec_from_file_location('paper_frame_reference',ROOT/'work/grid63/policies.py');P=importlib.util.module_from_spec(sp);sp.loader.exec_module(P)
subs=read(ROOT/'outputs/grid28/offline.json')['public_subids']
def fp(v):return struct.unpack('f',struct.pack('f',v))[0]
def main():
 assert not any((ROOT/f'outputs/grid{s}/RUN.lock').exists() for s in [67,68])
 OUT.mkdir(exist_ok=True);rows=[];groups=[]
 for stage in [65,68]:
  assert read(ROOT/f'outputs/grid{stage}/review.json')['passed_saved_data']
  dates=read(ROOT/f'outputs/grid{stage}/design.json')['weeks']
  for w in dates:
   folder=ROOT/f'outputs/grid{stage}/runs/r0__{w}__FULL'
   for path in sorted(folder.glob('call[0-9][0-9][0-9].json')):
    c=read(path);truth={x['pool_id']:x for x in c['outcomes']};order=c['order'];aliases={int(k):int(v) for k,v in c['aliases'].items()}
    assert set(truth)==set(order)
    reveal=lambda i,p:{**truth[i],'phase':p}
    results={name:P.run(order,reveal,name,subs,aliases) for name in ['FULL','FRAME','GLOBAL_MATCH']}
    results['NO_LOCAL']=P.old.run(order,reveal,'NO_LOCAL',subs,aliases)
    a=results['FRAME'];b=results['GLOBAL_MATCH'];f=results['FULL'];n=results['NO_LOCAL'];assert a['public_queries']==b['public_queries']
    quality=lambda x:None if x['chosen_pool_id'] is None else fp(truth[x['chosen_pool_id']]['reward'])
    fq,aq,bq,nq=map(quality,[f,a,b,n]);loss=None if fq is None or aq is None else fq-aq
    if loss is not None:assert loss>=0
    rows.append({'stage':stage,'date':w,'step':c['step'],'full_pool':len(order),'full_has_admissible':fq is not None,'frame_queries':a['public_queries'],'global_queries':b['public_queries'],'no_local_queries':n['public_queries'],'frame_exact_full_choice':a['chosen_pool_id']==f['chosen_pool_id'],'global_exact_full_choice':b['chosen_pool_id']==f['chosen_pool_id'],'no_local_exact_full_choice':n['chosen_pool_id']==f['chosen_pool_id'],'frame_fp32_reward_loss':loss,'global_fp32_reward_loss':None if fq is None or bq is None else fq-bq,'local_reward_gain':None if aq is None or nq is None else aq-nq,'local_changed_choice':a['chosen_pool_id']!=n['chosen_pool_id'],'completion_queries':a['local_queries'],'global_changed_choice':b['chosen_pool_id']!=n['chosen_pool_id'],'stop_reason':a['stop_reason'],'initial_short_path':not a['fallback']})
  a=[x for x in rows if x['stage']==stage];losses=[x['frame_fp32_reward_loss'] for x in a if x['frame_fp32_reward_loss'] is not None]
  groups.append({'stage':stage,'dates':len(dates),'search_dates':len({x['date'] for x in a}),'full_search_states':len(a),'exact_full_choice':sum(x['frame_exact_full_choice'] and x['full_has_admissible'] for x in a),'global_exact_full_choice':sum(x['global_exact_full_choice'] and x['full_has_admissible'] for x in a),'no_local_exact_full_choice':sum(x['no_local_exact_full_choice'] and x['full_has_admissible'] for x in a),'initial_short_paths':sum(x['initial_short_path'] for x in a),'no_admissible_states':sum(not x['full_has_admissible'] for x in a),'completion_triggers':sum(x['completion_queries']>0 for x in a),'local_choice_changes':sum(x['local_changed_choice'] for x in a),'local_positive_reward_gains':sum(x['local_reward_gain'] is not None and x['local_reward_gain']>0 for x in a),'median_frame_fp32_reward_loss':statistics.median(losses) if losses else None,'max_frame_fp32_reward_loss':max(losses) if losses else None})
 if rows:
  with (OUT/'same_state_mechanism.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
 result={'passed':True,'groups':groups,'new_simulations':0,'scope':'Every FULL search state from repeat0, both cohorts including failed weeks; repeats omitted to avoid duplicate physical states. Counterfactual finite-policy queries replay actual FULL feedback only for offline diagnosis, not fed to online controller. This is FULL-policy state distribution, not FRAME on-policy or full-week optimality proof.'}
 (OUT/'same_state_mechanism.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
