# Superseded recording batch

The 564 physical steps executed, but the telemetry cached action.to_vect before continuous setters. Fourteen final action logs were stale, and matched-action forecasts were therefore incorrectly attributed in those steps. The old PASS summary in this directory is superseded. Do not cite its final-action or forecast results.

The corrected top-level batch uses direct non-mutating field vectorization. All physical observation hashes match across the batches; 14 action-vector hashes differ. Retain this directory for provenance, count its steps and runtime in total costs, and use only the top-level corrected audit/report for conclusions.
