from pathlib import Path
ROOT=Path('D:/Codex/GRL研究');OUT=ROOT/'outputs/grid_icaps_cn_v4'
# Manually checked fields. Software links identify the artifact itself.
entries=[
('misc','rte2026grid2op',{'author':'{RTE France}','title':'{Grid2Op}: A Testbed Platform to Model Sequential Decision Making in Power Systems','howpublished':'Software documentation','note':'Experiment version 1.12.5; accessed 2026-10-14','url':'https://github.com/Grid2op/grid2op'}),
('misc','lajavaness2023ljn',{'author':'{Lajavaness}','title':'{L2RPN 2023 LJN Agent}','year':'2023','howpublished':'Official software implementation','note':'Accessed 2026-10-14','url':'https://github.com/lajavaness/l2rpn-2023-ljn-agent'}),
('inproceedings','hassouna2026topology',{'author':r'Hassouna, Mohamed and Holzh{\"u}ter, Clara and Lehna, Malte and de Jong, Matthijs and Viebahn, Jan and Sick, Bernhard and Scholz, Christoph','title':'Learning Topology Actions for Power Grid Control: A Graph-Based Soft-Label Imitation Learning Approach','booktitle':'Machine Learning and Knowledge Discovery in Databases. Applied Data Science Track and Demo Track','volume':'16022','pages':'129--146','year':'2026','doi':'10.1007/978-3-032-06129-4_8'}),
('misc','dejong2025busbar',{'author':'de Jong, Matthijs and Viebahn, Jan and Shapovalova, Yuliya','title':'Graph Neural Networks for Transmission Grid Topology Control: Busbar Information Asymmetry and Heterogeneous Representations','year':'2025','howpublished':'arXiv:2501.07186v3','doi':'10.48550/arXiv.2501.07186'}),
('inproceedings','bhatia2022tuning',{'author':'Bhatia, Abhinav and Svegliato, Justin and Nashed, Samer B. and Zilberstein, Shlomo','title':'Tuning the Hyperparameters of Anytime Planning: A Metareasoning Approach with Deep Reinforcement Learning','booktitle':'Proceedings of the Thirty-Second International Conference on Automated Planning and Scheduling','pages':'556--564','year':'2022','doi':'10.1609/icaps.v32i1.19842'}),
('inproceedings','milli2017bounded',{'author':'Milli, Smitha and Lieder, Falk and Griffiths, Thomas L.','title':'When Does Bounded-Optimal Metareasoning Favor Few Cognitive Systems?','booktitle':'Proceedings of the Thirty-First AAAI Conference on Artificial Intelligence','pages':'4422--4428','year':'2017','doi':'10.1609/aaai.v31i1.11156'}),
('inproceedings','budd2024profiles',{'author':'Budd, Matthew and Lacerda, Bruno and Hawes, Nick','title':'Stop! Planner Time: Metareasoning for Probabilistic Planning Using Learned Performance Profiles','booktitle':'Proceedings of the Thirty-Eighth AAAI Conference on Artificial Intelligence','pages':'20053--20060','year':'2024','doi':'10.1609/aaai.v38i18.29983'})]
blocks=[]
for typ,key,fields in entries:
 blocks.append('@'+typ+'{'+key+',\n'+',\n'.join('  '+k+' = {'+('{'+v+'}' if k=='title' else v)+'}' for k,v in fields.items())+'\n}')
(OUT/'references_checked.bib').write_text('% Chinese V4 reference preparation only. No English manuscript built.\n% SoftGNN: publisher citation year 2026; ECML PKDD conference year 2025.\n'+'\n\n'.join(blocks)+'\n',encoding='utf-8')
print('7 manually normalized bibliography entries saved')
