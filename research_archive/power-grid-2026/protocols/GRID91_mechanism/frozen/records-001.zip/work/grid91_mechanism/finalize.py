"""Make a complete, bounded mechanism verdict and a concise method description."""
from pathlib import Path
import csv,json,statistics
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/grid91_mechanism'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))


def main():
    R=read(OUT/'review.json');assert R['passed_saved_data'];rows=R['comparisons']
    benefits=[r['week'] for r in rows if r['qualification_prevents_quality_failure']]
    harms=[r['week'] for r in rows if r['no_local_quality'] and not r['frame_quality']]
    category='RETAIN_CONDITIONAL_COMPLETION_QUALITY_EVIDENCE' if benefits else 'COMPLETION_NOT_NEEDED_FOR_PRESET_QUALITY_ON_THIS_REGRESSION'
    summary=[]
    for group in ['old13','G1','G2']:
        rr=[r for r in rows if r['cohort']==group];active=[r for r in rr if r['same_horizon'] and r['frame_queries']>0]
        deltas=[r['no_local_cost_delta_frame'] for r in rr if r['no_local_cost_delta_frame'] is not None]
        summary.append(dict(cohort=group,n=len(rr),frame_quality=sum(r['frame_quality'] for r in rr),no_local_quality=sum(r['no_local_quality'] for r in rr),frame_complete=sum(r['frame_complete'] for r in rr),no_local_complete=sum(r['no_local_complete'] for r in rr),frame_queries=sum(r['frame_queries'] for r in rr),no_local_queries=sum(r['no_local_queries'] for r in rr),same_horizon=sum(r['same_horizon'] for r in rr),no_local_query_reduction_on_matched_active=statistics.mean(1-r['no_local_queries']/r['frame_queries'] for r in active) if active else None,mean_no_local_cost_delta_frame=statistics.mean(deltas) if deltas else None,max_no_local_cost_delta_frame=max(deltas) if deltas else None))
    decision=dict(category=category,completion_prevents_quality_failure_cases=benefits,removing_completion_improves_quality_cases=harms,groups=summary,
                  prefix='Retain as initialization; no separate novelty or optimal128 claim',feedback='Retain as core adaptive depth control; keep existing fixed-budget and ordering limitations',
                  qmin='Remove independent default qmin parameter only under128/64/2; preserve historical freezes and results',
                  no_new_gate_or_threshold_selected=True,all_cases_retained=True,no_second_grid_started=True,no_new_learning=True)
    (OUT/'decision.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    with (OUT/'per_scenario.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    fmt=lambda v:'—' if v is None else f'{v:+.4%}'
    text=['# GRID91：三个步骤的机制去留与方法精简','','本轮只完成第1项。新增25条最终版本NO_LOCAL闭环，以及旧13/G1/G2各1条FRAME环境资格回放，共28条。未训练、调参、换电网或新增对照；既有FRAME质量/查询轨迹原样复用，全部场景和失败保留。','','## 去留结论','',f'冻结判读：**{category}**。',
          f'移除补查后失去既有FULL质量达标的场景：{len(benefits)}；反向质量改善场景：{len(harms)}。',
          '前缀保留为初始化，反馈控制深度作为核心。默认最低核查256由128+2×64自然满足，新模块化实现删除这一独立参数；保存反馈与独立逻辑复核，不改变其它规则。',
          ('同站补查保留为有条件的质量改进，有直接删除对照支持；不称所有场景都更好，也不新选触发阈值。' if benefits else '当前回归未证明同站补查是达到预设质量门槛所必需。将其降为可选扩展；完整保留成本、查询与反例，未凭此声称长期完全等价。'),
          '', '## 分组结果','','|组|FRAME质量|无补查质量|FRAME整周|无补查整周|FRAME查询合计|无补查查询合计|同时间域场景|','|---|---:|---:|---:|---:|---:|---:|---:|']
    for r in summary:text.append(f"|{r['cohort']}|{r['frame_quality']}/{r['n']}|{r['no_local_quality']}/{r['n']}|{r['frame_complete']}/{r['n']}|{r['no_local_complete']}/{r['n']}|{r['frame_queries']}|{r['no_local_queries']}|{r['same_horizon']}/{r['n']}|")
    text+=['','查询合计可能涉及不同闭环状态或存活长度，不能直接当作等质量提速。匹配活跃时域的查询比例、共同完成场景的成本差另存decision.json。质量达标沿用不早于FULL终止、共同完成周成本不超过FULL100.5%；这是实验容差，不是电网安全标准。','','## 全场景结果','','|组/场景|FRAME质量/完成|无补查质量/完成|FRAME对FULL成本|无补查对FULL成本|无补查对FRAME成本|FRAME/无补查查询|','|---|---|---|---:|---:|---:|---:|']
    for r in rows:text.append(f"|{r['cohort']}/{r['week']}|{r['frame_quality']}/{r['frame_complete']}|{r['no_local_quality']}/{r['no_local_complete']}|{fmt(r['frame_cost_delta_full'])}|{fmt(r['no_local_cost_delta_full'])}|{fmt(r['no_local_cost_delta_frame'])}|{r['frame_queries']}/{r['no_local_queries']}|")
    div=read(OUT/'first_divergences.json');changed=[r for r in div if r['first_action_divergence_step'] is not None]
    text+=['','## 机制解释',f"首次实际动作分歧的场景共{len(changed)}个，其中{sum(r['first_difference_is_local_selection'] is True for r in changed)}个在相同观测和基础动作下直接定位到同站补查改变候选。完整详情见first_divergences.json。首次分歧定位了作用入口，后续累计成本由整条闭环决定，不全部归因于这一动作。",'',
           '此前等追加预算结果仍保留：旧组13个状态奖励更好、0个更差；G1为3好1差且平均奖励差反向；G2为4好0差。本轮删除对照回答是否需要追加补查，等预算对照回答为何查同站，两者不能互相替代。',
           '候选排序依赖与参数敏感性沿用GRID89，不重复扩大实验。原教师频次顺序前128项占原记录44.38%，随机换序有失败，不能说排序不影响结果；128/64属于经验配置，不称理论最优。',
           '', '## 核查与范围',f"保存数据核查：{R['checks']['steps']}个物理步、{R['checks']['calls']}次搜索、{R['checks']['queries']}次已付费查询；动作/观测向量、公共候选与别名、反馈合法性、严格最优已观测选择、独立策略、上下文与逐步成本均核对。3条资格FRAME轨迹逐步重现历史结果。",
           '25个场景条目包括13个旧场景和两批各6个生成时序；两批生成时序的日历日期重复，不能称25个独立日期。所有输入均已暴露，是同电网机制回归。没有独立AC重求解，也未建立跨电网泛化。',
           '新计时为单次描述性记录，完整控制、P95及互斥计算分解保存在review.json；不与历史FRAME时间相除，也不以提前结束当作提速。',
           '', '## 第1项完成边界','代码模块化与默认冗余删除、最终版补查去留、原顺序/参数边界、同状态和闭环证据对应已整理。第二电网、比例预算和CCMA训练未启动。当前用户稿和全部冻结实验保留；本文为机制汇报，不冒充正式投稿稿。']
    (OUT/'GRID91_report.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    method='''# 精简后的方法说明（中文工作版）

FRAME根据已评估候选的反馈分配仿真计算。算法先评估候选序列的初始前缀，建立当前最佳可用动作；随后分批评估，依据最佳动作是否改善决定继续搜索或停止。初始候选尚未达到负载率分支阈值时，首次达到该阈值也可结束全局扩展。所有动作使用同一可接纳条件和奖励排序规则，查询结果在本次搜索中复用。

默认前缀128、批次64、连续两批未改善时停滞退出。此时停滞分支自然至少查询256次，因此不再单列最低核查量参数。前缀是反馈搜索的初始化步骤；经验停止规则控制查询深度，不能证明尚未评估的候选没有更高奖励。

全局阶段结束后，条件补查根据当前最佳动作的变电站归属定位尚未评估的候选，并按相同规则更新最佳动作。初始候选低于分支阈值且全局核查未改变该候选时，沿用原实现跳过补查。动作别名映射保留原始变电站归属，以免代表合并后遗漏结构关联候选。

本轮去留判读：'''+category+'''。是否把补查放在主方法中，以完整报告的质量、成本与查询增量为依据；不把已观测最优写成全局最优，不把一步奖励改善写成长期成本保证。该工作版说明对应另存的模块化代码，历史版本和成绩保持可追溯。
'''
    (OUT/'精简方法说明_中文.md').write_text(method,encoding='utf-8')
    print(json.dumps(decision,ensure_ascii=False))


if __name__=='__main__':main()
