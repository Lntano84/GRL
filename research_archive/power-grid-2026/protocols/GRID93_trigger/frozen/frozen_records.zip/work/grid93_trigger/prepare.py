"""Seal the one-rule finite stage and its six changed-trajectory replays."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid93_trigger'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
save=lambda n,x:(OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    assert read(OUT/'screen_verification.json')['passed']
    original=read(ROOT/'outputs/grid91_mechanism/design.json')
    D=read(W/'design.json');plans=read(OUT/'scenario_plan.json')
    assert sum(x['needs_closed_loop'] for x in plans)<=D['caps']['new_replays']
    olditems={i['week']:i for i in original['execution_order'] if i['policy']=='NO_LOCAL'}
    D['execution_order']=[dict(olditems[x['week']],method='SUPPORT_GATE',policy='SUPPORT_GATE',purpose='single_frozen_trigger_test') for x in plans if x['needs_closed_loop']]
    D['timing']=original['timing']
    D['caps'].update(episode_s=1200,wall_s=10800,physical_steps=25*2017,public_forecasts=250000)
    D['references']=original['references']
    save('design.json',D)
    freeze={}
    for name in ['code_freeze.json','data_freeze.json']:
        z=read(ROOT/'outputs/grid91_mechanism'/name)
        for rel,want in z.items():
            assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==want,rel
        if name=='code_freeze.json':freeze.update(z)
        else:save('data_freeze.json',z)
    for p in list(W.glob('*.py'))+[W/'design.json',OUT/'design.json']:
        freeze[p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    save('code_freeze.json',freeze)
    save('preflight.json',dict(passed=True,old_freeze_unchanged=True,code_files=len(freeze),data_files=len(z),
                               score_checks=222,hidden_suffix_checks=222,actual_baseline_reproductions=179,
                               planned_new_replays=len(D['execution_order']),unchanged_choice_scenarios=25-len(D['execution_order'])))
    print(json.dumps(read(OUT/'preflight.json'),ensure_ascii=False))


if __name__=='__main__':main()
