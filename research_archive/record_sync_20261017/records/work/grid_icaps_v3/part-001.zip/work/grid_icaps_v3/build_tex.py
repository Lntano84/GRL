from pathlib import Path
from docx import Document
import re,shutil
ROOT=Path('D:/Codex/GRL研究');OUT=ROOT/'outputs/grid_icaps_v3'
BASE=ROOT/'outputs/grid_icaps_draft_v1'
for n in ['aaai2027.sty','aaai2027.bst']:shutil.copy2(BASE/n,OUT/n)
bib=(BASE/'references.bib').read_text(encoding='utf-8')
# Editorial/provenance notes belong in receipts rather than the reference list.
bib=re.sub(r',?\n\s*note\s*=\s*\{[^\n]*\}\s*', '\n',bib)
bib=bib.replace('note = {Experiments use installed version 1.12.5; accessed 2026-10-13}', 'note = {Software documentation; accessed 2026-10-14}')
bib=bib.replace('  title = {{Grid2Op}', '  year = {2026},\n  note = {Version 1.12.5; software documentation accessed 2026-10-14},\n  title = {{Grid2Op}')
bib+='''\n@inproceedings{budd2024profiles,
 author={Budd, Matthew and Lacerda, Bruno and Hawes, Nick},
 title={Stop! Planner Time: Metareasoning for Probabilistic Planning Using Learned Performance Profiles},
 booktitle={Proceedings of the AAAI Conference on Artificial Intelligence},
 volume={38}, pages={20053--20060}, year={2024},
 doi={10.1609/aaai.v38i18.29983}
}\n'''
(OUT/'references.bib').write_text(bib,encoding='utf-8')
keys={1:'grid2op',2:'ljn2023agent',3:'hassouna2025softgnn',4:'dejong2025generalizablev1',5:'bhatia2022metareasoning',6:'milli2017metareasoning',7:'budd2024profiles'}
def text(s):
 tokens={}
 def hold(value):
  token=f'ZZTOKEN{len(tokens)}ZZ';tokens[token]=value;return token
 s=re.sub(r'\[([1-7](?:,[1-7])*)\]',lambda m:hold('\\citep{'+','.join(keys[int(x)] for x in m[1].split(','))+'}'),s)
 for old,new in [('a*(C)',r'$a^*(C)$'),('a*',r'$a^*$'),('s*',r'$s^*$'),('F_C',r'$\mathcal F_C$'),('q_min',r'$q_{\min}$'),('id(a)',r'$\operatorname{id}(a)$'),('M(a)',r'$M(a)$'),('s(j)',r'$s(j)$'),('v(a)=1',r'$v(a)=1$'),('r(a)',r'$r(a)$'),('ρ(a)',r'$\rho(a)$'),('ρ(x)',r'$\rho(x)$'),('ρ(a*)',r'$\rho(a^*)$')]:s=s.replace(old,hold(new))
 maps={'ρ':r'$\rho$','θ':r'$\theta$','η':r'$\eta$','⊥':r'$\bot$','⊆':r'$\subseteq$','≥':r'$\geq$','≤':r'$\leq$','∪':r'$\cup$','∈':r'$\in$','→':r'$\rightarrow$','−':'-','–':'--','’':"'"}
 for a,b in maps.items():s=s.replace(a,hold(b))
 s=s.replace('&',r'\&').replace('%',r'\%').replace('_',r'\_').replace('#',r'\#')
 for k,v in tokens.items():s=s.replace(k,v)
 return s
algo=r'''\begin{algorithm}[t]
\caption{Progressive Evaluation and Substation Completion}
\label{alg:frame}
\begin{algorithmic}[1]
\REQUIRE Ordered pool $A$, query $Q$, aliases $M$, substation map $s$
\ENSURE Topology proposal $a$ or $\bot$
\STATE $C\gets\operatorname{Query}(\operatorname{First}_{128}(A))$
\STATE $a\gets\operatorname{Best}(C)$
\IF{$C=A$ or $(a\ne\bot$ and $\rho(a)<0.9)$}
\RETURN $a$
\ENDIF
\STATE $h\gets 0$
\WHILE{$A\setminus C\ne\varnothing$}
\STATE $a_{\rm old}\gets a$
\STATE $C\gets C\cup\operatorname{Query}(\operatorname{Next}_{64}(A\setminus C))$
\STATE $a\gets\operatorname{Best}(C)$
\IF{$\operatorname{Better}(a,a_{\rm old})$}
\STATE $h\gets 0$
\ELSE
\STATE $h\gets h+1$
\ENDIF
\IF{$a\ne\bot$ and $[\rho(a)<0.9$ or $(|C|\geq256$ and $h\geq2)]$}
\STATE \textbf{break}
\ENDIF
\ENDWHILE
\IF{$a\ne\bot$ and $C\ne A$}
\STATE $s^*\gets s(\operatorname{id}(a))$
\STATE Construct $\mathcal L$ using Eq.~(3)
\STATE $C\gets C\cup\operatorname{Query}(\mathcal L)$; $a\gets\operatorname{Best}(C)$
\ENDIF
\RETURN $a$
\end{algorithmic}
\end{algorithm}
'''
def fig(name,caption,wide=True):
 env='figure*' if wide else 'figure'
 return '\\begin{'+env+'}[t]\n\\centering\n\\includegraphics[width=\\'+('textwidth' if wide else 'columnwidth')+']{figures/'+name+'.pdf}\n\\caption{'+text(caption)+'}\n\\label{fig:'+name+'}\n\\end{'+env+'}\n'
main=Document(ROOT/'outputs/grid_icaps_en_from_cn_v2/ICAPS2027_English_from_author_CN_V2.docx')
def table(rows,caption,cols,wide=True,emphasize=False,numbered=True):
 env='table*' if wide else 'table';out=['\\begin{'+env+'}[t]','\\centering','\\caption'+('' if numbered else '*')+'{'+text(caption)+'}',r'\begin{tabular}{'+cols+'}',r'\toprule']
 for i,row in enumerate(rows):
  vals=[text(v.replace('\n',' ')) for v in row]
  if i==0:
   head={'Dates passing quality':r'\shortstack{Quality\\dates}', 'Full weeks':r'\shortstack{Full\\weeks}', 'Controller time savings':r'\shortstack{Controller\\saving}', 'Query savings':r'\shortstack{Query\\saving}', 'Worst full-week cost change':r'\shortstack{Worst cost\\change}', 'FRAME steps and outcome':r'\shortstack{Steps and\\outcome}', 'Full-week cost change':r'\shortstack{Full-week\\cost change}', 'Confirmation date':r'\shortstack{Confirmation\\date}', 'Queries FULL → FRAME':r'\shortstack{Queries\\FULL $\to$ FRAME}'}
   vals=[r'\textbf{'+head.get(row[j].replace('\n',' '),v)+'}' for j,v in enumerate(vals)]

  if emphasize and len(row)>1 and row[1]=='FRAME':out.append(r'\rowcolor{framefill}')
  if emphasize and i>0:
   block=rows[1:5] if row[0]=='Development' else rows[5:9]
   for col in [4,5,6]:
    ordered=sorted({float(r[col].strip('%')) for r in block},reverse=col!=6)
    value=float(row[col].strip('%'))
    if value==ordered[0]:vals[col]=r'\textbf{'+vals[col]+'}'
    elif len(ordered)>1 and value==ordered[1]:vals[col]=r'\underline{'+vals[col]+'}'

  out.append(' & '.join(vals)+r' \\')
  if i==0:out.append(r'\midrule')
  elif emphasize and i==4:out.append(r'\midrule')
 out.extend([r'\bottomrule',r'\end{tabular}','\\end{'+env+'}']);return '\n'.join(out)+'\n'
md=(OUT/'manuscript_en.md').read_text(encoding='utf-8')
# Extend related work with a directly verified recent planning reference.
md=md.replace('while bounded-optimal metareasoning incorporates deliberation costs into policy evaluation [6].','while bounded-optimal metareasoning incorporates deliberation costs into policy evaluation [6]. Budd et al. use contextual performance profiles and a learned policy to choose when to stop probabilistic planning and how to set its hyperparameters [7].')
blocks=md.split('\n\n');parts=[];i=0;abstract=False;figmethod=False;maintable=False;datetable=False
while i<len(blocks):
 b=blocks[i].strip();i+=1
 if not b:continue
 if b.startswith('# '):continue
 if b=='## References':break
 if b=='## Abstract':abstract=True;continue
 if abstract:parts.append('\\begin{abstract}\n'+text(b)+'\n\\end{abstract}');abstract=False;continue
 if b.startswith('Keywords:'):continue
 if b.startswith('## ') or b.startswith('### '):
  cmd='section' if b.startswith('## ') else 'subsection';heading=re.sub(r'^\d+(?:\.\d+)*\s+','',b.lstrip('# '));parts.append('\\'+cmd+'{'+text(heading)+'}');continue
 if b.startswith('\\['):parts.append(b.replace('\\[',r'\begin{equation}').replace('\\]',r'\end{equation}'));continue
 if b.startswith('![Framework]'):parts.append(fig('method','FRAME uses query feedback to limit global evaluation and completes the selected substation before returning a topology proposal.'));figmethod=True;continue
 if b.startswith('Figure 2.'):continue
 if b.startswith('Algorithm 1.'):
  parts.append(algo)
  if i<len(blocks) and blocks[i].startswith('```'):i+=1
  continue
 if b.startswith('|'):
  # Markdown tables are split by blank lines; consume all rows as a unit.
  tablelines=[]
  while True:
   tablelines.extend(b.splitlines())
   if i>=len(blocks) or not blocks[i].strip().startswith('|'):break
   b=blocks[i].strip();i+=1
  rows=[[v.strip() for v in ln.strip('| ').split('|')] for ln in tablelines if not re.match(r'^\|?\s*---',ln)]
  if rows[0][0]=='Policy':parts.append(table(rows,'Search policies under a shared candidate order.',r'p{.37\columnwidth}p{.52\columnwidth}',False,numbered=False))
  elif rows[0][0]=='Set':
   parts.append(table(rows,'FRAME retains quality while reducing candidate evaluation. Query savings exclude zero-query dates; positive cost change is an increase. Bold and underline mark the best and second-best values within each set.',r'llccccc',emphasize=True));maintable=True
  elif rows[0][0].startswith('Confirmation'):parts.append(table(rows,'All frozen confirmation dates for FRAME.',r'lcccc'));datetable=True
  continue
 if b.startswith('Table 1.') or b.startswith('Table 2.'):continue
 parts.append(text(b))
 if b.startswith('Global rankings and the structural grouping'):
  parts.append(fig('motivation','Global rankings interleave substation configurations. Exhaustive comparison evaluates every group; early stopping can leave alternatives at an identified substation unqueried; FRAME completes that group. The candidate order is illustrative.'))
 if b.startswith('Table 1 shows how'):parts.append(fig('results','FRAME reduces candidate evaluation under matched survival outcomes. Solid and hatched bars distinguish development and confirmation; timing markers show both repetitions, with horizontal ticks denoting their means. Cost limits and query denominators follow Section 3.2.'))
 if b.startswith('This case illustrates how structural completion works'):parts.append(fig('completion_case','In the March case, 198 local queries recover FULL\'s selected action at step 1733. Closed-loop ablation reduces that date\'s full-week cost increase from 4.810% to 0.372%; the panels show single-step and full-week outcomes.'))
assert figmethod and maintable and datetable
preamble=r'''\documentclass[letterpaper]{article}
\usepackage[submission]{aaai2027}
\usepackage[hyphens]{url}
\usepackage{graphicx}
\urlstyle{rm}
\def\UrlFont{\rm}
\usepackage{natbib}
\usepackage{caption}
\usepackage{amsmath}
\usepackage{amssymb}
\usepackage{algorithm}
\usepackage{algorithmic}
\usepackage{booktabs}
\usepackage{colortbl}
\frenchspacing
\pdfinfo{/TemplateVersion (2027.1)}
\setcounter{secnumdepth}{2}
\definecolor{framefill}{RGB}{237,245,241}
\title{Progressive Topology Search with Substation Completion\\for Power Grid Control}
\author{Anonymous Authors}
\affiliations{}
\begin{document}
\maketitle
'''
(OUT/'manuscript.tex').write_text(preamble+'\n\n'.join(parts)+'\n\\bibliography{references}\n\\end{document}\n',encoding='utf-8')
print('AAAI 2027 submission-style source written with algorithmic pseudocode and four figures.')
