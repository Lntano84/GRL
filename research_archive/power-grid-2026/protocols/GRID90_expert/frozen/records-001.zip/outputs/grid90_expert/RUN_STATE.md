FROZEN:24 serial runs, two arms/six exposed G2 scenarios/two reverse timing repeats; preflight passed.
