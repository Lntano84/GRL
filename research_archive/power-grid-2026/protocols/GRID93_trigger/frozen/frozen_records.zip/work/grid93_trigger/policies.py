"""Single frozen station-support veto. Score uses pre-completion feedback only."""
from pathlib import Path
import importlib.util, struct

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('grid93_original',ROOT/'work/grid91_mechanism/policies.py')
BASE=importlib.util.module_from_spec(spec);spec.loader.exec_module(BASE)


def support(rows, incumbent, subids, aliases):
    station=int(subids[incumbent])
    target={int(v) for k,v in aliases.items() if int(subids[int(k)])==station}
    left=[r for r in rows if r['strict_admissible'] and r['pool_id']!=incumbent and r['pool_id'] in target]
    right=[r for r in rows if r['strict_admissible'] and r['pool_id'] not in target]
    def reward(r):return struct.unpack('f',struct.pack('f',r['reward']))[0]
    pairs=len(left)*len(right)
    wins=sum(reward(a)>reward(b) for a in left for b in right)
    ties=sum(reward(a)==reward(b) for a in left for b in right)
    score=(wins+.5*ties)/pairs if pairs else None
    return dict(station=station,local_observed=len(left),other_observed=len(right),pairs=pairs,
                pair_wins=wins,pair_ties=ties,score=score,veto=pairs>0 and 2*wins+ties<pairs)


def run(order,observe,policy,subids,aliases,params=None,context=None,limit=None,model_path=None):
    assert policy in ('FRAME_GUARD','SUPPORT_GATE') and not params and model_path is None
    if policy=='FRAME_GUARD':return BASE.run(order,observe,policy,subids,aliases)
    result=BASE.run(order,observe,'NO_LOCAL',subids,aliases)
    rows=result['outcomes'];best=max((r for r in rows if r['strict_admissible']),key=BASE.key,default=None)
    info=None
    if result['completion_budget']:
        info=support(rows,best['pool_id'],subids,aliases)
        if not info['veto']:
            for i in result['completion_candidate_ids']:
                r=observe(i,'local_completion');rows.append(r)
                if r['strict_admissible'] and BASE.key(r)>BASE.key(best):best=r
            result['local_queries']=result['completion_budget']
            result['extra_selected_ids']=result['completion_candidate_ids'].copy()
            result['stop_reason']+='_supported_local_complete'
        else:result['stop_reason']+='_station_support_veto'
    result['chosen_pool_id']=None if best is None else best['pool_id']
    result['public_queries']=len(rows)
    result['trigger_support']=info
    return result
