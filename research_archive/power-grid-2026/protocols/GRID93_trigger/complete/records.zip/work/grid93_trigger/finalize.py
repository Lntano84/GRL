"""Report and archive the result of one trigger hypothesis, including rejection."""
from pathlib import Path
import csv,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid93_trigger';REPO=ROOT/'work/GRL-results-integration'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def append(p,key,text):
    old=p.read_text(encoding='utf-8')
    if key not in old:p.write_text(old.rstrip()+'\n\n'+text.strip()+'\n',encoding='utf-8')


def main():
    R=read(OUT/'review.json');D=read(OUT/'decision.json');S=read(OUT/'screen_summary.json');assert R['passed_saved_data']
    rows=R['comparisons'];lost=[r for r in rows if r['lost_quality']]
    with (OUT/'actual_frame_state_screen.csv').open(encoding='utf-8-sig') as f:screen=list(csv.DictReader(f))
    july=[r for r in screen if r['week']=='2036-07-07_10' and r['step']=='113'];assert len(july)==1
    verdict='不采用这条新触发条件，保留原FRAME规则。' if not D['accepted'] else '本轮未损失预设质量，但还不能宣称触发问题已被解决。'
    text=['# 同站补查触发：一条“站内支持”规则的验证','',
          '**结论：'+verdict+'**','',
          '本轮检验一个具体想法：当前最佳动作来自某个站，去掉这个最佳动作后，该站其余已查询候选是否仍整体表现较好。如果整体表现较差，就取消本次补查。只检验这一条规则，没有扫描阈值或根据结果再加第二条规则。','',
          '## 触发条件怎么计算','',
          '保持原FRAME的前缀、全局分批核查与原触发资格。把补查前已经查询、可接纳的候选分成当前最佳站和站外两组，去掉当前最佳候选本身。逐对比较两组奖励，胜记1、平记0.5，取全部候选对的平均值。分数低于0.5，表示站内其余候选整体较弱，否决原补查；分数达到0.5或任一组没有候选时，保留原补查。0.5来自双方成对胜率相等，没有用评价数据拟合。','',
          '这样检验的是“这个站有多个好候选支持”，避免仅由当前最好的一个动作决定补查位置。分数按候选对平均，不让大站仅靠候选数量占优。它仍是一个有待验证的启发式假设，不是计算价值的理论估计。','',
          '## 先看保存反馈，避免重复回放','',
          '185个FULL状态和179个FRAME实际访问状态全部保留。两种状态来源分别报告，不能相加当作独立样本。','',
          '|FRAME访问状态|原补查次数|新规则取消次数|漏掉原本能提高奖励的补查|沿原状态序列省下的查询|',
          '|---|---:|---:|---:|---:|']
    for g in [x for x in S if x['states']=='FRAME_states']:
        text.append(f"|{g['cohort']}|{g['original_completion_calls']}|{g['veto_calls']}|{g['removed_improvements']}|{g['saved_queries']}|")
    text += ['', '上表最后一列只是沿原FRAME状态序列的诊断。只要动作改变，后续状态也会改变，就不能把它当作新策略实际闭环查询节省。','',
             '19个场景在所有保存搜索调用上的选择完全不变，复用其确定性轨迹的质量和成本，仅重算查询数；6个场景存在选择变化，全部做了单次新闭环回放。19个复用条目不是新物理回放或独立验证，没有把历史控制时间与新时间拼成提速。','',
             '## 闭环质量与查询','',
             '|场景组|FRAME质量达标|新触发质量达标|FRAME整周完成|新触发整周完成|FRAME查询|新触发查询|',
             '|---|---:|---:|---:|---:|---:|---:|']
    for g in R['groups']:
        n=g['scenarios'];text.append(f"|{g['cohort']}|{g['frame_quality']}/{n}|{g['gate_quality']}/{n}|{g['frame_complete']}/{n}|{g['gate_complete']}/{n}|{g['frame_queries']}|{g['gate_queries']}|")
    text += ['', '质量仍使用原来的标准：存活不短于FULL，双方完成整周时成本不超过FULL的100.5%；它是实验质量标准，不是安全保证。','',
             '双方完成整周时，新触发相对FRAME的逐场景成本变化宏平均：'+ '；'.join(f"{g['cohort']} {g['complete_cost_pct_macro']:+.4f}%" for g in R['groups'])+'。正值表示新规则成本更高。全量逐场景结果见`per_scenario.csv`。','']
    text += ['这些成本均值只覆盖双方完成整周的条目，不包含提前终止条目，不能用来掩盖质量退化或声称整体成本优势。','']
    extra_queries=[r for r in rows if r['gate_queries']>r['frame_queries'] and r['source_kind']=='new_closed_loop']
    if extra_queries:
        worst=max(extra_queries,key=lambda r:r['gate_queries']/r['frame_queries'])
        text += ['**单次少查不一定让整周少查。** '+worst['week']+'沿原FRAME状态序列筛查时，新门控只能减少当前调用查询；但实际闭环中，查询总量从'+str(worst['frame_queries'])+'变成'+str(worst['gate_queries'])+f"，增加{100*(worst['gate_queries']/worst['frame_queries']-1):.2f}%。改变动作后，后续状态和搜索需求也变了。因此必须检验整条控制轨迹，不能用静态筛查节省量代替闭环节省量。该场景还提前结束，原始查询总数并不构成相同时域的效率比较。",'']
    if lost:
        text += ['新规则让以下原本FRAME达标的场景失去质量条件：','',
                 '|场景|FRAME相对FULL成本变化|新触发相对FULL成本变化|新触发相对FRAME成本变化|',
                 '|---|---:|---:|---:|']
        for r in lost:
            def fmt(x):return '不适用' if x is None else f'{x:+.4f}%'
            text.append(f"|{r['week']}|{fmt(r['frame_vs_full_pct'])}|{fmt(r['gate_vs_full_pct'])}|{fmt(r['gate_vs_frame_cost_pct'])}|")
        for f in read(OUT/'failure_analysis.json'):
            e=f['comparison'];s=f['gate_support'];old=f['old_candidate'];new=f['completed_candidate']
            text += ['', f"**具体失败：{e['week']}。** 两版直到第{f['first_action_divergence_step']-1}步，动作、状态和成本完全一致。第{f['first_action_divergence_step']}步，站内除最佳外有{s['local_observed']}个可接纳候选，站外有{s['other_observed']}个，成对分数{s['score']:.6f}，新门控取消了{f['original_local_queries']}次补查。",'',
                     f"原FRAME通过补查把预测最大负载率从{old['rho']:.6f}降到{new['rho']:.6f}。新门控未发现这个尾部改进，此后轨迹分化，环境在第{e['gate_steps']}步提前结束；原FRAME完成{e['frame_steps']}步。该环境回合通过正常done接口返回潮流不收敛/非连通错误，运行器本身没有工程崩溃。搜索反馈与最终连续控制分开记账，不把一个搜索预测说成整套动作的物理保证。",'',
                     '这支持一个具体解释：**站内平均表现不能代替尚未查询尾部的最好表现**。把均值略低的站整体排除，仍会漏掉关键动作。首次分歧是后续失败路径的起点，不能据一次轨迹把全部后果归结为单个动作。', '']
            if f['historical_no_local_complete']:
                text += ['另一个边界是：历史完全不补查版本在该场景也能完成整周，但本次只取消部分补查反而提前结束。选择性门控不是两个端点性能的简单插值，必须检验它自己的闭环。','']
    text += ['', '## 七月反例有没有被识别','',
             f"G2七月第113步，这条规则的分数为{july[0]['score']}，是否取消补查为{july[0]['veto']}。原七月反例中那次很小的一步奖励改善，不能仅靠‘同站已观察候选整体较好’识别为长期不划算。",'',
             '这也是需要区分的两件事：','',
             '1. **值得再查吗？** 需要估计还有多少未发现的好动作、查询要花多少计算。已观察站内候选的平均表现，不等于未查询尾部的最大收益。整体较弱的站仍可能藏着少数关键动作。',
             '2. **查到了就应该换动作吗？** 原搜索奖励是一步最大负载率，长期评价还含损耗、再调度等运行成本。站内候选整体都不错，也不能保证其中负载率最低的动作长期最划算。','',
             '本轮只改变触发，不改变奖励或补查动作采用规则。因此即使一个触发条件能省掉无收益查询，也不自动解决七月反例所反映的目标不一致。','',
             '## 研究判断','',
             '本次完成的是对一条可解释触发条件的实际检验，不是证明所有触发条件都无效。'+verdict,
             '不应为了得到漂亮结果，在这25个已暴露场景上继续扫描站内比例、奖励差或负载率阈值。当前更明确的方向是把“查询触发”和“补查动作采用”分开描述：前者追求计算价值，后者决定是否接受微小负载率收益及其成本代价。新增成本条件需要明确目标和可用反馈，不能把事后整周成本当作在线输入。','',
             '本轮未新增学习模型、训练、日期、排序、预算或电网；原方法和全部不利结果保留。尚未找到可替代原规则的可靠新触发条件。','',
             '## 复现与核对','',
             f"- 新闭环回放{R['checks']['new_runs']}条；其余{R['checks']['reused_scenarios']}条为全部保存调用选择不变的轨迹复用。",
             '- 原185个FULL状态、179个FRAME调用、222个独立分数核对与222个隐藏后缀扰动核对通过。控制代码/模型及本轮运行文件584项、数据1817项冻结核对通过。',
             f"- 新运行保存数据：{R['checks']['steps']}步、{R['checks']['vectors']}个向量哈希、{R['checks']['calls']}次搜索、{R['checks']['queries']}条预测反馈，成本与独立策略逻辑核对通过。",
             '- 无独立AC重求解。全部场景来自同一公开电网且已暴露；生成种子与重复日历日期不是新独立场景。',
             '- 冻结规则先于分数提取，冻结包于新回放前推送cc36dde7。脚本、方案、筛查与完整新日志/向量哈希一并归档。']
    (OUT/'GRID93_report.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    dest=REPO/'research_archive/power-grid-2026/protocols/GRID93_trigger/complete';dest.mkdir(parents=True,exist_ok=False)
    files=list(W.glob('*.py'))+[W/'design.json'];vectors=[]
    for p in OUT.rglob('*'):
        if not p.is_file():continue
        if p.suffix=='.npz':vectors.append(dict(path=p.relative_to(ROOT).as_posix(),sha256=sha(p),bytes=p.stat().st_size))
        else:files.append(p)
    zpath=dest/'records.zip';entries=[]
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(set(files)):
            rel=p.relative_to(ROOT).as_posix();data=p.read_bytes();z.writestr(rel,data);entries.append(dict(path=rel,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None
        for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
    (dest/'archive_receipt.json').write_text(json.dumps(dict(zip_sha256=sha(zpath),files=entries,large_vectors_preserved_on_D=vectors,crc_and_hashes_verified=True),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    collab=ROOT/'论文协作资料/FRAME_补查触发条件_20261020';collab.mkdir(exist_ok=True)
    for n in ['GRID93_report.md','review.json','decision.json','per_scenario.csv','screen_summary.json','full_state_screen.csv','actual_frame_state_screen.csv','design.json','preflight.json']:
        for folder in [dest,collab]:shutil.copy2(OUT/n,folder/n);assert sha(OUT/n)==sha(folder/n)
    note=f"单条站内支持否决规则完成：去掉最佳后以成对奖励胜率0.5作负证据门控，无拟合或扫描。185个FULL和179个实际FRAME调用筛查，19场景选择不变复用、6条新闭环。判读{D['category']}，原达标而新规则不达标的场景{len(lost)}个。一步搜索价值与长期动作采用分开，不加第二条规则救结果。所有混合结果保留，无新模型训练或同批提速主张。"
    key='GRID93_TRIGGER_complete'
    for n in ['docs/DECISIONS.md','docs/EXPERIMENT_LOG.md']:
        append(REPO/n,key,'## 2026-10-20 — '+key+'\n\n'+note)
    p=REPO/'docs/RESEARCH_STATE.md';old=p.read_text(encoding='utf-8');first,rest=old.split('\n',1)
    if key not in old:p.write_text(first+'\n\n- **'+key+'：** '+note+'\n'+rest,encoding='utf-8')
    append(REPO/'docs/NEXT_STEPS.md',key,'## '+key+'\n\n'+note+'\n\n先向用户汇报本条触发条件是否成立；当前不自动搜索新阈值或改动作采用目标。')
    append(REPO/'research_archive/power-grid-2026/README.md',key,'## '+key+'\n\n'+note+'\n\n[报告](protocols/GRID93_trigger/complete/GRID93_report.md)')
    print(json.dumps(dict(decision=D,report=str(OUT/'GRID93_report.md'),archived_files=len(entries)),ensure_ascii=False))


if __name__=='__main__':main()
