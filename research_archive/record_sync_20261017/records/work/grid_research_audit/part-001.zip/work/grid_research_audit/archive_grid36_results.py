"""Archive all cheap-rule outcomes, additive timing explanation, and next fair protocol."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];REPO=ROOT/'work/GRL-results-integration';ARCH=REPO/'research_archive/power-grid-2026'
assert json.loads((ROOT/'outputs/grid36/review.json').read_text())['passed_saved_data']
old={}
for p in list(ARCH.glob('*manifest.json'))+list((ARCH/'protocols').glob('*/manifest.json')):
    for row in json.loads(p.read_text(encoding='utf-8')).get('files',[]):
        q=p.parent/row['path']
        if not q.exists():q=ARCH/row['path']
        assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256'],q
        old[str(q)]=row['sha256']
groups={
 'GRID36_completed':list((ROOT/'work/grid36').glob('*.py'))+[p for p in (ROOT/'outputs/grid36').rglob('*') if p.is_file() and (p.suffix in ['.json','.md','.csv'] or p.name=='steps.jsonl.gz')],
 'GRID_search_speed_explanation':[ROOT/'work/grid_research_audit/search_speed_explanation.py',ROOT/'outputs/grid_speed_review/GRID34_INCREMENT.md',ROOT/'outputs/grid_speed_review/GRID34_disjoint_timing.json'],
 'GRID37_before_results':list((ROOT/'work/grid37').glob('*.py'))+[p for p in (ROOT/'outputs/grid37').iterdir() if p.is_file()],
}
counts={}
for name,files in groups.items():
    dest=ARCH/'protocols'/name;assert not dest.exists();dest.mkdir(parents=True)
    records=[]
    for p in sorted(set(files)):
        rel=p.relative_to(ROOT);q=dest/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
        h=hashlib.sha256(q.read_bytes()).hexdigest();assert h==hashlib.sha256(p.read_bytes()).hexdigest()
        records.append({'path':rel.as_posix(),'sha256':h,'bytes':q.stat().st_size})
    (dest/'manifest.json').write_text(json.dumps({'files':records,'historical_preserved':len(old),'scope':name+'; no final-date opening or model training.'},indent=2),encoding='utf-8');counts[name]=len(records)
note='GRID36三月廉价规则闭环核验完成：STATIC_ID成本+0.37200%通过0.5%筛查；PHYSICS_TAIL/LOCAL_STRESS成本+3.61164%/+4.01870%未通过，所有结果保留。静态顺序仅单次资格，不能据跨批时间宣告赢过GNN。GRID37冻结同一共有优化下FULL、两GNN、STATIC_ID四日期两平衡重复共32条，公平区分便宜停止与图模型增量。'
docs=REPO/'docs';p=docs/'RESEARCH_STATE.md';t=p.read_text(encoding='utf-8');p.write_text('# Research state — fair static control and training-target diagnosis\n\n- **最新：** '+note+'\n\n'+t.split('\n',1)[1],encoding='utf-8')
(docs/'NEXT_STEPS.md').write_text('''# Next steps — fair static comparison and target alignment

1. 检查GRID37后台worker/manifest再续32条冻结公平比较；4条臂均用相同缓存、仪表与停止规则，两GNN原权重保留。
2. 完成后核验完整成本/存活/路径/计时和静态顺序；相同0.5%投资门槛逐日期检查，六月共同失败仍保留。非学习顺序不等于去掉整个作者PPO控制器。
3. 仅使用既有训练标签检查soft-rho目标与实际FP32奖励选动作目标的对齐及先验约束；没有足够诊断前不换模块，训练时MLP须获相同标签/改进。
4. 已有11–12%vs共有优化FULL主要由约21.34%搜索部分减少54–55%解释；相对PPO/MLP的图模型总时间增量仅0.1–1.9%。历史10.93%/0.39%精确波动原因不可恢复。
5. 最终8日期封存，LG01暂停；额度暂停不是取消，继续当前任务，不重选题/重问授权/重复完成运行。
''',encoding='utf-8')
for name in ['EXPERIMENT_LOG.md','DECISIONS.md']:
    p=docs/name;p.write_text(p.read_text(encoding='utf-8')+'\n## 2026-10-11 — Cheap order quality and fair static comparator\n\n'+note+' 新旧模型不覆盖，失败规则不原样扩展；先核对训练目标而非堆模块。\n',encoding='utf-8')
p=ARCH/'README.md';p.write_text('# 最新：静态规则资格通过，公平比较与训练目标核对继续\n\n[GRID36完整结果](protocols/GRID36_completed/outputs/grid36/GRID36_report.md) · [10%幅度分解](protocols/GRID_search_speed_explanation/outputs/grid_speed_review/GRID34_INCREMENT.md) · [GRID37冻结](protocols/GRID37_before_results/outputs/grid37/design.json)\n\n'+note+'\n\n'+p.read_text(encoding='utf-8'),encoding='utf-8')
for p,h in old.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
print(json.dumps({'passed':True,'files':counts,'historical_preserved':len(old)}))
