"""Freeze one model revision and record the user's narrower publication scope."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];REPO=ROOT/'work/GRL-results-integration';ARCH=REPO/'research_archive/power-grid-2026'
old={}
for p in list(ARCH.glob('*manifest.json'))+list((ARCH/'protocols').glob('*/manifest.json')):
    for row in json.loads(p.read_text(encoding='utf-8')).get('files',[]):
        q=p.parent/row['path']
        if not q.exists():q=ARCH/row['path']
        assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256'],q
        old[str(q)]=row['sha256']
groups={
 'GRID_target_alignment':[ROOT/'work/grid_research_audit/target_alignment.py']+list((ROOT/'outputs/grid_target_audit').glob('*')),
 'GRID38_before_training':list((ROOT/'work/grid38').glob('*.py'))+list((ROOT/'outputs/grid38').glob('*')),
}
counts={}
for name,files in groups.items():
    dest=ARCH/'protocols'/name;assert not dest.exists();dest.mkdir(parents=True);records=[]
    for p in sorted(set(files)):
        if not p.is_file():continue
        rel=p.relative_to(ROOT);q=dest/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);h=hashlib.sha256(q.read_bytes()).hexdigest()
        assert h==hashlib.sha256(p.read_bytes()).hexdigest();records.append({'path':rel.as_posix(),'sha256':h,'bytes':q.stat().st_size})
    (dest/'manifest.json').write_text(json.dumps({'files':records,'historical_preserved':len(old),'scope':name+'; no new fitting or final evaluation yet.'},indent=2),encoding='utf-8');counts[name]=len(records)
note='按用户投稿目标收敛：主实验只保留2–3个最近且可用的成熟方法，MLP/静态顺序仅少量归因消融，不再扩规则组合。GRID37当前已启动批次跑完保留。训练集167状态/148有效目标峰值均与实际奖励最优对齐，没有代码错误；最优集合原目标均值权重24.44%。GRID38冻结仅改目标为一半原soft标签、一半奖励最优集合均匀标签，原初始化/数据顺序/网络/先验/训练轮数全部相同，两GNN两MLP公平处理；不覆盖原模型、不扫参数。'
docs=REPO/'docs';p=docs/'RESEARCH_STATE.md';t=p.read_text(encoding='utf-8');p.write_text('# Research state — focused model revision after fair timing\n\n- **最新决定：** '+note+'\n\n'+t.split('\n',1)[1],encoding='utf-8')
(docs/'NEXT_STEPS.md').write_text('''# Next steps — focused model improvement

1. 续完已启动GRID37公平静态比较并核验；不再新增廉价规则筛查，已有成功/失败全部保留。
2. GRID37计时worker全部结束后执行GRID38单一目标修订的4次轻量拟合，GNN/MLP都使用相同原初始化和改进，不覆盖历史模型。
3. 用现成26开发状态查看排序和已知关键动作，随后看实际闭环质量及完整控制速度；不把单纯预测指标当贡献。最终8日期仍封存。
4. 投稿范围保持一个明确改进、2–3个相近成熟主对照、少量必要消融。基本权限、公平成本和原始结果记录保留；避免层层追加资格与过量发散。
5. 当前框架为GNN辅助作者PPO控制器的拓扑搜索，目标修改、共有编译复用及GNN+RL组合本身都不是新意保证。额度暂停后继续当前任务，LG01仍暂停。
''',encoding='utf-8')
for name in ['EXPERIMENT_LOG.md','DECISIONS.md']:
    p=docs/name;p.write_text(p.read_text(encoding='utf-8')+'\n## 2026-10-11 — Focused target revision and limited baseline scope\n\n'+note+' 四次拟合尚未运行；与计时worker错开。\n',encoding='utf-8')
p=ARCH/'README.md';p.write_text('# 最新：主对照收敛，单一模型改进已冻结\n\n[训练目标诊断](protocols/GRID_target_alignment/outputs/grid_target_audit/TARGET_ALIGNMENT.md) · [GRID38训练方案](protocols/GRID38_before_training/outputs/grid38/design.json)\n\n'+note+'\n\n'+p.read_text(encoding='utf-8'),encoding='utf-8')
for p,h in old.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
print(json.dumps({'passed':True,'files':counts,'historical_preserved':len(old)}))
