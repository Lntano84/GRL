"""Three real calibration-state shadow calls with their actual forecast context.

Saved vectors alone do not reconstruct forecasts. This bounded check uses a live
old calibration trajectory and returns unchanged FRAME actions after the shadow.
No evaluation dates, parameter selection or efficiency results are produced.
"""
from pathlib import Path
import hashlib,importlib.util,json,os,sys,time,traceback
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid90_expert/live_vector_fixed'
OUT.mkdir(exist_ok=True)
sys.path[:0]=[str(ROOT/'work/grid30'),str(ROOT/'work/grid29'),str(ROOT/'work/grid08'),str(ROOT/'work/grid28')]
from common import make_env,ResidualControl,OptimModule,np,action_vector
from cache_dc import run_dc_cached
from cache_safe import compute_safe_cached
OptimModule.run_dc=run_dc_cached;OptimModule.compute_optimum_safe=compute_safe_cached
from engine import Search
spec=importlib.util.spec_from_file_location('live_expert',W/'adapter.py');A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)


def save(name,x):(OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')


def main():
    assert not (OUT/'live_qualification.json').exists()
    env=make_env();env.seed(0);env.set_id('2035-07-23_10');obs=env.reset()
    ctl=ResidualControl(env,obs);search=Search(env,ctl,'STATIC_ID',128,None);search.policy='FRAME_GUARD'
    A.install(Search,dict(policy='FRAME_GUARD'))
    calls=[];reward=0.;start=time.perf_counter()
    def replacement(observation,base,previous_reward,done=False,**kwargs):
        params=env.parameters.to_dict();before=observation.to_vect().copy();b=action_vector(base).copy()
        count=int(env.nb_highres_called)
        selected,log,_,_=A.expert_search(search,observation,base,previous_reward,done,**kwargs)
        assert np.array_equal(before,observation.to_vect()) and np.array_equal(b,action_vector(base))
        assert env.parameters.to_dict()==params
        assert int(env.nb_highres_called)-count==log['public_queries']
        for r in log['outcomes']:
            future=search._expert_future_template.copy();future.from_vect(search._expert_future_vectors[r['pool_id']])
            assert float(future.rho.max())==r['rho']
        n=len(calls);save(f'live_qualification_call{n:03d}.json',log)
        calls.append(dict(step=int(observation.current_step),timestamp=str(observation.get_time_stamp()),
            query_count=log['public_queries'],candidate_queries=log['candidate_queries'],
            analysis_queries=log['analysis_queries'],chosen=log['chosen_pool_id'],
            root_vector_sha256=hashlib.sha256(before.tobytes()).hexdigest(),
            successful_graphs=sum(a['status']=='ranked' for a in log['expert_analyses'])))
        print(json.dumps(calls[-1]),flush=True)
        # Shadow exploration never changes the calibration controller's action.
        return search.choose(observation,base,previous_reward,done,**kwargs)[0]
    ctl.base.topo_n1_unsafe.get_act=replacement
    try:
        for step in range(1,2018):
            assert time.perf_counter()-start<600
            base,restore,proposal=ctl.propose(obs,reward,cadence=6)
            obs,reward,done,info=env.step(restore if proposal['offered'] else base)
            if len(calls)>=3:break
            if done:break
        assert len(calls)==3 and any(c['successful_graphs'] for c in calls)
        save('live_qualification.json',dict(passed=True,calls=calls,actual_forecasts=True,
            adapter_sha256=hashlib.sha256((W/'adapter.py').read_bytes()).hexdigest(),
            calibration_date='2035-07-23_10',forecast_horizon=1,common_action_and_parameters_unchanged=True,
            shadow_only=True,parameter_selection=False,new_training=0,physical_steps=step,
            wall_s=time.perf_counter()-start,
            saved_vector_check_limit='qualification.json tested interface only: saved vectors do not reconstruct dated forecasts. This live receipt supplies actual forecast-context qualification.'))
    finally:env.close()


if __name__=='__main__':
    try:main()
    except Exception:
        save('live_qualification_error.json',dict(traceback=traceback.format_exc()));raise
