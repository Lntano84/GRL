"""Publishable reports/source/model snapshots; never copy datasets or raw traces."""
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT / "work/GRL-results-integration"
DEST = REPO / "research_archive/power-grid-2026"


def main():
    assert json.loads((ROOT / "outputs/grid_research_audit/GRID22_23_reconciliation.json").read_text())["passed"]
    assert not (DEST / "archive_manifest.json").exists()
    DEST.mkdir(parents=True, exist_ok=True)
    manifest = []

    def copy(p):
        rel = p.relative_to(ROOT)
        target = DEST / rel
        assert target.resolve().is_relative_to(DEST.resolve())
        assert p.stat().st_size <= 10_000_000, rel
        target.parent.mkdir(parents=True,exist_ok=True)
        a = hashlib.sha256(p.read_bytes()).hexdigest()
        if target.exists():
            assert hashlib.sha256(target.read_bytes()).hexdigest() == a, target
        else:
            shutil.copy2(p,target)
        assert hashlib.sha256(target.read_bytes()).hexdigest() == a
        manifest.append({"path":rel.as_posix(),"bytes":p.stat().st_size,"sha256":a})

    stages = []
    for n in range(24):
        output = ROOT / f"outputs/grid{n:02d}"
        source = ROOT / f"work/grid{n:02d}"
        included = []
        if output.is_dir():
            for p in sorted(output.iterdir()):
                if p.is_file() and p.suffix in [".md",".json",".csv",".patch"] and p.stat().st_size <= 4_000_000:
                    copy(p)
                    included.append(p.name)
        if source.is_dir():
            for p in sorted(source.glob("*.py")):
                text = p.read_text(encoding="utf-8-sig")
                import re
                assert not re.search(r"gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}",text),p.name
                copy(p)
        stages.append({"stage":f"GRID{n:02d}","included_root_results":included})
    for n in [20,21]:
        for folder in sorted((ROOT/f"outputs/grid{n}/models").iterdir()):
            if folder.is_dir():
                for name in ["initial.pt","final.pt","curve.json","summary.json"]:
                    copy(folder/name)
    for name in ["GRID22_23_closeout.md","GRID22_23_reconciliation.json","power_model_registry.json","POWER_MODEL_CHANGELOG.md",
                 "DEPLOYMENT_TARGET_CHECK.md","SPLIT_EXPOSURE_CORRECTION.md","split_exposure.json",
                 "GRID22_failure_coverage.json","GRID22_cost_components.json","GRID23_cost_components.json",
                 "GRID22_shared_choice_coverage.json","GRID23_shared_choice_coverage.json",
                 "SAFETY_GUARD_K32_teacher_probe.json","SAFETY_GUARD_K128_teacher_probe.json",
                 "RL_NEXT_ROLE_NOT_STARTED.md"]:
        copy(ROOT/"outputs/grid_research_audit"/name)
    for name in ["cost_components.py","failure_coverage.py","shared_choice_coverage.py","safety_guard_probe.py","closeout22_23.py"]:
        copy(ROOT/"work/grid_research_audit"/name)
    for p in sorted((ROOT/"outputs/grid_final_holdout").iterdir()):
        if p.is_file() and p.suffix in [".md",".json",".sha256"]:
            copy(p)
    (DEST/"archive_manifest.json").write_text(json.dumps({"files":manifest,"stages":stages,
        "included_bytes":sum(r["bytes"] for r in manifest),
        "scope":"Selected reports, root result/audit tables, original-layout source snapshots and V0/V1 initial/final owned model weights. Raw vectors/call archives, large trajectories, intermediate epochs, virtual environments, third-party repositories/PPO models and the RTE dataset stay local; per-stage delivery manifests retain their original hashes. This directory alone is not a full raw-artifact reproduction bundle."},indent=2),encoding="utf-8")
    lines = ["# 电网研究归档（2026-10-10）","",
        "[最新完整裁决](outputs/grid_research_audit/GRID22_23_closeout.md) · [模型保留与改动](outputs/grid_research_audit/POWER_MODEL_CHANGELOG.md) · [机器归档清单](archive_manifest.json)","",
        "GRID22/23共52条预定闭环轨迹完成并通过保存数据审计。K128共同破并列修订缓解了提前失败，但三月成本仍高8.073%，GNN对同预算PPO/MLP/固定偏置的成本增量只有0.015%–0.031%，未过固定门槛。没有新增RL或最终封存评价。原模型和失败结果保留。","",
        "本目录是实验记录与源码快照，不是原IM模型在电网上的直接迁移成绩。当前电网模型是监督候选排序器，加在作者PPO先验及完整工程控制器上；两层图原型的候选解码器、先验残差及同信息MLP均单独记录。GNN＋RL并非首次出现。","",
        "## 包含范围","",
        "- GRID00–23的根目录报告、配置、汇总、审计、更正与原始清单，保留旧版本。部分早期阶段没有Markdown报告，以JSON和后继审计为准。",
        "- 自有Python源码的历史目录布局快照；外部依赖与作者代码不捆绑。",
        "- V0/V1共10个拟合版本的初始权重、最终权重、曲线和摘要（20份权重文件），逐文件SHA-256核对。",
        "- 日期家族切分更正、预留8家族的元数据、当前未启动RL的说明。","",
        "原始大轨迹、逐调用向量、其他历史RL权重和中间epoch、RTE数据集、虚拟环境及作者PPO权重保留在本地，未上传本目录。原阶段delivery_manifest列出的完整文件并非全部包含；这份archive_manifest准确列出本目录实际包含项。不能直接在此运行依赖完整本地轨迹的封存审计。","",
        "## 关键边界","",
        "成本只比较共同完成的周，早失败的低累计成本不计优势。四个周是已暴露开发数据，两种拟合种子不是独立日期。原GRID03测试分区已部分用于后续开发；8个新日期家族的最终评价未开始。单次含记录开销的墙钟不是无日志生产速度基准；模型排名改善不等同于闭环质量改善。","",
        "GRID22曾中断，305个已保存步及至少4,253次预测另记；未落盘在途费用未知，不能当零成本。详情见该阶段报告。","",
        "## 一手背景与外部依赖","",
        "- [Grid2Op](https://github.com/Grid2op/grid2op) 与 [LightSim2Grid](https://github.com/Grid2op/lightsim2grid)。",
        "- [L2RPN 2023 LJN 作者控制器](https://github.com/lajavaness/l2rpn-2023-ljn-agent)；原连续优化及恢复规则保留，外部权重原训练身份未知。",
        "- [软标签 GNN](https://github.com/AI4REALNET/soft_label_gnn) 与[论文](https://arxiv.org/abs/2503.15190)。",
        "- [GNN潜在连接表示](https://github.com/MatthijsdeJ/GNN_PN_Imitation_Learning) 与[论文](https://arxiv.org/abs/2501.07186)。",
        "- [GNN风险代理与Gibbs先验RL](https://arxiv.org/abs/2604.01830)。",
        "只记录已用的代码和已核查的研究背景；没有宣称完整复现上述每种学习方法。源码包含历史路径、数据提取和依赖设定，使用前需按原协议重建目录及外部依赖。","",
        "## 各阶段文件索引","","| 阶段 | 已包含根结果文件 |","|---|---|"]
    for s in stages:
        names=s["included_root_results"]
        preferred=[p for p in names if p.endswith("_report.md") or p.endswith("_review_zh.md")]
        selected=preferred or [p for p in names if p in ["audit.json","finished.json","RUN_STATE.md"]]
        links=" · ".join(f"[{p}](outputs/{s['stage'].lower()}/{p})" for p in selected)
        lines.append(f"| {s['stage']} | {links or '参见归档清单'} |")
    (DEST/"README.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps({"copied_files":len(manifest),"included_bytes":sum(r["bytes"] for r in manifest),"directory":str(DEST)}))


if __name__=="__main__":
    main()
