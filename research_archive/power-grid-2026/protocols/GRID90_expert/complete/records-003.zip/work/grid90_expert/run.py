"""One bounded, resumable serial runner; complete outputs are never repeated."""
from pathlib import Path
import ctypes,datetime as dt,gzip,hashlib,json,os,subprocess,sys,time,traceback
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid90_expert'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))


def save(name,value):
    p=OUT/name;t=p.with_suffix(p.suffix+'.tmp')
    t.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n');os.replace(t,p)


def complete(folder,result):
    s=read(folder/'summary.json');assert s==read(result)
    assert (folder/'components.json').exists() and (folder/'vectors.npz').exists()
    with gzip.open(folder/'steps.jsonl.gz','rt',encoding='utf-8') as f:assert sum(1 for _ in f)==s['steps']
    return s


def main():
    handle=ctypes.windll.kernel32.CreateMutexW(None,True,'GRL_GRID90_SERIAL_BENCHMARK')
    assert ctypes.windll.kernel32.GetLastError()!=183,'Another GRID90 runner exists'
    D=read(OUT/'design.json');assert read(OUT/'preflight.json')['passed']
    for name in ['code_freeze.json','data_freeze.json']:
        for p,h in read(OUT/name).items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
    start=time.monotonic();rows=read(OUT/'manifest.json')['summaries'] if (OUT/'manifest.json').exists() else []
    existing={(s['week'],s['method'],s['repeat']) for s in rows}
    assert len(existing)==len(rows)
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:
        for index,item in enumerate(D['execution_order']):
            key=(item['week'],item['method'],item['repeat'])
            if key in existing:continue
            assert time.monotonic()-start<D['caps']['wall_s']
            folder=OUT/'runs'/f"r{item['repeat']}__{item['week']}__{item['method']}";result=OUT/f'worker_result_{index:02d}.json'
            if folder.exists():
                if result.exists():
                    rows.append(complete(folder,result));existing.add(key);save('manifest.json',dict(planned=24,summaries=rows));continue
                raise RuntimeError(f'Partial output retained; recovery inspection required: {folder}')
            save('pipeline_state.json',dict(phase='benchmark',completed=len(rows),planned=24,index=index,item=item,pid=os.getpid()))
            (OUT/'RUN_STATE.md').write_text(f'RUNNING:{len(rows)}/24 complete; one serial worker; all outcomes retained.\n',encoding='utf-8')
            env=os.environ.copy();env['PYTHONHASHSEED']='0'
            with (OUT/f'worker_{index:02d}.log').open('a',encoding='utf-8') as log:
                proc=subprocess.Popen([sys.executable,'-u',str(W/'worker.py'),'--index',str(index)],cwd=ROOT,env=env,
                    stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                save('active_worker.json',dict(pid=proc.pid,parent=os.getpid(),index=index,item=item))
                try:code=proc.wait(timeout=D['caps']['episode_s']+120)
                except subprocess.TimeoutExpired:
                    subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT);proc.wait(timeout=60);raise
            assert code==0,(index,code)
            s=complete(folder,result);rows.append(s);existing.add(key)
            save('manifest.json',dict(planned=24,summaries=rows))
            print(json.dumps(dict(completed=len(rows),planned=24,index=index,method=item['method'])),flush=True)
        assert len(rows)==24
        assert sum(r['steps'] for r in rows)<=D['caps']['physical_steps']
        assert sum(r['public_forecasts'] for r in rows)<=D['caps']['public_forecasts']
        save('finished.json',dict(passed_engineering=True,summaries=rows,wall_s=time.monotonic()-start,new_training=0))
        save('pipeline_state.json',dict(phase='runs_complete',completed=24,planned=24))
    finally:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        ctypes.windll.kernel32.ReleaseMutex(handle);ctypes.windll.kernel32.CloseHandle(handle)


if __name__=='__main__':
    try:main()
    except BaseException:
        save('benchmark_error.json',dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(),traceback=traceback.format_exc()));raise
