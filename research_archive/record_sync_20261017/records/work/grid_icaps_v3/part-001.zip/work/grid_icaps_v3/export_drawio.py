from pathlib import Path
import subprocess,os
HERE=Path(__file__).resolve().parent
OUT=Path('D:/Codex/GRL研究/outputs/grid_icaps_v3/figures')
EXE=Path('D:/Codex/tools/drawio-32.4.1/draw.io.exe')
env=dict(os.environ,TEMP=str(HERE),TMP=str(HERE),APPDATA='D:/Codex/tools/drawio-profile',LOCALAPPDATA='D:/Codex/tools/drawio-profile',DRAWIO_DISABLE_UPDATE='true')
for name in ['motivation','method']:
 for ext in ['svg','pdf','png']:
  cmd=[str(EXE),'--export','--format',ext,'--theme','light','--border','8','--output',str(OUT/f'{name}.{ext}'),str(OUT/f'{name}.drawio'),'--user-data-dir=D:/Codex/tools/drawio-profile','--disable-update']
  if ext=='svg':cmd+=['--embed-diagram','--embed-svg-images','--embed-svg-fonts','false']
  if ext=='pdf':cmd+=['--crop']
  if ext=='png':cmd+=['--scale','2.5']
  with (HERE/f'drawio_{name}_{ext}.log').open('w',encoding='utf-8') as f:
   p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW,timeout=90)
  assert p.returncode==0 and (OUT/f'{name}.{ext}').exists(),(name,ext,p.returncode)
  print(name,ext,flush=True)
