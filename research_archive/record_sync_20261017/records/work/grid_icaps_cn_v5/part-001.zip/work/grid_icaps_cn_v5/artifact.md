# V5 document execution contract

{
  "source": "D:\\Codex\\GRL研究\\outputs\\grid_icaps_cn_v4\\ICAPS2027_中文全文修订稿_V4.docx",
  "sha256": "0ff838a83f6a90c0ba1f56d09c0d7155d16a4d67a8446091debe070618f640a2",
  "page_mm": [
    210.00861111111112,
    297.0036111111111
  ],
  "margins_mm": [
    21.007916666666667,
    21.007916666666667,
    21.995694444444446,
    21.995694444444446
  ],
  "sections": 1,
  "paragraphs": 97,
  "tables": 3,
  "native_equations": 3,
  "retain": "Original source untouched; method body and native formulas copied intact; revise title/abstract/introduction/results/conclusion/related work for new evidence in a separate V5. Original A4 page geometry and named styles retained.",
  "guide_basis": "Prior full-guide reading and 49-item audit in outputs/grid_icaps_cn_v4; latest Feishu refresh and browser tool unavailable, so no claim of a new full read.",
  "visual_reference": "Existing work/grid_icaps_cn_v4/render_final; inspect final new pages after timing finishes."
}

Scientific charts are regenerated from completed audited results in editable SVG/vector PDF, 300dpi PNG; no invented confidence intervals. Tables provide compact parallel numerical fields. Headers/captions follow the retained source. New sections may extend pagination; do not shrink text to imitate the old page count.
