"""Freeze a finite two-arm comparison; all choices precede evaluation."""
from pathlib import Path
import ast,datetime as dt,hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid90_expert'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def save(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')


def main():
    assert not (OUT/'design.json').exists()
    live=read(OUT/'live_vector_fixed/live_qualification.json');assert live['passed'] and live['actual_forecasts']
    assert live['adapter_sha256']==sha(W/'adapter.py')
    old=read(ROOT/'outputs/grid89_review/sealed/design.json')
    methods=[dict(method=p,policy=p,rule='STATIC_ID',budget=128 if p=='FRAME_GUARD' else 25,checkpoint=None,
                  cache_dc=True,cache_safe=True,order_mode='STATIC_ID')
             for p in ['FRAME_GUARD','EXPERTOP_SHARED']]
    matrix=[]
    for repeat in range(2):
        for date in old['weeks'] if repeat==0 else old['weeks'][::-1]:
            block=methods if (old['weeks'].index(date)+repeat)%2==0 else methods[::-1]
            matrix.extend(dict(m,week=date,repeat=repeat,stage_phase='all') for m in block)
    commit=subprocess.check_output(['git','-C',str(W/'vendor/ExpertOp4Grid'),'rev-parse','HEAD'],text=True).strip()
    baseline_source=read(W/'vendor/ExpertAgent/source_receipt.json')
    design=dict(stage='GRID90_EXPERTOP_SHARED_CLOSED_LOOP',frozen_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        authorization='User: begin the ExpertOp heuristic comparison under unified conditions.',
        weeks=old['weeks'],methods=methods,execution_order=matrix,repeats=2,pilot=[],
        environment=old['environment'],environment_seed=0,quality_threshold=.005,
        timing=old['timing'],caps=dict(episode_s=1800,wall_s=10800,physical_steps=60000,public_forecasts=2000000),
        expert=dict(version='0.3.3',commit=commit,repository='https://github.com/ainetus/ExpertOp4Grid',
            agent_reference_commit=baseline_source['commit'],candidate_cap_per_line=25,candidate_cap_per_station=5,
            maximum_monitored_overloads=3,graph_threshold=.2,forecast_horizon=1,
            original_paper='Marot et al., MEDPOWER2018, Expert System for topological remedial action discovery in smart grids',
            label='ExpertOp4Grid structure-ranking adaptation on a common candidate library',
            adaptations=['Restrict native topology scores to common eligible/deduplicated candidate library, following the original paper historical-library setting.',
                'Keep all representative IDs even when storage-omitting expert projections tie.',
                'Common action composition and admissibility/reward/tie rule determine returned action.',
                'Use ordinary one-step public line-cut forecasts for influence graph; never override simulator protection/action-limit parameters.',
                'When common controller triggers below rho1, analyze largest loaded active line; otherwise native overload priority, up to3.',
                'Retain native overload success scores4/critical3 for outer-loop stopping; no own reconnection/restoration controller.',
                'Charge diagnostic line-cut forecasts as well as candidate forecasts and graph/ranking cost.',
                'Preserve official default25/5/3, no budget tuning, no global fallback added.'],
            limits=['Not full original ExpertAgent or original paper benchmark reproduction.',
                    'Current source ranks storage-free generator/load/line elements; common controller retains storage actions. Projection ties retain every legal representative.',
                    'Unavailable legal public line-cut counterfactual is logged; cannot interpret such oracle incompatibility as failure of the original method.']),
        quality_reference='GRID89 sealed FULL repeat0, survival/horizon/comparable complete-week cost only; no old FULL timing.',
        frame_reference='Must reproduce GRID89 sealed FRAME_GUARD stepwise; no model/controller/threshold/budget changes.',
        decision=dict(equal_quality='Both6/6 quality and all six date horizons identical',
            compute='FRAME macro controller and matching-active query reductions>=5%, >=4/6 positive time dates, both repeat macro reductions>0.',
            otherwise='Report quality/compute tradeoff, competitiveness, or graph-oracle incompatibility. Preserve every result; no budget or date changes.'),
        scope='Six already exposed same-grid/calendar G2 series; timing repeats are not independent scenarios. No new training or new scenarios.')
    save('design.json',design)
    for path in W.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
    worker=(W/'worker.py').read_text(encoding='utf-8')
    assert 'old_init=ResidualControl.__init__' in worker
    save('preflight.json',dict(passed=True,live_qualification='outputs/grid90_expert/live_vector_fixed/live_qualification.json',
         old_calibration_only=True,shared_pool=True,common_oracle=True,parameter_override=False,
         total_replays=24,new_training=0,budget_selection=False))
    base=read(ROOT/'outputs/grid89_review/code_freeze.json')
    for rel,expected in base.items():assert sha(ROOT/rel)==expected,rel
    extra=[*W.glob('*.py'),OUT/'design.json',OUT/'preflight.json',OUT/'live_vector_fixed/live_qualification.json',
           W/'vendor/ExpertAgent/expertAgent.py',W/'vendor/ExpertAgent/source_receipt.json',
           W/'vendor/ExpertOp4Grid/LICENSE',W/'vendor/ExpertOp4Grid/README.md']
    extra.extend((W/'vendor/ExpertOp4Grid/alphaDeesp').rglob('*.py'))
    extra.extend(p for p in (W/'deps').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    for path in extra:base[path.relative_to(ROOT).as_posix()]=sha(path)
    save('code_freeze.json',base)
    inherited=read(ROOT/'outputs/grid89_review/data_freeze.json')
    data={p:h for p,h in inherited.items() if p.startswith(design['environment']+'/')}
    assert data and all(sha(ROOT/p)==h for p,h in data.items())
    save('data_freeze.json',data)
    save('source_receipt.json',dict(expert_repository='https://github.com/ainetus/ExpertOp4Grid',commit=commit,
        agent_reference=baseline_source,paper_local_sha256=sha(W/'vendor/ExpertOp4Grid/_LARGE__bf_Expert_System_for_topological_remedial_action_discovery_in_smart_grids.pdf'),
        dependencies=dict(pydot='3.0.4',rustworkx='0.17.1',install_scope='work/grid90_expert/deps; --no-deps, original scientific runtime not upgraded'),
        code_files=len(base),data_files=len(data)))
    (OUT/'RUN_STATE.md').write_text('FROZEN:24 serial runs, two arms/six exposed G2 scenarios/two reverse timing repeats; preflight passed.\n',encoding='utf-8',newline='\n')
    print(json.dumps(dict(planned=24,code_files=len(base),data_files=len(data),source_commit=commit)),flush=True)


if __name__=='__main__':main()
