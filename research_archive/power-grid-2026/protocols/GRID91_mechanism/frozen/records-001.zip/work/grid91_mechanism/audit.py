"""Saved-vector, feedback and cost audit, plus first-divergence attribution."""
from pathlib import Path
import gzip,hashlib,importlib.util,json,math,os,statistics,sys
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid91_mechanism'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))


def steps(folder):
    with gzip.open(folder/'steps.jsonl.gz','rt',encoding='utf-8') as f:return [json.loads(x) for x in f]


def trajectory_signature(folder):
    rows=steps(folder)
    return hashlib.sha256(json.dumps([(r['before_hash'],r['action_hash'],r['after_hash'],r['raw_cost'],r['done'],r['complete']) for r in rows],separators=(',',':')).encode()).hexdigest()


def load(name,path):
    s=importlib.util.spec_from_file_location(name,ROOT/path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m


def save(name,x):(OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def main():
    D=read(OUT/'design.json');S=read(OUT/'finished.json')['summaries'];assert len(S)==28
    for freeze in ['code_freeze.json','data_freeze.json']:
        for rel,h in read(OUT/freeze).items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h,rel
    sys.path[:0]=[str(ROOT/'work/grid30'),str(ROOT/'work/grid29'),str(ROOT/'work/grid08'),str(ROOT/'work/grid28')]
    from common import grid2op,LightSimBackend,MaxRhoReward,operational_other_rewards,np,ResidualControl,action_vector,graph_features
    from engine import Search
    P=load('grid91_audit_p','work/grid91_mechanism/policies.py')
    V=load('grid91_audit_original','work/grid89_review/policies.py')
    I=load('grid91_audit_independent','work/grid89_review/reference_logic.py')
    digest=lambda v:hashlib.sha256(np.ascontiguousarray(v).tobytes()).hexdigest()
    checks=dict(steps=0,calls=0,queries=0,vectors=0,legal_feedback=0,independent_policy=0,public_context=0,qualification_trajectories=0)
    runrows=[]
    for cohort in ['old13','G1','G2']:
        refs=[r for r in D['references'] if r['cohort']==cohort]
        env=grid2op.make(str(ROOT/refs[0]['environment']),test=True,backend=LightSimBackend(),reward_class=MaxRhoReward,other_rewards=operational_other_rewards())
        template=env.reset();ctl=ResidualControl(env,template);search=Search(env,ctl,'STATIC_ID',128,None);nb=int(env.nb_highres_called)
        try:
            for s in [x for x in S if x['cohort']==cohort]:
                folder=OUT/'runs'/f"r0__{s['week']}__{s['method']}";assert read(folder/'summary.json')==s
                rs=steps(folder);assert len(rs)==s['steps']
                assert abs(math.fsum(r['raw_cost'] for r in rs)-s['cost'])<1e-6
                assert abs(math.fsum(r['decision_s'] for r in rs)-s['controller_s'])<1e-6
                assert sum(r['simulations'] for r in rs)==s['public_forecasts']
                assert s['illegal']==s['ambiguous']==0
                with np.load(folder/'vectors.npz') as z:
                    assert len(z['action'])==len(z['observation'])==len(rs)
                    for j,r in enumerate(rs):
                        assert digest(z['action'][j])==r['action_hash'] and digest(z['observation'][j])==r['after_hash'];checks['vectors']+=2
                        if j:assert r['before_hash']==rs[j-1]['after_hash']
                        if r['ledger'] is not None:assert abs(r['ledger']['recomputed_raw_cost']-r['raw_cost'])<=r['ledger_tolerance']
                        if r['exceptions']:assert r['done']
                ref=next(r for r in refs if r['week']==s['week'])
                sig=trajectory_signature(folder)
                if s['purpose']=='environment_qualification':
                    assert sig==trajectory_signature(ROOT/ref['frame']);checks['qualification_trajectories']+=1
                calls=sorted(folder.glob('call[0-9][0-9][0-9].json'));assert len(calls)==s['n1_calls']
                assert sum(read(p)['public_queries'] for p in calls)==s['n1_forecasts']
                for p in calls:
                    c=read(p)
                    with np.load(p.with_name(p.stem+'_state.npz')) as z:
                        obs=template.copy();obs.from_vect(z['observation']);base=env.action_space();base.from_vect(z['base_action'])
                    assert digest(obs.to_vect())==c['state_hash']
                    eligible,reps,aliases,actions,changed=search.prepare(obs,base)
                    assert sorted(reps)==c['order'] and reps==c['representatives']
                    assert aliases=={int(k):int(v) for k,v in c['aliases'].items()}
                    truth={r['pool_id']:r for r in c['outcomes']};assert len(truth)==len(c['outcomes'])==c['public_queries']
                    for r in c['outcomes']:
                        assert r['strict_admissible']==bool(0<r['rho']<c['rho_limit'] and not r['done'] and not r['exceptions'] and not r['illegal'] and not r['ambiguous'])
                        assert r['combined_hash']==digest(action_vector(actions[r['pool_id']]+base));checks['legal_feedback']+=1
                    with np.load(p.with_name(p.stem+'_inputs.npz')) as z:
                        xx,ee,gg=graph_features(obs,env,dict(offered=False,predictions=[None,None]))
                        assert np.array_equal(xx,z['x']) and np.array_equal(ee,z['edges']) and np.array_equal(gg,z['glob']);checks['public_context']+=1
                    def execute(module):
                        seen=[]
                        def reveal(i,phase):
                            assert i in truth and i not in seen and truth[i]['phase']==phase;seen.append(i);return truth[i]
                        result=module.run(c['order'],reveal,s['policy'],search.subids,aliases,limit=c['rho_limit'])
                        for field in ['chosen_pool_id','public_queries','stop_reason','local_queries','completion_budget','extra_selected_ids']:
                            assert result[field]==c[field],(p,field)
                        assert seen==[r['pool_id'] for r in c['outcomes']]
                    execute(P);execute(V)
                    plan,choice,budget=I.replay(c['order'],truth,search.subids,aliases,s['policy'],dict(V.DEFAULT,qmin=0))
                    assert plan==[r['pool_id'] for r in c['outcomes']] and choice==c['chosen_pool_id'] and budget==c['completion_budget'];checks['independent_policy']+=1
                    if s['policy']=='NO_LOCAL':assert c['local_queries']==0 and not c['extra_selected_ids']
                    if choice is not None:
                        best=max((r for r in c['outcomes'] if r['strict_admissible']),key=I.k);assert best['pool_id']==choice
                        assert digest(action_vector(actions[choice]))==c['returned_action_hash']
                    checks['calls']+=1;checks['queries']+=c['public_queries']
                components=read(folder/'components.json')
                opt=math.fsum(x['wall_s'] for x in components['calls'] if x['in_control'])
                fore=s['all_forecast_s'];over=s['n1_source_s']-s['n1_forecast_s'];rest=s['controller_s']-opt-fore-over
                assert min(opt,fore,over,rest)>=-1e-6
                latency=[x['decision_s'] for x in rs];trigger={read(p)['step'] for p in calls};active=[x['decision_s'] for x in rs if x['step'] in trigger]
                runrows.append(dict(cohort=cohort,week=s['week'],method=s['method'],purpose=s['purpose'],steps=s['steps'],complete=s['complete'],cost=s['cost'],queries=s['n1_forecasts'],controller_s=s['controller_s'],all_p95=float(np.percentile(latency,95)),search_p95=float(np.percentile(active,95)) if active else None,optimizer_s=opt,forecast_s=fore,search_overhead_s=over,remainder_s=rest,trajectory_signature=sig))
                checks['steps']+=len(rs)
            assert int(env.nb_highres_called)==nb,'Audit must not issue forecasts'
        finally:env.close()

    comparisons=[];divergences=[]
    for ref in D['references']:
        no=next(s for s in S if s['week']==ref['week'] and s['policy']=='NO_LOCAL')
        a=ROOT/ref['frame'];b=OUT/'runs'/f"r0__{ref['week']}__NO_LOCAL_FINAL"
        frame=read(a/'summary.json');full=read(ROOT/ref['full']/'summary.json')
        def quality(s):
            costgap=s['cost']/full['cost']-1 if s['complete'] and full['complete'] else None
            passed=(bool(s['complete']) if full['complete'] else s['steps']>=full['steps']) and (costgap is None or costgap<=D['quality_threshold'])
            return bool(passed),costgap
        fq,fc=quality(frame);nq,nc=quality(no)
        comparisons.append(dict(cohort=ref['cohort'],week=ref['week'],full_steps=full['steps'],full_complete=full['complete'],
                                frame_steps=frame['steps'],frame_complete=frame['complete'],frame_quality=fq,frame_cost_delta_full=fc,frame_queries=frame['n1_forecasts'],
                                no_local_steps=no['steps'],no_local_complete=no['complete'],no_local_quality=nq,no_local_cost_delta_full=nc,no_local_queries=no['n1_forecasts'],
                                no_local_cost_delta_frame=no['cost']/frame['cost']-1 if no['complete'] and frame['complete'] else None,
                                same_horizon=frame['steps']==no['steps'] and frame['complete']==no['complete'],
                                qualification_prevents_quality_failure=fq and not nq))
        fs,ns=steps(a),steps(b);common=min(len(fs),len(ns))
        diff=next((j for j in range(common) if fs[j]['action_hash']!=ns[j]['action_hash']),None)
        entry=dict(cohort=ref['cohort'],week=ref['week'],first_action_divergence_step=None if diff is None else fs[diff]['step'],common_steps=common,
                   first_difference_is_local_selection=None,shared_state_base=None)
        if diff is None:
            assert all(fs[j]['after_hash']==ns[j]['after_hash'] for j in range(common))
        else:
            assert all(fs[j]['after_hash']==ns[j]['after_hash'] for j in range(diff))
            assert fs[diff]['before_hash']==ns[diff]['before_hash']
            step=fs[diff]['step'];ap=[p for p in a.glob('call[0-9][0-9][0-9].json') if read(p)['step']==step];bp=[p for p in b.glob('call[0-9][0-9][0-9].json') if read(p)['step']==step]
            entry['search_call_counts_at_difference']=[len(ap),len(bp)]
            if len(ap)==len(bp)==1:
                ca,cb=read(ap[0]),read(bp[0])
                with np.load(ap[0].with_name(ap[0].stem+'_state.npz')) as az,np.load(bp[0].with_name(bp[0].stem+'_state.npz')) as bz:
                    same=np.array_equal(az['observation'],bz['observation']) and np.array_equal(az['base_action'],bz['base_action'])
                entry['shared_state_base']=bool(same)
                if same:
                    aa=[r for r in ca['outcomes'] if r['phase']!='local_completion'];bb=cb['outcomes']
                    fields=['pool_id','phase','rho','reward','done','strict_admissible','illegal','ambiguous','exceptions']
                    assert [{k:r[k] for k in fields} for r in aa]==[{k:r[k] for k in fields} for r in bb]
                    assert ca['pre_extra_choice']==cb['chosen_pool_id']
                    local=ca['chosen_pool_id']!=ca['pre_extra_choice'] and ca['local_queries']>0
                    entry.update(first_difference_is_local_selection=local,frame_pre_extra_choice=ca['pre_extra_choice'],frame_final_choice=ca['chosen_pool_id'],no_local_choice=cb['chosen_pool_id'],frame_queries=ca['public_queries'],no_local_queries=cb['public_queries'],local_queries=ca['local_queries'])
        divergences.append(entry)
    assert len(comparisons)==25 and checks['qualification_trajectories']==3
    save('first_divergences.json',divergences)
    save('review.json',dict(passed_saved_data=True,runs=28,deletion_scenarios=25,checks=checks,comparisons=comparisons,new_run_descriptive_metrics=runrows,
                            reused_frame_quality_and_queries=True,independent_ac_resolve=False,audit_forecasts=0,
                            no_cross_batch_speed_claim=True,scope='Exposed same-grid mechanism regression; saved vectors, feedback, public candidates/context and cost arithmetic, not independent AC re-solving.'))
    print(json.dumps(dict(passed_saved_data=True,checks=checks,frame_pass=sum(x['frame_quality'] for x in comparisons),no_local_pass=sum(x['no_local_quality'] for x in comparisons)),ensure_ascii=False))


if __name__=='__main__':main()
