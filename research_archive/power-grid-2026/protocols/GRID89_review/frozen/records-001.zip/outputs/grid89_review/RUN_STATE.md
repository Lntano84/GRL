FROZEN: independent generation plan; experiment implementation/preflight pending. No new control outcomes.
