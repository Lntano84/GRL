# 先设计后制图

2026-10-14，在改写Methods后，从头逐节阅读飞书《论文画图指南》及其18个配图案例，再形成以下规格。本文中图号按动机、方法、主结果、案例排列。

## 图1 动机图

**Caption先行：** Global rankings interleave substation configurations; FRAME completes an identified substation while avoiding exhaustive comparison of unrelated groups.

必要元素：同一排序的候选、变电站分组颜色、早停边界、已识别变电站、尚未比较的同站配置、FRAME的局部补全。左中右三幅依次表现观察、早停留下的局部空缺、本文如何解决。采用动机案例1的对比和案例2的抽象表达；候选条带为概念示意，不虚构仿真奖励或试验数量。图例解释颜色、虚线边框和已查询标记。

## 图2 方法主图

**Caption先行：** FRAME uses query feedback to limit global evaluation and completes the selected substation before returning a topology proposal.

必要元素与流转：当前观测x与基础动作b → Candidate preparation → 代表池A及别名M → Progressive evaluation → Substation completion → 拓扑提案；预测仿真产生奖励、负载率和有效性反馈；反馈更新incumbent与未改善批次数，控制是否继续。首批直接返回分支与扩展后补全分支分开画出。接入原连续控制和恢复。

布局：总体从左到右；中心突出两个贡献模块，上下展示首批、扩展、反馈；局部补全居右且与输出连接。按照方法案例2的模块分层、案例3的图例和案例4的输入分区组织。灰色表示共有准备/控制，蓝色表示全局评估，浅棕表示结构补全，绿色表示输出；实线是主数据流，虚线是反馈。所有模块名与Methods一致；图标来自同一Lucide SVG线性图标组（ISC许可证保留）。使用draw.io原生节点与连线，保留可编辑.drawio和矢量SVG/PDF。

## 图3 主结果与计时重复

**Caption先行：** FRAME reduces candidate evaluation under matched survival outcomes; the two timing repetitions expose the variability of actual controller time.

必要元素：四个固定方法、开发/确认分组、完整数字表、查询节省、控制时间节省、质量通过数和整周成本；实际时间的两个重复均呈现。方法和配色在各面板一致，FRAME以颜色和标记突出；轴、单位、方向、图例与分母明确。采用主结果表的分块与强调方式，参照曲线案例2呈现重复变动，但使用实际两次测量点及其范围，不绘制虚构置信带。数据直接读取GRID61/62 CSV，用Matplotlib/Seaborn生成PDF/SVG及PNG。

## 图4 局部补全案例

**Caption先行：** In the March case, 198 local queries recover FULL's selected action; closed-loop ablation reduces the date's cost increase from 4.810% to 0.372%.

左侧：1733步NO_LOCAL→FRAME→FULL的查询数及动作编号。右侧：同一日期整周成本变化。两种尺度分别标识，避免把单步动作与整周结果混成一个数。图内直接标出变化，参考曲线案例1的数值标注。该图用作实验机制解释；图1负责一般动机，分工清楚。

## 共用视觉标准

白底、Arial图中文字、低饱和配色、3–5种功能颜色；数据图从零基线开始；矢量优先，保留许可；在7英寸左右双栏宽度检查，最小字型至少8pt。图标统一线宽；连接线避开模块文字，反馈线型有图例。每张图先查看独立导出，再查看论文中的实际大小。
