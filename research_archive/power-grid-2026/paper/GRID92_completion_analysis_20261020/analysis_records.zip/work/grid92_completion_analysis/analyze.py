"""Saved-feedback mechanism analysis. Does not import a simulator or controller."""
from pathlib import Path
from collections import defaultdict, Counter
from itertools import combinations
import csv, gzip, hashlib, importlib.util, json, math, statistics
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
W = Path(__file__).parent
OUT = ROOT / 'outputs/grid92_completion_analysis'
SOURCES = {}
EPS = 1e-6


def source(p):
    p = Path(p)
    rel = p.relative_to(ROOT).as_posix()
    if rel not in SOURCES:
        SOURCES[rel] = dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(), bytes=p.stat().st_size)
    return p


def read(p):
    return json.loads(source(p).read_text(encoding='utf-8'))


def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def csvsave(name, rows):
    if not rows:
        return
    with (OUT / name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, list(rows[0])); w.writeheader(); w.writerows(rows)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, source(ROOT / path))
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m


def avg(a):
    a = [x for x in a if x is not None]
    return statistics.mean(a) if a else None


def reward(r):
    return float(np.float32(r['reward']))


def best(rows):
    return max((r for r in rows if r['strict_admissible']), key=lambda r: (reward(r), -r['pool_id']), default=None)


def random_best(gains, q):
    """Analytic E[max(0,gain)] for a uniform q-subset, without replacement."""
    n = len(gains)
    assert 0 <= q <= n
    if not q or not any(g > 0 for g in gains):
        return 0., 0.
    denominator = math.lgamma(n+1)-math.lgamma(q+1)-math.lgamma(n-q+1)
    def p_hit(k):
        if n-k < q:
            return 1.
        log_no = math.lgamma(n-k+1)-math.lgamma(q+1)-math.lgamma(n-k-q+1)-denominator
        return min(1., max(0., -math.expm1(min(0., log_no))))
    counts = Counter(g for g in gains if g > 0)
    running, previous, expectation = sum(counts.values()), 0., 0.
    for g in sorted(counts):
        expectation += (g-previous)*p_hit(running)
        previous = g; running -= counts[g]
    return expectation, p_hit(sum(g > EPS for g in gains))


def check_random():
    cases = 0
    for gains in ([0., .1, .2, .2, 0.], [0., 0., 0.], [.03], [.1, .1, .1, .4]):
        for q in range(len(gains)+1):
            samples = list(combinations(gains, q))
            mean = avg([max((0.,)+x) for x in samples])
            prob = avg([float(any(g > EPS for g in x)) for x in samples])
            a, b = random_best(gains, q)
            assert abs(a-mean) < 1e-12 and abs(b-prob) < 1e-12
            cases += 1
    return cases


def state_summary(rows):
    rr = [r for r in rows if r['triggered']]
    def macro(field):
        by = defaultdict(list)
        for r in rr:
            by[r['week']].append(r[field])
        return avg([avg(v) for v in by.values()])
    return dict(full_states=len(rows), valid_full_best=sum(r['full_reward'] is not None for r in rows),
                triggered=len(rr), trigger_scenarios=len({r['week'] for r in rr}),
                local_improves=sum(r['local_gain'] > EPS for r in rr),
                global_improves=sum(r['global_gain'] > EPS for r in rr),
                local_vs_global_wins=sum(r['local_minus_global'] > EPS for r in rr),
                local_vs_global_losses=sum(r['local_minus_global'] < -EPS for r in rr),
                local_vs_global_ties=sum(abs(r['local_minus_global']) <= EPS for r in rr),
                local_vs_uniform_wins=sum(r['local_minus_uniform'] > EPS for r in rr),
                local_vs_uniform_losses=sum(r['local_minus_uniform'] < -EPS for r in rr),
                mean_local_gain=avg([r['local_gain'] for r in rr]),
                mean_global_gain=avg([r['global_gain'] for r in rr]),
                mean_uniform_expected_gain=avg([r['uniform_expected_gain'] for r in rr]),
                mean_local_minus_global=avg([r['local_minus_global'] for r in rr]),
                mean_local_minus_uniform=avg([r['local_minus_uniform'] for r in rr]),
                scenario_macro_local_minus_global=macro('local_minus_global'),
                scenario_macro_local_minus_uniform=macro('local_minus_uniform'),
                mean_local_density=avg([r['local_density'] for r in rr]),
                mean_other_density=avg([r['other_density'] for r in rr]),
                mean_density_difference=avg([r['density_difference'] for r in rr]),
                enriched_states=sum((r['density_difference'] or 0) > 1e-12 for r in rr),
                depleted_states=sum((r['density_difference'] or 0) < -1e-12 for r in rr),
                local_queries=sum(r['local_q'] for r in rr),
                local_improving_candidates=sum(r['local_improvers'] for r in rr),
                other_queries=sum(r['other_n'] for r in rr),
                other_improving_candidates=sum(r['other_improvers'] for r in rr))


FEATURES = {
    'initial_safe': [False, True],
    'incumbent_changed_after_prefix': [False, True],
    'q_bin': ['1-64', '65-128', '>128'],
    'fraction_bin': ['<=0.1', '(0.1,0.3]', '>0.3'],
    'gap_bin': ['<=1e-4', '(1e-4,1e-3]', '>1e-3', 'only_one_admissible'],
    'rho_bin': ['<0.9', '[0.9,1)', '>=1']}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    plan = read(W/'plan.json'); save('plan.json', plan)
    source(Path(__file__))
    P = module('grid92_default', 'work/grid91_mechanism/policies.py')
    I = module('grid92_independent', 'work/grid89_review/reference_logic.py')
    for p in ['work/grid03/score_adapter.py','work/grid02/ljn_nn/LJNAgent.py','work/grid02/ljn_nn/modules/rewards.py']:
        source(ROOT/p)
    subs = read(ROOT/'outputs/grid28/offline.json')['public_subids']
    design = read(ROOT/'outputs/grid91_mechanism/design.json')
    previous_review = read(ROOT/'outputs/grid91_mechanism/review.json')
    assert previous_review['passed_saved_data']
    rows, check = [], dict(random_enumeration=check_random(), independent_replays=0, full_states=0,
                           alias_local_sets=0, equal_budget_rows=0, ledger_steps=0, input_pairs=0)
    for ref in design['references']:
        for path in sorted((ROOT/ref['full']).glob('call[0-9][0-9][0-9].json')):
            c = read(path); truth = {r['pool_id']: r for r in c['outcomes']}
            order = c['order']; aliases = {int(k): v for k, v in c['aliases'].items()}
            assert len(truth) == len(order) == len(c['outcomes'])
            assert set(truth) == set(order)
            for o in truth.values():
                assert o['strict_admissible'] == bool(0 < o['rho'] < c['rho_limit'] and not o['done'] and not o['illegal'] and not o['ambiguous'] and not o['exceptions'])
            got = {}
            for policy in ['NO_LOCAL', 'FRAME_GUARD', 'GLOBAL_MATCH']:
                seen = []
                def reveal(i, phase):
                    assert i not in seen; seen.append(i)
                    return dict(truth[i], phase=phase)
                z = P.run(order, reveal, policy, subs, aliases)
                independent, choice, budget = I.replay(order, truth, subs, aliases, policy, dict(P.DEFAULT, qmin=0))
                assert seen == independent and choice == z['chosen_pool_id'] and budget == z['completion_budget']
                got[policy] = z; check['independent_replays'] += 1
            nl, lc, gl = [got[k] for k in ['NO_LOCAL', 'FRAME_GUARD', 'GLOBAL_MATCH']]
            assert lc['public_queries'] == gl['public_queries']
            bg, bf = best(nl['outcomes']), best(c['outcomes'])
            remaining = [i for i in order if i not in {r['pool_id'] for r in nl['outcomes']}]
            q = lc['completion_budget']; local_ids = lc['completion_candidate_ids']; local_set = set(local_ids)
            assert q == len(local_ids) and q <= len(remaining)
            if q:
                sub = int(subs[bg['pool_id']])
                expected_set = {rep for alias, rep in aliases.items() if subs[alias] == sub}
                assert local_ids == [i for i in remaining if i in expected_set]
                check['alias_local_sets'] += 1
            rr = dict(cohort=ref['cohort'], week=ref['week'], call=path.stem, step=c['step'],
                      full_source=path.relative_to(ROOT).as_posix(), candidates=len(order),
                      global_queries=nl['public_queries'], remaining=len(remaining), local_q=q,
                      local_station=lc['local_substation'], triggered=bool(q),
                      initial_safe=nl['prefix_safe_at_entry'],
                      incumbent_changed_after_prefix=nl['pre_extra_choice'] != nl['shortlist_choice'],
                      global_choice=nl['chosen_pool_id'], local_choice=lc['chosen_pool_id'], next_global_choice=gl['chosen_pool_id'],
                      full_choice=None if bf is None else bf['pool_id'], full_reward=None if bf is None else reward(bf),
                      incumbent_reward=None if bg is None else reward(bg), incumbent_rho=None if bg is None else bg['rho'],
                      local_gain=None, global_gain=None, uniform_expected_gain=None, uniform_hit_probability=None,
                      local_minus_global=None, local_minus_uniform=None, local_density=None, other_density=None,
                      density_difference=None, local_improvers=0, other_improvers=0, other_n=len(remaining)-q,
                      local_fraction=None, observed_reward_gap=None, q_bin=None, fraction_bin=None, gap_bin=None, rho_bin=None)
            if q:
                base = reward(bg)
                def gain(i):
                    return max(0., reward(truth[i])-base) if truth[i]['strict_admissible'] else 0.
                gains = [gain(i) for i in remaining]
                local_gain = reward(best(lc['outcomes']))-base
                global_gain = reward(best(gl['outcomes']))-base
                uniform, hit = random_best(gains, q)
                local_count = sum(gain(i) > EPS for i in local_ids)
                other_count = sum(gain(i) > EPS for i in remaining if i not in local_set)
                other_n = len(remaining)-q
                ordered_valid = sorted((reward(r) for r in nl['outcomes'] if r['strict_admissible']), reverse=True)
                gap = ordered_valid[0]-ordered_valid[1] if len(ordered_valid)>1 else None
                fraction = q/len(remaining)
                rr.update(local_gain=local_gain, global_gain=global_gain, uniform_expected_gain=uniform,
                          uniform_hit_probability=hit, local_minus_global=local_gain-global_gain,
                          local_minus_uniform=local_gain-uniform, local_density=local_count/q,
                          other_density=other_count/other_n if other_n else None,
                          density_difference=local_count/q-other_count/other_n if other_n else None,
                          local_improvers=local_count, other_improvers=other_count, local_fraction=fraction,
                          observed_reward_gap=gap, q_bin='1-64' if q<=64 else '65-128' if q<=128 else '>128',
                          fraction_bin='<=0.1' if fraction<=.1 else '(0.1,0.3]' if fraction<=.3 else '>0.3',
                          gap_bin='only_one_admissible' if gap is None else '<=1e-4' if gap<=1e-4 else '(1e-4,1e-3]' if gap<=1e-3 else '>1e-3',
                          rho_bin='<0.9' if bg['rho']<.9 else '[0.9,1)' if bg['rho']<1 else '>=1')
                assert local_gain >= 0 and global_gain >= 0
            rows.append(rr); check['full_states'] += 1
    assert len(rows) == 185
    csvsave('per_state.csv', rows)
    scenarios = []
    for ref in design['references']:
        scenarios.append(dict(cohort=ref['cohort'], week=ref['week'], **state_summary([r for r in rows if r['week']==ref['week']])))
    csvsave('per_scenario.csv', scenarios)
    cohorts = [dict(cohort=g, **state_summary([r for r in rows if r['cohort']==g])) for g in ['old13', 'G1', 'G2']]
    save('cohorts.json', cohorts)
    stations, concentration = [], []
    for g in ['old13', 'G1', 'G2']:
        rr = [r for r in rows if r['cohort']==g and r['triggered']]
        for station in sorted({r['local_station'] for r in rr}):
            ss = [r for r in rr if r['local_station']==station]
            stations.append(dict(cohort=g,station=station,states=len(ss),
                                 scenarios=len({r['week'] for r in ss}),
                                 queries=sum(r['local_q'] for r in ss),
                                 improving_states=sum(r['local_gain']>EPS for r in ss),
                                 reward_gain_sum=sum(r['local_gain'] for r in ss),
                                 local_minus_global_sum=sum(r['local_minus_global'] for r in ss)))
        largest = max(rr,key=lambda r:r['local_gain'])
        concentration.append(dict(cohort=g,largest_gain_week=largest['week'],largest_gain_step=largest['step'],
                                  largest_gain=largest['local_gain'],
                                  largest_share_of_total_local_gain=largest['local_gain']/sum(r['local_gain'] for r in rr),
                                  leave_one_state_out_local_minus_global_min=min(avg([x['local_minus_global'] for x in rr if x is not omitted]) for omitted in rr),
                                  leave_one_state_out_local_minus_global_max=max(avg([x['local_minus_global'] for x in rr if x is not omitted]) for omitted in rr),
                                  purpose='Post-analysis descriptive concentration check, not parameter or case selection'))
    csvsave('target_station_summary.csv',stations); save('gain_concentration.json',concentration)
    features = []
    for g in ['old13', 'G1', 'G2']:
        for feature, bins in FEATURES.items():
            for b in bins:
                rr = [r for r in rows if r['cohort']==g and r['triggered'] and r[feature]==b]
                features.append(dict(cohort=g, feature=feature, bin=b, n=len(rr), scenarios=len({r['week'] for r in rr}),
                                     local_improves=sum(r['local_gain']>EPS for r in rr),
                                     local_beats_global=sum(r['local_minus_global']>EPS for r in rr),
                                     local_loses_global=sum(r['local_minus_global'] < -EPS for r in rr),
                                     mean_local_gain=avg([r['local_gain'] for r in rr]),
                                     mean_local_minus_global=avg([r['local_minus_global'] for r in rr]),
                                     mean_local_minus_uniform=avg([r['local_minus_uniform'] for r in rr])))
    csvsave('observable_feature_bins.csv', features)
    lookup = {(r['week'], r['call']): r for r in rows}
    for old_path, old_style in [('outputs/grid85_mechanism/equal_budget_pairs.csv', True), ('outputs/grid89_review/sealed_equal_budget_pairs.csv', False)]:
        with source(ROOT/old_path).open(encoding='utf-8-sig', newline='') as f:
            for prior in csv.DictReader(f):
                r = lookup[prior['date'], prior['call']]
                empty = not prior['local_reward_gain'] if old_style else not prior['local_minus_global_reward']
                if empty:
                    assert r['full_reward'] is None
                    if old_style: assert not prior['global_reward_gain']
                    delta = 0.
                else:
                    delta = float(prior['local_reward_gain'])-float(prior['global_reward_gain']) if old_style else float(prior['local_minus_global_reward'])
                assert abs((r['local_minus_global'] or 0)-delta) < 1e-10
                assert r['local_q'] == int(prior['extra_queries'])
                check['equal_budget_rows'] += 1

    divergences = read(ROOT/'outputs/grid91_mechanism/first_divergences.json')
    cases, windows, details = [], [], []
    def steps(folder):
        with gzip.open(source(folder/'steps.jsonl.gz'), 'rt', encoding='utf-8') as f:
            return [json.loads(line) for line in f]
    component_map = dict(loss='losses_mwh', redispatch='redispatch_mwh', curtailment_delta='curtailment_delta_mwh', storage='storage_throughput_mwh')
    def components(rs):
        return {k: math.fsum(r['ledger']['marginal_cost']*r['ledger'][field] for r in rs if r['ledger'] is not None) for k, field in component_map.items()}
    for ref in design['references']:
        folder_f = ROOT/ref['frame']; folder_n = ROOT/'outputs/grid91_mechanism/runs'/f"r0__{ref['week']}__NO_LOCAL_FINAL"
        sf, sn = read(folder_f/'summary.json'), read(folder_n/'summary.json')
        a, b = steps(folder_f), steps(folder_n)
        assert len(a)==len(b) and len(a)==sf['steps']==sn['steps']
        assert abs(math.fsum(r['raw_cost'] for r in a)-sf['cost']) < 1e-6
        assert abs(math.fsum(r['raw_cost'] for r in b)-sn['cost']) < 1e-6
        for rs in [a,b]:
            for j,r in enumerate(rs):
                if j: assert r['before_hash']==rs[j-1]['after_hash']
                if r['ledger'] is not None:
                    computed = sum(r['ledger']['marginal_cost']*r['ledger'][field] for field in component_map.values())
                    assert abs(computed-r['raw_cost']) <= r['ledger_tolerance']+1e-9
                    check['ledger_steps'] += 1
        first = next((j for j,(x,y) in enumerate(zip(a,b)) if x['action_hash']!=y['action_hash']), None)
        prev = next(d for d in divergences if d['week']==ref['week'])
        assert (None if first is None else a[first]['step']) == prev['first_action_divergence_step']
        fc, nc = components(a), components(b)
        case = dict(cohort=ref['cohort'], week=ref['week'], complete=sf['complete'] and sn['complete'],
                    steps=len(a), divergence_step=None if first is None else a[first]['step'],
                    frame_cost=sf['cost'], no_local_cost=sn['cost'], no_local_vs_frame_pct=100*(sn['cost']/sf['cost']-1),
                    frame_minus_no_cost=sf['cost']-sn['cost'],
                    predicted_reward_gain=None, predicted_rho_before=None, predicted_rho_after=None,
                    local_queries_first=None, later_different_actions=0, first_step_frame_minus_no=None,
                    predicted_combined_equals_delivered_frame=None, predicted_combined_equals_delivered_no=None,
                    first_frame_restore=None, first_no_restore=None,
                    first_frame_continuous_solver_calls=None, first_no_continuous_solver_calls=None,
                    loss_delta=fc['loss']-nc['loss'], redispatch_delta=fc['redispatch']-nc['redispatch'],
                    curtailment_delta_cost=fc['curtailment_delta']-nc['curtailment_delta'], storage_delta=fc['storage']-nc['storage'],
                    ledger_residual_delta=(sf['cost']-sum(fc.values()))-(sn['cost']-sum(nc.values())),
                    frame_curtailed_mwh=math.fsum(r['ledger']['curtailed_mwh'] for r in a if r['ledger']),
                    no_local_curtailed_mwh=math.fsum(r['ledger']['curtailed_mwh'] for r in b if r['ledger']),
                    frame_n1_calls=sf['n1_calls'], no_local_n1_calls=sn['n1_calls'],
                    frame_queries=sf['n1_forecasts'], no_local_queries=sn['n1_forecasts'])
        if first is not None:
            assert all((x['before_hash'],x['after_hash'],x['raw_cost'])==(y['before_hash'],y['after_hash'],y['raw_cost']) for x,y in zip(a[:first],b[:first]))
            assert a[first]['before_hash']==b[first]['before_hash']
            selected = []
            for folder in [folder_f, folder_n]:
                pairs = [(p,read(p)) for p in sorted(folder.glob('call[0-9][0-9][0-9].json'))]
                at = [(p,c) for p,c in pairs if c['step']==a[first]['step']]
                assert len(at)==1; selected.append(at[0])
            (pf,cf),(pn,cn)=selected
            with np.load(source(pf.with_name(pf.stem+'_state.npz'))) as z: obs_f=z['observation']; base_f=z['base_action']
            with np.load(source(pn.with_name(pn.stem+'_state.npz'))) as z: obs_n=z['observation']; base_n=z['base_action']
            assert np.array_equal(obs_f,obs_n) and np.array_equal(base_f,base_n)
            check['input_pairs'] += 1
            tf={r['pool_id']:r for r in cf['outcomes']}; tn={r['pool_id']:r for r in cn['outcomes']}
            assert cf['pre_extra_choice']==cn['chosen_pool_id']
            for i,r in tn.items():
                assert all(r[k]==tf[i][k] for k in ['rho','reward','done','illegal','ambiguous','exceptions','strict_admissible','combined_hash'])
            old,new=tf[cf['pre_extra_choice']],tf[cf['chosen_pool_id']]
            optim_counts=[]
            for folder in [folder_f,folder_n]:
                comp=read(folder/'components.json')
                optim_counts.append(sum(r['in_control'] and r['step']==a[first]['step'] and r['phase']=='compute_optimum_unsafe' for r in comp['calls']))
            if new['combined_hash']!=a[first]['action_hash']: assert optim_counts[0]>0
            if old['combined_hash']!=b[first]['action_hash']: assert optim_counts[1]>0
            case.update(predicted_reward_gain=reward(new)-reward(old), predicted_rho_before=old['rho'], predicted_rho_after=new['rho'],
                        local_queries_first=cf['local_queries'],
                        predicted_combined_equals_delivered_frame=new['combined_hash']==a[first]['action_hash'],
                        predicted_combined_equals_delivered_no=old['combined_hash']==b[first]['action_hash'],
                        first_frame_restore=a[first]['restore'],first_no_restore=b[first]['restore'],
                        first_frame_continuous_solver_calls=optim_counts[0],first_no_continuous_solver_calls=optim_counts[1],
                        later_different_actions=sum(x['action_hash']!=y['action_hash'] for x,y in zip(a[first+1:],b[first+1:])),
                        first_step_frame_minus_no=a[first]['raw_cost']-b[first]['raw_cost'])
            for horizon in [1,6,12,48,288,len(a)-first]:
                aa,bb=a[first:first+horizon],b[first:first+horizon]
                end=a[min(len(a)-1,first+horizon-1)]['step']
                af,bf=components(aa),components(bb)
                windows.append(dict(cohort=ref['cohort'],week=ref['week'], requested_horizon=horizon,
                                    actual_steps=len(aa),from_step=a[first]['step'],through_step=end,
                                    frame_minus_no_cost=math.fsum(x['raw_cost'] for x in aa)-math.fsum(x['raw_cost'] for x in bb),
                                    **{k+'_delta':af[k]-bf[k] for k in af},
                                    different_actions=sum(x['action_hash']!=y['action_hash'] for x,y in zip(aa,bb))))
            details.append(dict(cohort=ref['cohort'],week=ref['week'],frame_source=pf.relative_to(ROOT).as_posix(),
                                no_local_source=pn.relative_to(ROOT).as_posix(),old_outcome=old,new_outcome=new,
                                first_frame_step=a[first],first_no_local_step=b[first]))
        else:
            assert all((x['before_hash'],x['after_hash'],x['raw_cost'])==(y['before_hash'],y['after_hash'],y['raw_cost']) for x,y in zip(a,b))
        assert abs(sum(case[k] for k in ['loss_delta','redispatch_delta','curtailment_delta_cost','storage_delta','ledger_residual_delta'])-case['frame_minus_no_cost']) < 1e-6
        cases.append(case)
    assert check['input_pairs']==14
    csvsave('closed_loop_cases.csv', cases); csvsave('cost_windows.csv',windows); save('first_divergence_evidence.json',details)
    save('source_receipt.json', SOURCES)
    save('verification.json',dict(passed=True,checks=check,source_files=len(SOURCES),
                                  new_simulations=0,new_closed_loop_replays=0,new_training=0,
                                  interpretation='Saved feedback replay and ledger accounting only, no independent AC re-solving or learned completion trigger'))
    print(json.dumps(dict(cohorts=cohorts, checks=check, reversal=next(c for c in cases if c['week']=='2036-07-07_10')),ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
