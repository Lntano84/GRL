# GRID08: trained auxiliary restoration controller

The original LJN NN20 topology agent and its unsafe convex controller remain unchanged. A separate safe convex optimizer proposes restoring accumulated continuous controls. A binary learned policy accepts or declines that candidate. This pilot does not learn topology-action ranking and does not establish that GNN + RL itself is novel.

## Artifacts and versions

`outputs/grid08/design.json` defines V0. V1 and V2 have separate design files in their output directories, generated runners, initial/episode/final checkpoints, optimization logs, per-step logs and saved physical-cost vectors. `outputs/grid08/CHANGELOG.md` records changes and failed engineering runs. No recorded experiment is overwritten.

- V0: shared actor/critic representation, all-step PPO advantage normalization.
- V1: independent common critic, offered-only actor optimization, bootstrap critic independent of proposal fields.
- V2: load V1, shift policy bias toward the qualified fixed restoration rule using training-only probabilities; continue four training passes at half the learning rate. Critic and input-dependent policy differences are retained.

Each encoder sees the same legal node/global inputs and connectivity. MLP uses a padded edge table; GNN uses two message-passing layers. Critic architecture differs between V0 and later versions but is common to the two encoders within each version. Parameter counts and compute are retained.

## Execution

Use the already configured Python environment at `work/grid02/.venv/Scripts/python.exe`. Installing or upgrading libraries is unnecessary for reproducing this pilot. Processes use one Torch thread and CPU; neural updates are a small part of total simulator time. Commands below are run from the workspace root.

```powershell
& work/grid02/.venv/Scripts/python.exe work/grid08/preflight.py
& work/grid02/.venv/Scripts/python.exe work/grid08/pilot.py --phase train --kind gnn
& work/grid02/.venv/Scripts/python.exe work/grid08/pilot.py --phase train --kind mlp
& work/grid02/.venv/Scripts/python.exe work/grid08/pilot.py --phase evaluate
& work/grid02/.venv/Scripts/python.exe work/grid08/pilot.py --phase evaluate --kind gnn
& work/grid02/.venv/Scripts/python.exe work/grid08/pilot.py --phase evaluate --kind mlp
```

Completed phase directories refuse reruns to protect results. Reproduction therefore requires a distinct output version and a preserved design, rather than deleting original outputs. V1/V2 creation scripts also refuse to overwrite their generated source. Incomplete episodes have logs but do not automatically resume; saved episode-boundary checkpoints include optimizer state and Torch RNG. Do not claim seamless resume of a mid-episode run.

The interrupted V2 attempt is retained. `prepare_resume.py` generated separate resume runners and a checked move plan; the resumed run restores the last completed episode's model, Adam and Torch RNG and restarts only the incomplete episode. `resume_audit.py` checks interrupted prefixes and accounting. The prepare script is a one-time recovery operation and must not be rerun over completed results. Its interrupted steps are extra costs, not valid additional training episodes.

For each completed version run `audit_report.py --version v0` (or `v1`/`v2`); after all three versions finish run `delivery_report.py`. The combined report compares later versions with the frozen V0 fixed baselines on the same weeks. Baselines are not re-tuned for each model.

`ramp_counterexample.py` separates public forecast branches from privileged actual diagnostic branches. `guard_qualification.py` and its preserved resume version compare two fixed rules on training weeks only; `guard_audit.py` checks saved vectors. `credit_diagnostic.py` measures offered-decision spacing and algebraic GAE trace weights, not causal effects or policy regret. `failure_audit.py` categorizes actual archived terminal feedback without assigning its cause to a previous restoration action. Sources and implementation limitations are in `outputs/grid08/literature_failure_review.md`.

## Interpretation

Rank survival/completion before cost. Cost reductions are computed only between jointly completed full weeks. Training failures and cumulative cost from partial weeks are retained, never presented as savings. Exact equality of action/state hashes is reported separately from similar aggregate cost.

The one-step forecast screen is a qualification filter, not a safety guarantee. Public forecast simulations are allowed and charged by simulation counts. The model has no access to hidden future chronics. The final test is not used for fitting, tuning or scoring in this development pilot.

The NN20 control is instrumented with the same proposal generation as every other arm, so these episode wall times are not pure original-agent deployment timings. Independent auditing checks persisted cost vectors, arithmetic, action hashes, completion, original-asset hashes and counts; it is not a second independent power-flow replay or RF/neural fit. The first previous-curtailment value is a retained ledger input, not independently reconstructed from a saved full initial observation.

Improvements over NN20 may come from adding restoration. Added learning value requires comparison with ALWAYS_RESTORE and IMMEDIATE_COST, with their survival differences explicitly included. A policy reproducing a fixed rule provides no evidence of a superior learned state-conditioned choice.
