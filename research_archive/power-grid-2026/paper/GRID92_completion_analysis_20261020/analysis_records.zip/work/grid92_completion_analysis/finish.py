"""Verify, package and copy the completed offline analysis; no simulations."""
from pathlib import Path
import csv, hashlib, json, shutil, zipfile

ROOT=Path(__file__).resolve().parents[2]
W=Path(__file__).parent
OUT=ROOT/'outputs/grid92_completion_analysis'
REPO=ROOT/'work/GRL-results-integration'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def append_once(p, key, text):
    old=p.read_text(encoding='utf-8')
    if key not in old:p.write_text(old.rstrip()+'\n\n'+text.strip()+'\n',encoding='utf-8')


def main():
    verification=read(OUT/'verification.json'); assert verification['passed']
    sources=read(OUT/'source_receipt.json')
    for rel,s in sources.items():assert sha(ROOT/rel)==s['sha256'],rel
    c=read(OUT/'cohorts.json')
    assert [(r['triggered'],r['local_vs_global_wins'],r['local_vs_global_losses']) for r in c]==[(70,13,0),(18,3,1),(25,4,0)]
    assert sum(r['local_improves'] for r in c)==29
    with (OUT/'closed_loop_cases.csv').open(encoding='utf-8-sig',newline='') as f:cases=list(csv.DictReader(f))
    different=[r for r in cases if r['divergence_step']]
    complete=[r for r in different if r['complete']=='True']
    assert len(different)==14 and len(complete)==13
    assert sum(float(r['no_local_vs_frame_pct'])>0 for r in complete)==8
    assert sum(float(r['no_local_vs_frame_pct'])<0 for r in complete)==5
    assert sum(r['predicted_combined_equals_delivered_frame']==r['predicted_combined_equals_delivered_no']=='True' for r in different)==6
    july=next(r for r in cases if r['week']=='2036-07-07_10')
    assert abs(float(july['no_local_vs_frame_pct'])+6.1230828119)<1e-8
    assert july['first_frame_continuous_solver_calls']==july['first_no_continuous_solver_calls']=='0'
    verification.update(source_hashes_rechecked=len(sources), report_counts_checked=True,
                        complete_divergence_cases=13,frame_lower_cost=8,frame_higher_cost=5,
                        exact_delivered_candidate_pairs=6)
    (OUT/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    decision=dict(category='CONDITIONAL_LOCAL_ENRICHMENT_NO_RELIABLE_TRIGGER_AND_SURROGATE_COST_MISMATCH',
                  q1='Same-station remaining candidates show per-query enrichment; equal-budget gains in old13/G2, reversed mean in G1; concentrated effects.',
                  q2='No stable pre-completion decision rule established from predefined observable bins; no rule or threshold changed.',
                  q3='G2 July first tiny rho improvement precedes higher loss and redispatch cost. Later actions also diverge; no single-action whole-week attribution.',
                  retain_completion_as_conditional_module=True,new_training=0,new_simulations=0,new_policy_choices=0,
                  no_cross_grid_claim=True,all_cases_retained=True)
    (OUT/'decision.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    dest=REPO/'research_archive/power-grid-2026/paper/GRID92_completion_analysis_20261020'
    assert not (dest/'archive_receipt.json').exists(),'Preserve existing archive; inspect instead of overwriting'
    dest.mkdir(parents=True,exist_ok=True)
    files=sorted([p for p in OUT.iterdir() if p.is_file()]+[p for p in W.iterdir() if p.suffix in ['.py','.json']])
    zpath=dest/'analysis_records.zip'; entries=[]
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:
            rel=p.relative_to(ROOT).as_posix();z.write(p,rel);entries.append(dict(path=rel,sha256=sha(p),bytes=p.stat().st_size))
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None
        for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
    (dest/'archive_receipt.json').write_text(json.dumps(dict(zip=zpath.name,sha256=sha(zpath),files=entries,crc_and_hashes_verified=True),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    collab=ROOT/'论文协作资料/FRAME_同站补查三问_20261020';collab.mkdir(exist_ok=True)
    for p in OUT.iterdir():
        if not p.is_file():continue
        shutil.copy2(p,collab/p.name);assert sha(p)==sha(collab/p.name)
    for name in ['GRID92_report.md','cohorts.json','decision.json','verification.json','per_state.csv','per_scenario.csv','observable_feature_bins.csv','closed_loop_cases.csv','cost_windows.csv','target_station_summary.csv','gain_concentration.json','source_receipt.json','plan.json']:
        shutil.copy2(OUT/name,dest/name);assert sha(OUT/name)==sha(dest/name)
    key='GRID92_COMPLETION_ANALYSIS_complete'
    note='同站补查三问完成仅保存记录分析，无新仿真/训练。185个FULL状态、113个触发补查状态：等预算同站对全局后缀20好/1差/92相当；候选级改进密度三组更高，但G1奖励幅度均值反向，G2收益高度集中。预先列出的可见特征未建立稳定触发判据。G2七月一步rho仅降约0.000044而整周成本高78078.900，不补查低6.1231%，差额主要为损耗与再调度；后续258个不同动作，不作首动作全部归因。保留条件模块，不改阈值。'
    for name in ['docs/DECISIONS.md','docs/EXPERIMENT_LOG.md']:
        append_once(REPO/name,key,'## 2026-10-20 — '+key+'\n\n'+note)
    state=REPO/'docs/RESEARCH_STATE.md';old=state.read_text(encoding='utf-8')
    if key not in old:
        first,rest=old.split('\n',1);state.write_text(first+'\n\n- **'+key+'：** '+note+'\n'+rest,encoding='utf-8')
    append_once(REPO/'research_archive/power-grid-2026/README.md',key,'## '+key+'\n\n'+note+'\n\n[报告与逐项证据](paper/GRID92_completion_analysis_20261020/GRID92_report.md)')
    nxt=REPO/'docs/NEXT_STEPS.md';old=nxt.read_text(encoding='utf-8')
    history=REPO/'docs/history/NEXT_STEPS_before_grid92_20261020.md'
    if not history.exists():history.write_text(old,encoding='utf-8')
    nxt.write_text('''# Next steps — ACM e-Energy 2027 provisional

1. GRID91机制去留和GRID92同站补查三问均已完成，先与用户讨论条件性收益、收益集中、补查触发尚不可靠及目标不一致；不根据反例自动改规则、加阈值或学习模型。
2. 整理稿件时以前缀初始化、反馈控制深度、结构引导补查位置解释现有方法。默认q_min256冗余已验证；旧冻结源码与所有不利结果保留。不要把搜索一步奖励改善写成整周成本必然改善。
3. 第二电网与比例预算是后续待确认阶段：先资格检查动作库、别名、预测与控制底座；参数只由源网确定，不在目标测试集重调。本轮未自动进入。
4. CCMA仍是领域学习基线候选，作者实现/权重尚未定位；不贸然训练或按会议名称替换META/ExpertOp，旧比较保留。
5. 机制定型及必要验证后编写e-Energy稿件；不追加普通对照堆数量，也不自动启动学习/智能体探索。

当前材料：research_archive/power-grid-2026/paper/GRID92_completion_analysis_20261020/GRID92_report.md。
此前计划保存在docs/history/NEXT_STEPS_before_grid92_20261020.md。
''',encoding='utf-8')
    print(json.dumps(dict(verified_sources=len(sources),files=len(entries),archive=str(dest),collaboration=str(collab)),ensure_ascii=False))


if __name__=='__main__':main()
