"""Use the unchanged GRID91 public-interface adapter with the frozen new policy."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
source=ROOT/'work/grid91_mechanism/adapter.py'
code=source.read_text(encoding='utf-8')
assert code.count("ROOT/'work/grid91_mechanism/policies.py'")==1
code=code.replace("ROOT/'work/grid91_mechanism/policies.py'","ROOT/'work/grid93_trigger/policies.py'")
exec(compile(code,str(source),'exec'),globals())
