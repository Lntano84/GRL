"""Descriptive exogenous-series coverage; not used to select scenes or models."""
from pathlib import Path
import csv,json
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'outputs/grid89_review'
def main():
 D=json.loads((OUT/'design.json').read_text(encoding='utf-8'));rows=[]
 for cohort,folder,suffix in [('seed20261016',ROOT/'work/grid80/fresh_env','9'),('seed20261017',ROOT/D['environment'],str(D['scenario_id']))]:
  for day in D['dates']:
   base=folder/'chronics'/(day+'_'+suffix)
   for quantity,name in [('demand_MW','load_p'),('generation_MW','prod_p')]:
    x=pd.read_csv(base/(name+'.csv.bz2'),sep=';').to_numpy()[:2017].sum(1);delta=np.diff(x)
    rows.append(dict(cohort=cohort,date=day,quantity=quantity,n=len(x),minimum=float(x.min()),p05=float(np.quantile(x,.05)),median=float(np.median(x)),p95=float(np.quantile(x,.95)),maximum=float(x.max()),mean=float(x.mean()),max_abs_5min_change=float(np.abs(delta).max())))
 with (OUT/'input_coverage.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
 print(json.dumps(dict(series=len(rows),scope='Same calendar months and generator distribution; new stochastic seed, no rescaling, outcome filtering or claimed guaranteed wider coverage. Descriptive only.')))
if __name__=='__main__':main()
