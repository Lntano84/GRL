"""Existing controller/timing worker with explicit expert input and output vectors."""
from pathlib import Path
import argparse,json,os,sys
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid90_expert'
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
ap=argparse.ArgumentParser();ap.add_argument('--index',type=int,required=True);args=ap.parse_args()
D=json.loads((OUT/'design.json').read_text(encoding='utf-8'));item=D['execution_order'][args.index]
source=ROOT/'work/grid55/run.py'
code=source.read_text(encoding='utf-8').replace("OUT=ROOT/'outputs/grid55'","OUT=ROOT/'outputs/grid90_expert'")
marker='    old_init=ResidualControl.__init__;old_propose=ResidualControl.propose'
assert code.count(marker)==1
patch="""    import importlib.util
    ss=importlib.util.spec_from_file_location('grid90_expert_adapter',ROOT/'work/grid90_expert/adapter.py')
    aa=importlib.util.module_from_spec(ss);ss.loader.exec_module(aa);aa.install(engine.Search,item)
    import common
    def expert_env():
        return common.grid2op.make(str(ROOT/D['environment']),test=True,backend=common.LightSimBackend(),reward_class=common.MaxRhoReward,other_rewards=common.operational_other_rewards())
    common.make_env=expert_env
    worker_source=(ROOT/'work/grid55/worker.py').read_text(encoding='utf-8')
    annotation='                for r in log["outcomes"]: r["combined_hash"] = digest(action_vector(actions[r["pool_id"]] + base_action))'
    assert worker_source.count(annotation)==1
    vector_save='''                if log.get("policy")=="EXPERTOP_SHARED":
                    ids=[r["pool_id"] for r in log["outcomes"]]
                    future_vectors=[search._expert_future_vectors[i] for i in ids]
                    for rr,v in zip(log["outcomes"],future_vectors):rr["future_hash"]=digest(v)
                    np.savez_compressed(path/f"call{number:03d}_expert_futures.npz",pool_ids=np.asarray(ids,dtype=np.int64),vectors=np.stack(future_vectors) if future_vectors else np.empty((0,len(state)),dtype=np.float32))
'''
    worker_source=worker_source.replace(annotation,vector_save+annotation)
    ns={'__file__':str(ROOT/'work/grid55/worker.py'),'__name__':'grid90_shared_worker'}
    exec(compile(worker_source,str(ROOT/'work/grid55/worker.py'),'exec'),ns)
    ns['OUT']=OUT;worker.worker=ns['worker']
"""
code=code.replace(marker,patch+marker)
sys.argv=[str(source),'--worker',str(args.index)]
exec(compile(code,str(source),'exec'),{'__file__':str(source),'__name__':'__main__'})
