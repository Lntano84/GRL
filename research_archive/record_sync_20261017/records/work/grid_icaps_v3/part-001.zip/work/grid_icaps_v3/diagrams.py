from pathlib import Path
from lxml import etree as E
import urllib.parse,json
ROOT=Path('D:/Codex/GRL研究');OUT=ROOT/'outputs/grid_icaps_v3/figures';OUT.mkdir(exist_ok=True)
INK='#263B4D';BLUE='#427894';BROWN='#B18451';GREEN='#56877E';GRAY='#8D99A4'
class Diagram:
 def __init__(self,name,width,height):
  self.name=name;self.n=1;self.file=E.Element('mxfile',host='draw.io',version='32.4.1');d=E.SubElement(self.file,'diagram',name=name)
  self.model=E.SubElement(d,'mxGraphModel',dx=str(width),dy=str(height),grid='1',gridSize='10',guides='1',tooltips='1',connect='1',arrows='1',fold='1',page='0',pageScale='1',pageWidth=str(width),pageHeight=str(height),background='#FFFFFF')
  self.root=E.SubElement(self.model,'root');E.SubElement(self.root,'mxCell',id='0');E.SubElement(self.root,'mxCell',id='1',parent='0')
 def vertex(self,text,x,y,w,h,style):
  self.n+=1;ident=str(self.n);c=E.SubElement(self.root,'mxCell',id=ident,value=text,style=style,vertex='1',parent='1')
  g=E.SubElement(c,'mxGeometry',x=str(x),y=str(y),width=str(w),height=str(h));g.set('as','geometry');return ident
 def text(self,text,x,y,w,h,size=24,color=INK,bold=False,align='left'):
  return self.vertex(text,x,y,w,h,f'text;html=0;whiteSpace=wrap;align={align};verticalAlign=middle;fontFamily=Arial;fontSize={size};fontColor={color};fontStyle={1 if bold else 0};strokeColor=none;fillColor=none;')
 def box(self,title,body,x,y,w,h,color=BLUE,fill='#EEF4F7',icon=None):
  node=self.vertex('',x,y,w,h,f'rounded=1;arcSize=10;whiteSpace=wrap;html=0;fillColor={fill};strokeColor={color};strokeWidth=2;')
  if icon:self.icon(icon,x+18,y+17,38,color)
  self.text(title,x+65 if icon else x+15,y+10,w-80 if icon else w-30,60 if '\n' in title else 36,24,INK if color==GRAY else color,True)
  off=82 if '\n' in title else 57
  self.text(body,x+18,y+off,w-36,h-off-10,24,INK)
  return node
 def icon(self,name,x,y,size,color=INK):
  text=(OUT/'icons'/f'{name}.svg').read_text(encoding='utf-8').replace('currentColor',color)
  image='data:image/svg+xml,'+urllib.parse.quote(text,safe='')
  self.vertex('',x,y,size,size,f'shape=image;imageAspect=0;aspect=fixed;image={image};')
 def arrow(self,points,dashed=False,color=INK,label=None):
  self.n+=1;c=E.SubElement(self.root,'mxCell',id=str(self.n),value='',style=f'endArrow=block;endFill=1;html=0;rounded=0;strokeWidth=2.4;strokeColor={color};dashed={1 if dashed else 0};',edge='1',parent='1');g=E.SubElement(c,'mxGeometry',relative='1');g.set('as','geometry')
  for pt,name in [(points[0],'sourcePoint'),(points[-1],'targetPoint')]:p=E.SubElement(g,'mxPoint',x=str(pt[0]),y=str(pt[1]));p.set('as',name)
  if len(points)>2:
   ar=E.SubElement(g,'Array');ar.set('as','points')
   for x,y in points[1:-1]:E.SubElement(ar,'mxPoint',x=str(x),y=str(y))
 def save(self):
  p=OUT/f'{self.name}.drawio';p.write_bytes(E.tostring(self.file,xml_declaration=True,encoding='UTF-8',pretty_print=True));return p
def method():
 d=Diagram('method',1420,725)
 d.text('FRAME: global discovery followed by local comparison',20,0,1000,45,28,INK,True)
 d.text('Shared controller context',20,65,270,35,24,INK,True)
 d.box('Current inputs','Grid observation x\nBase action b\nLegality / cooldown',20,115,270,230,GRAY,'#F4F6F7','network')
 d.box('Candidate\npreparation','Merge equal actions\nRetain aliases M',330,115,280,175,GRAY,'#F4F6F7','layers')
 d.box('Ordered pool A','Fixed / learned order\nQuery each action once',330,320,280,150,GRAY,'#F4F6F7','list-ordered')
 d.vertex('',650,65,420,540,'rounded=1;arcSize=5;dashed=1;dashPattern=4 3;strokeColor='+BLUE+';fillColor=#FAFCFD;strokeWidth=1.5;')
 d.text('Progressive evaluation',670,75,380,38,25,BLUE,True)
 d.box('Initial prefix','Query min(128, |A|) actions\nSelect best admissible action',675,130,370,125,BLUE,'#EDF3F7','search')
 d.box('Batch expansion','Query next up to 64 actions\nLoading / plateau stop',675,300,370,125,BLUE,'#EDF3F7','search')
 d.box('Query feedback Q','Reward r, loading ρ, validity\nUpdate C, a* and h',675,470,370,130,BLUE,'#EDF3F7',None)
 d.box('Substation\ncompletion','Fix substation s*\nQuery remaining L\nKeep best action',1130,300,280,175,BROWN,'#F8F2E9','git-branch')
 d.box('Controller output','Proposal a* or fallback\nControl + recovery',1130,130,280,125,GREEN,'#EDF5F1','check')
 d.arrow([(290,190),(330,190)]);d.arrow([(470,290),(470,320)]);d.arrow([(610,385),(635,385),(635,193),(675,193)])
 d.arrow([(860,255),(860,300)]);d.text('Continue',875,260,150,35,24,BLUE)
 d.arrow([(1045,193),(1130,193)]);d.text('Direct return',1065,90,165,35,24,GREEN)
 d.arrow([(1045,370),(1130,370)]);d.text('Stop',1070,320,60,30,24,BROWN)
 d.arrow([(1270,300),(1270,255)]);d.arrow([(860,425),(860,470)])
 d.arrow([(675,515),(655,515),(655,363),(675,363)],True,BLUE)
 d.text('Direct return: safe prefix or exhausted pool.',20,525,600,35,24,INK)
 d.text('Completion: after extended search,\nwhen an incumbent and unqueried actions remain.',20,563,610,62,24,INK)
 d.arrow([(20,680),(85,680)]);d.text('Main flow',96,659,150,40,22)
 d.arrow([(320,680),(385,680)],True,BLUE);d.text('Query feedback',396,659,230,40,24,BLUE)
 d.save()
def teaser():
 d=Diagram('motivation',1420,450)
 d.text('Global rankings can leave a useful substation only partially compared',20,0,1380,45,28,INK,True)
 for x,title in [(20,'(a) Exhaustive comparison'),(500,'(b) Global early stopping'),(980,'(c) FRAME local completion')]:
  d.vertex('',x,70,420,280,'rounded=1;arcSize=6;fillColor=#FAFBFC;strokeColor=#CBD4DC;strokeWidth=1.5;')
  d.text(title,x+16,83,392,37,24,INK,True)
 groups=['A','B','C','A','B','A','C','A'];cols={'A':GREEN,'B':BLUE,'C':BROWN};fills={'A':'#E7F1ED','B':'#EAF1F6','C':'#F6EFE5'}
 for panel,x in enumerate([20,500,980]):
  for i,g in enumerate(groups):
   cx=x+18+(i%4)*98;cy=147+(i//4)*67
   queried=panel==0 or i<4 or (panel==2 and g=='A')
   style=f'rounded=1;arcSize=8;fillColor={fills[g] if queried else "#FFFFFF"};strokeColor={cols[g]};strokeWidth={3 if panel==2 and i==7 else 1.8};dashed={0 if queried else 1};'
   d.vertex('',cx,cy,83,48,style);d.text('S'+g,cx,cy,83,48,23,cols[g],False,'center')
   if panel==2 and i==7:d.icon('check',cx+60,cy+25,24,GREEN)
  text=['Compare all configuration groups\nRanking interleaves substations','Prefix finds substation A\nLater A configurations remain','Complete unqueried A actions\nKeep the best observed proposal'][panel]
  d.text(text,x+18,282,388,60,24,INK)
 d.arrow([(455,202),(487,202)]);d.arrow([(935,202),(967,202)])
 d.text('SA / SB / SC: substations',20,363,440,35,24,INK)
 d.text('Illustrative order',20,402,230,35,24,INK)
 d.text('Filled: compared • Dashed: unqueried • Dark outline: recovered alternative',310,402,1090,35,24,INK)
 d.save()
if __name__=='__main__':method();teaser();print('Native draw.io diagrams generated from the prewritten specifications.')
