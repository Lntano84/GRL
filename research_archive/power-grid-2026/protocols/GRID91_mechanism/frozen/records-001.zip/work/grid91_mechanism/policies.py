"""Modular default FRAME, with redundant qmin removed; no simulator dependency."""
import struct

DEFAULT = dict(p=128, h=64, patience=2, safe=.9)


def key(row):
    return struct.unpack('f', struct.pack('f', row['reward']))[0], -row['pool_id']


def completion_ids(order, seen, chosen, subids, aliases):
    sub = int(subids[chosen])
    targets = {int(rep) for alias, rep in aliases.items()
               if int(subids[int(alias)]) == sub}
    return sub, [i for i in order if i not in seen and i in targets]


def run(order, observe, policy, subids, aliases, params=None, context=None,
        limit=None, model_path=None):
    assert policy in ('FRAME_GUARD', 'NO_LOCAL', 'GLOBAL_MATCH')
    assert not params and model_path is None
    assert len(order) == len(set(order))
    rows, events, seen = [], [], set()
    best = None

    def evaluate(ids, phase):
        nonlocal best
        before = None if best is None else key(best)
        for i in ids:
            assert i not in seen
            r = observe(i, phase)
            assert r['pool_id'] == i
            seen.add(i)
            rows.append(r)
            if r['strict_admissible'] and (best is None or key(r) > key(best)):
                best = r
        improved = best is not None and (before is None or key(best) > before)
        events.append(dict(queries=len(rows), phase=phase,
                           chosen=None if best is None else best['pool_id'],
                           improved=improved))
        return improved

    # Initialization, rather than an independent search-control mechanism.
    n = min(DEFAULT['p'], len(order))
    evaluate(order[:n], 'shortlist')
    prefix = None if best is None else best['pool_id']
    prefix_safe = best is not None and best['rho'] < DEFAULT['safe']

    # Feedback controls depth. With these defaults two full stale batches
    # already imply >=128+2*64=256 queries, so qmin adds no condition.
    reason, stale = 'full_exhaustion', 0
    for offset in range(n, len(order), DEFAULT['h']):
        improved = evaluate(order[offset:offset+DEFAULT['h']],
                            'verification' if prefix_safe else 'fallback')
        stale = 0 if improved else stale + 1
        if not prefix_safe and best is not None and best['rho'] < DEFAULT['safe']:
            reason = 'verified_below_author_safe'
            break
        if best is not None and stale >= DEFAULT['patience'] and len(rows) < len(order):
            reason = 'guard_verified_plateau' if prefix_safe else 'patience64_experimental_stop'
            break

    # Completion changes the search location, without altering depth control.
    before_extra = None if best is None else best['pool_id']
    sub, candidates, extra = None, [], []
    if before_extra is not None and len(rows) < len(order) and (
            not prefix_safe or before_extra != prefix):
        sub, candidates = completion_ids(order, seen, before_extra, subids, aliases)
        if policy != 'NO_LOCAL':
            extra = ([i for i in order if i not in seen][:len(candidates)]
                     if policy == 'GLOBAL_MATCH' else candidates.copy())
            evaluate(extra, 'global_budget_extension' if policy == 'GLOBAL_MATCH'
                     else 'local_completion')
            reason += '_global_budget_complete' if policy == 'GLOBAL_MATCH' else '_local_complete'
    elif prefix_safe and len(rows) < len(order):
        reason += '_unchanged_incumbent'

    return dict(outcomes=rows, chosen_pool_id=None if best is None else best['pool_id'],
                shortlist_choice=prefix, fallback=len(rows)>min(128,len(order)),
                stop_reason=reason, events=events, public_queries=len(rows),
                local_substation=sub, local_queries=len(extra) if policy=='FRAME_GUARD' else 0,
                completion_budget=len(candidates),
                global_extra_queries=len(extra) if policy=='GLOBAL_MATCH' else 0,
                pre_extra_choice=before_extra, completion_candidate_ids=candidates,
                extra_selected_ids=extra, verification_guard=prefix_safe,
                prefix_safe_at_entry=prefix_safe,
                parameters=dict(DEFAULT), qmin_is_derived=True)
