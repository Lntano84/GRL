from pathlib import Path
from copy import deepcopy
import sys,re,json,hashlib,shutil
from docx import Document
from docx.shared import Pt,Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from methods import EN,CN,LATEX,ALGORITHM_EN,ALGORITHM_CN
ROOT=Path('D:/Codex/GRL研究');HERE=Path(__file__).resolve().parent;OUT=ROOT/'outputs/grid_icaps_v3';OUT.mkdir(exist_ok=True)
sources={'cn':ROOT/'outputs/grid_icaps_cn_v2/ICAPS2027_中文重写稿_v2.docx','en':ROOT/'outputs/grid_icaps_en_from_cn_v2/ICAPS2027_English_from_author_CN_V2.docx'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def m(tag):return OxmlElement('m:'+tag)
def mr(text):
 r=m('r');pr=m('rPr');n=m('nor');pr.append(n);r.append(pr);t=m('t');t.set(qn('xml:space'),'preserve');t.text=text;r.append(t);return r
def sub(text,index):
 r=m('sSub');e=m('e');e.append(mr(text));s=m('sub');s.append(mr(index));r.extend([e,s]);return r
def sup(text,index):
 r=m('sSup');e=m('e');e.append(mr(text));s=m('sup');s.append(mr(index));r.extend([e,s]);return r
def low(text,atoms):
 r=m('limLow');e=m('e');e.append(mr(text));s=m('lim')
 for a in atoms:s.append(mr(a) if isinstance(a,str) else a)
 r.extend([e,s]);return r
def formula(doc,i):
 p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 para=m('oMathPara');expr=m('oMath');para.append(expr)
 if i==0:atoms=[sub('F','C'),' = {a ∈ C : v(a) = 1, 0 < ρ(a) < min(ρ(x), θ)}']
 elif i==1:atoms=[sup('a','*'),'(C) = ',low('arg max',['a ∈ ',sub('F','C')]),' r(a)']
 else:atoms=['L = {a ∈ A ∖ C : ∃ j ∈ M(a), s(j) = ',sup('s','*'),'}']
 for atom in atoms:expr.append(mr(atom) if isinstance(atom,str) else atom)
 p._p.append(para);return p
def patch(lang):
 src=sources[lang];before=sha(src);doc=Document(src);items=EN if lang=='en' else CN
 ps=doc.paragraphs
 start=next(p for p in ps if p.style.name=='Heading 1' and p.text.startswith('2'))
 end=next(p for p in ps if p.style.name=='Heading 1' and p.text.startswith('3'))
 body=doc._element.body;idx=body.index(start._p)+1;stop=body.index(end._p)
 originalfigure=next(deepcopy(p._p) for p in ps if p._p.xpath('.//w:drawing'))
 oldtables=[[ [c.text for c in r.cells] for r in t.rows] for t in doc.tables]
 for el in list(body)[idx:stop]:body.remove(el)
 # Insert new Method elements immediately before Experiments.
 for kind,value in items:
  if kind=='h2':p=doc.add_paragraph(value,style='Heading 2')
  elif kind=='eq':p=formula(doc,value)
  elif kind=='figure':
   p=doc.add_paragraph();p.add_run().add_picture(str(OUT/'figures/method.png'),width=Cm(16.4));end._p.addprevious(p._p)
   p=doc.add_paragraph(value);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
  elif kind=='algorithm':
   caption='Algorithm 1. Progressive Evaluation and Substation Completion' if lang=='en' else '算法1 渐进评估与变电站补全'
   p=doc.add_paragraph(caption);p.paragraph_format.keep_with_next=True;end._p.addprevious(p._p)
   p=doc.add_paragraph();lines=ALGORITHM_EN if lang=='en' else ALGORITHM_CN
   p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.left_indent=Pt(8);p.paragraph_format.line_spacing=1.05
   p.paragraph_format.keep_together=True
   for i,line in enumerate(lines):
    r=p.add_run(f'{i+1:2d}  {line}'+('\n' if i<len(lines)-1 else ''));r.font.name='Consolas';r.font.size=Pt(9)
    r._r.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'宋体')
  else:p=doc.add_paragraph(value)
  end._p.addprevious(p._p)
 # Add all three figure classes at their corresponding manuscript sections.
 def picture_before(anchor,name,caption):
  p=doc.add_paragraph();p.add_run().add_picture(str(OUT/'figures'/f'{name}.png'),width=Cm(16.4));p.paragraph_format.keep_with_next=True;anchor.addprevious(p._p)
  p=doc.add_paragraph(caption);p.alignment=WD_ALIGN_PARAGRAPH.CENTER;anchor.addprevious(p._p)
 picture_before(start._p,'motivation','Figure 1. Interleaved configurations motivate local completion.' if lang=='en' else '图1 全局排名中交错的配置为局部补全提供动机。')
 ps=doc.paragraphs
 h=next(p for p in ps if p.text.startswith('3.3'))
 target=h._p.getnext();picture_before(target,'results','Figure 3. Query reduction, timing repetitions and full-week quality.' if lang=='en' else '图3 查询减少、两次计时重复与整周质量。')
 h=next(p for p in ps if p.text.startswith('3.4'));target=h._p.getnext().getnext();picture_before(target,'completion_case','Figure 4. Single-step recovery and the March full-week outcome.' if lang=='en' else '图4 单步动作找回与三月整周结果。')
 assert oldtables==[[[c.text for c in r.cells] for r in t.rows] for t in doc.tables]
 # Precise current related-work positioning, with a verified planning reference.
 section=next(p for p in doc.paragraphs if p.text.startswith('5.2'))
 target=section._p.getnext()
 extra=' Budd et al. use contextual performance profiles and a learned policy to decide when to stop probabilistic planning and how to set its hyperparameters [7].' if lang=='en' else 'Budd等利用条件性能曲线与学习策略决定何时停止概率规划以及如何设置超参数[7]。'
 p=next(p for p in doc.paragraphs if p._p is target);p.add_run(extra)
 doc.add_paragraph('[7] Budd, M.; Lacerda, B.; and Hawes, N. 2024. Stop! Planner Time: Metareasoning for Probabilistic Planning Using Learned Performance Profiles. Proceedings of AAAI 38(18):20053–20060. DOI: 10.1609/aaai.v38i18.29983.')

 # All empirical tables and the author's prose outside Method are preserved.
 doc.core_properties.author='';doc.core_properties.last_modified_by=''
 name='ICAPS2027_English_Methods_V3.docx' if lang=='en' else 'ICAPS2027_中文方法修订稿_V3.docx'
 doc.save(OUT/name);assert sha(src)==before
 return {'source':str(src),'source_sha256':before,'output':name,'tables_preserved':True}
def method_md(items,lang):
 lines=[]
 for k,v in items:
  if k=='h2':lines.append('### '+v)
  elif k=='eq':lines.append('\\[\n'+LATEX[v]+'\n\\]')
  elif k=='figure':lines.extend(['![Framework](figures/method.png)',v])
  elif k=='algorithm':lines.extend(['Algorithm 1. Progressive Evaluation and Substation Completion' if lang=='en' else '算法1 渐进评估与变电站补全','```text\n'+'\n'.join(ALGORITHM_EN if lang=='en' else ALGORITHM_CN)+'\n```'])
  else:lines.append(v)
 return '\n\n'.join(lines)+'\n'
if __name__=='__main__':
 receipt=[patch('cn'),patch('en')]
 text=(ROOT/'outputs/grid_icaps_en_from_cn_v2/manuscript_en.md').read_text(encoding='utf-8')
 a=text.index('### 2.1');b=text.index('## 3 Experiments')
 text=text[:a]+method_md(EN,'en')+'\n'+text[b:]
 (OUT/'manuscript_en.md').write_text(text,encoding='utf-8')
 (OUT/'Methods_中文.md').write_text('## 2 方法\n\n'+method_md(CN,'cn'),encoding='utf-8')
 (OUT/'source_preservation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Methods rewritten; both source DOCX files and empirical tables retained.')
