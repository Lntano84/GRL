"""Append-only source/record publication, excluding runtime and large raw vectors."""
from pathlib import Path
import argparse,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[2];W=Path(__file__).parent;OUT=ROOT/'outputs/grid90_expert';REPO=ROOT/'work/GRL-results-integration'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))


def append_once(path,key,text):
    raw=path.read_bytes()
    if key.encode() not in raw:path.write_bytes(raw+b'\n'+text.encode('utf-8').strip()+b'\n')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['frozen','complete'],required=True);a=ap.parse_args()
    if a.phase=='complete':assert read(OUT/'review.json')['passed_saved_data']
    dest=REPO/'research_archive/power-grid-2026/protocols/GRID90_expert'/a.phase
    if (dest/'archive_receipt.json').exists():
        receipt=read(dest/'archive_receipt.json')
        assert all(sha(REPO/r['path'])==r['sha256'] for r in receipt['archives'])
        print('EXISTING_ARCHIVE_VERIFIED');return
    dest.mkdir(parents=True,exist_ok=True)
    files=list(W.glob('*.py'))
    files.extend((W/'vendor/ExpertOp4Grid/alphaDeesp').rglob('*.py'))
    files.extend([W/'vendor/ExpertOp4Grid/LICENSE',W/'vendor/ExpertOp4Grid/README.md'])
    files.extend(p for p in (W/'vendor/ExpertAgent').iterdir() if p.is_file())
    excluded=[]
    for p in OUT.rglob('*'):
        if not p.is_file():continue
        if p.suffix in ['.json','.md','.log','.txt'] or p.name.endswith('.jsonl.gz'):files.append(p)
        else:excluded.append(dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
    entries=[];archives=[];batches=[];current=[];size=0
    for p in sorted(set(files)):
        if current and size+p.stat().st_size>24*1024*1024:batches.append(current);current=[];size=0
        current.append(p);size+=p.stat().st_size
    if current:batches.append(current)
    for no,batch in enumerate(batches):
        zpath=dest/f'records-{no+1:03d}.zip'
        with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for p in batch:
                data=p.read_bytes();member=p.relative_to(ROOT).as_posix();z.writestr(member,data)
                entries.append(dict(path=member,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),archive=zpath.name))
        with zipfile.ZipFile(zpath) as z:
            assert z.testzip() is None
            for e in entries:
                if e['archive']==zpath.name:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
        archives.append(dict(path=zpath.relative_to(REPO).as_posix(),sha256=sha(zpath),bytes=zpath.stat().st_size))
    for name in ['design.json','source_receipt.json','preflight.json','review.json','decision.json','GRID90_report.md']:
        if (OUT/name).exists():shutil.copy2(OUT/name,dest/name)
    (dest/'files.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    (dest/'archive_receipt.json').write_text(json.dumps(dict(phase=a.phase,archives=archives,files=len(entries),
         excluded_large_local_vectors=excluded,crc_and_hashes_verified=True,
         vendor_runtime_not_archived=True),ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    key='GRID90_EXPERT_'+a.phase
    note='ExpertOp4Grid外部结构启发式：同六个已暴露G2场景、同合法动作库/基础控制器/一步公共预测，FRAME与ExpertOp适配两次交错反向计时共24条。原作者影响图/专家评分保留，官方25候选/每站5/最多3线路默认固定，所有图构建查询计入。严格公共接口不改保护参数，原方法外围恢复重连不带入。三次真实校准状态及未来向量接口检查通过，不按评价结果调参、选日期或增预算。'
    if a.phase=='complete':note+=' 保存数据/原生结构排名重执行审计通过，冻结判读：'+read(OUT/'decision.json')['category']+'。'
    for name in ['docs/DECISIONS.md','docs/EXPERIMENT_LOG.md']:
        append_once(REPO/name,key,'## 2026-10-19 — '+key+'\n\n'+note)
    state=REPO/'docs/RESEARCH_STATE.md';text=state.read_text(encoding='utf-8')
    if key not in text:
        first,body=text.split('\n',1);state.write_text(first+'\n\n- **'+key+'：** '+note+'\n'+body,encoding='utf-8')
    append_once(REPO/'research_archive/power-grid-2026/README.md',key,
        '## '+key+'\n\n'+note+'\n\n[方案与结果](protocols/GRID90_expert/'+a.phase+'/)')
    (REPO/'docs/NEXT_STEPS.md').write_text('# Next steps\n\n1. '+(
        '阅读GRID90两方法质量、完整周成本、完整控制时间及候选/分析查询；保留不利结果，不以较早终止声称提速。' if a.phase=='complete' else
        '已有GRID90流水线完成24条串行回放和审计；不启动第二运行器，不在计时中安装、训练或做重型检查。')+
        '\n2. META统一配置已归档；ExpertOp为任务适配，不能称原论文任务完整复现。\n3. 结果整理后再修订论文竞争力段落，不自动追加预算、场景、模型或其它基线。\n',encoding='utf-8')
    if a.phase=='complete':
        collab=ROOT/'论文协作资料/FRAME_ExpertOp启发式对照_20261019';collab.mkdir(exist_ok=True)
        for name in ['GRID90_report.md','review.json','decision.json','design.json','source_receipt.json']:
            shutil.copy2(OUT/name,collab/name)
    print(json.dumps(dict(phase=a.phase,files=len(entries),archives=len(archives))),flush=True)


if __name__=='__main__':main()
