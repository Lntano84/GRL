FROZEN:48 serial existing-development rollouts; zero fits/new scenarios; final test sealed.
