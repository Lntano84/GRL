# GRID08 v2: residual-control training pilot

Binary policy chooses whether to execute a separately generated safe-continuous restoration. Original NN20, action library and unsafe controller are preserved. No learned topology ranking has been attempted.

| Week | Method | Steps | Completed | Raw cost | Offered / selected |
|---|---|---:|---|---:|---:|
| 2035-02-12_5 | gnn | 2017 | True | 2814161.419 | 158 / 158 |
| 2035-05-21_3 | gnn | 2017 | True | 2107156.579 | 234 / 234 |
| 2035-08-20_5 | gnn | 2017 | True | 1378460.914 | 250 / 250 |
| 2035-11-05_12 | gnn | 2017 | True | 2053114.814 | 232 / 232 |
| 2035-02-12_5 | mlp | 2017 | True | 2814161.419 | 158 / 158 |
| 2035-05-21_3 | mlp | 2017 | True | 2107156.579 | 234 / 234 |
| 2035-08-20_5 | mlp | 2017 | True | 1378460.914 | 250 / 250 |
| 2035-11-05_12 | mlp | 2017 | True | 2053114.814 | 232 / 232 |

Raw costs are benchmark accounting units. Do not compare lower cumulative cost from earlier failures. Only jointly completed pairs are cost-ranked.

One training seed, four synthetic validation weeks, author pretraining identities unknown. These results cannot establish publication novelty, robust safety, or population improvement.

MLP receives node/global arrays and a padded edge table; GNN receives the same information through message passing. Parameter counts differ and are recorded.

First logger-only attempt failed on NumPy float serialization after one physical step per process, before any PPO update; v0_LOGGING_FAILED and the source are preserved. It is not a negative model result.

Pre-outcome design revision replaced unextracted archive names with the original extracted monthly validation subset, and set a terminal penalty to discourage premature termination. Both versions retained.

Audit: {"passed": true, "version": "v2", "episodes": 40, "physical_steps": 76412, "ledgers_checked": 76403, "max_abs_ledger_residual": 0.019379313855552027, "actual_illegal_or_ambiguous_runs": [], "original_assets_unchanged": true, "scope": "Independent persisted vector accounting; not independent reruns or fits."}
