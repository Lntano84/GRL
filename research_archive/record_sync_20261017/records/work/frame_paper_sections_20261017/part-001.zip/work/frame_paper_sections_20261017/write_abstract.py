from pathlib import Path
import datetime as dt,hashlib,json,statistics,shutil
R=Path(__file__).resolve().parents[2];O=R/'outputs/frame_paper_sections_20261017/01_摘要';REPO=R/'work/GRL-results-integration'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sentences=[
'在线电网拓扑控制通过预测候选动作的运行后果改善电网状态，大量逐候选仿真带来较高的在线计算开销。',
'不同运行状态所需的搜索深度存在差异，统一查询预算难以将评估计算集中到可能改变控制动作的关键候选上。',
'本文提出反馈驱动的拓扑搜索框架FRAME，将候选评估组织为前缀筛查、分批核查和同站补查，依据已获得的预测反馈控制全局搜索深度，并利用动作的变电站归属确定补查范围。',
'FRAME复用已查询结果并保留最佳已评估动作，可直接接入现有控制器，无需额外训练搜索控制策略。',
'在一个公开电网的6个生成时序场景上，相对完整候选搜索，FRAME的查询量和完整控制时间宏平均分别减少65.10%和14.98%，最大可比完整周成本增幅为0.087%；在另外13个时序场景中，相对每次搜索固定查询512个候选的策略，FRAME减少33.57%的查询，质量达标场景数为13/13，对照为11/13。'
]
abstract=''.join(sentences);assert abstract.count('。')==5
oldfiles=[R/'outputs/grid_icaps_cn_v4/ICAPS2027_中文全文修订稿_V4.docx',R/'outputs/grid_icaps_cn_v5/ICAPS2027_中文研究稿_V5.docx']
oldhash={p.relative_to(R).as_posix():sha(p) for p in oldfiles if p.exists()}
a=read(R/'outputs/grid81/review.json');b=read(R/'outputs/grid88/review.json');pairs=[]
for x in a['groups']:
 if x['method']!='FRAME_GUARD':continue
 y=next(v for v in a['groups'] if v['date']==x['date'] and v['method']=='FULL');pairs.append(dict(date=x['date'],query_reduction=None if not y['queries'] else 1-x['queries']/y['queries'],time_reduction=1-x['controller_s']/y['controller_s'],cost_delta=x['cost_delta_full'],quality=x['quality_pass']))
metrics=dict(generated_dates=len(pairs),query_active_dates=sum(x['query_reduction'] is not None for x in pairs),query_macro=statistics.mean(x['query_reduction'] for x in pairs if x['query_reduction'] is not None),time_macro=statistics.mean(x['time_reduction'] for x in pairs),max_comparable_cost=max(x['cost_delta'] for x in pairs if x['cost_delta'] is not None),original_dates=13,query_macro_fixed512=b['comparisons'][0]['macro_query_reduction_equal_horizons'],guard_quality=b['guard_quality_dates'],fixed512_quality=b['comparisons'][0]['quality_dates'])
assert round(metrics['query_macro']*100,2)==65.10 and round(metrics['time_macro']*100,2)==14.98 and round(metrics['max_comparable_cost']*100,3)==.087
assert round(metrics['query_macro_fixed512']*100,2)==33.57 and metrics['guard_quality']==13 and metrics['fixed512_quality']==11
main=O/'FRAME_中文摘要_逐节重写_V1.md';assert not main.exists();main.write_text('# 摘要\n\n'+abstract+'\n',encoding='utf8')
notes='''# 摘要指南阅读与逐句核对

本轮只写中文版摘要，等用户检查后再写下一部分。没有生成英文稿或图，也未修改旧稿。

## 指南原页

仓库：https://github.com/LAMDA-NeSy/Research-Starter-Kit
实际打开的摘要页面：https://dy8q0bnq8y.feishu.cn/wiki/Tz2pwvxTyiBK0zkCVszcZmJ3nwd

阅读方式：2026-10-17从仓库Abstract链接进入。网页检索接口重定向登录，随后用实际浏览器成功打开公开正文，阅读“基本思路”“五句话原则”和全部三个优秀案例；案例图片逐一滚动查看到结尾。未只依据仓库目录或历史缓存写作。

## 指南要求如何落实

| 句子 | 功能 | 落实方式 |
|---|---|---|
| 1 | 任务背景 | 直接交代电网拓扑控制及逐候选预测仿真的计算开销 |
| 2 | 科学问题 | 将问题定位为不同状态搜索需求与统一预算之间的计算分配问题 |
| 3 | 方法思想 | 解释前缀筛查、反馈核查与同站补查如何控制搜索深度和补查范围 |
| 4 | 方法接入 | 说明反馈复用和无需新增搜索控制策略训练；不扩大为整套控制器无需训练 |
| 5 | 量化结果 | 分开报告6个生成场景对FULL、13个其他场景对固定512；查询、实际控制时间和质量分别对应原指标 |

## 三个案例学习记录

- Train for the Worst, Plan for the Best：学习从结构性问题引出核心思想，再用任务中的明确数字闭合结论。
- Heterogeneous Vocabularies Speculative Decoding：学习背景短、问题具体、方法直接回应问题，并报告与计算加速直接相关的指标。
- LLM-SRBench：学习交代实验覆盖范围和可核查的结果，避免只用笼统“若干SOTA”支撑贡献。

借鉴的是组织方式与问题到结果的联系；没有挪用案例性能、理论性质或创新声称。

## 数字与措辞核对

1. GRID81查询65.10%：5个活跃且等时域场景的查询比例宏平均；六场景中的1个无搜索。控制时间14.98%对全部六场景日期比例宏平均，先平均同日期两次计时。0.087%来自双方完成整周的4个场景的最大相对成本差。
2. GRID88查询33.57%：12个活跃且等时域日期的比例宏平均，另1日期双方都无搜索。质量达标为预设0.5%完整周成本容差与不早于FULL终止，FRAME13/13、固定512为11/13；两方法整周完成数都11/13。摘要未将质量达标数写成整周完成数。
3. 两批来自同一公开电网，6+13是时序场景，不是19个电网或数据集。计时重复不增加场景数。
4. 摘要未宣称胜过全部会议方法、普适结构创新、独立GNN贡献或一般长期安全保证。对照固定512的整体控制时间3.883%未通过既定5%投资门槛，未改写为门槛通过。
5. 原始较差结果与已有稿件保留；本轮没有新增仿真或训练。

## 待用户检查

重点看第二句是否准确表达研究问题、第三句是否清楚表达方法思想，以及最后一句数字密度是否合适。本轮到摘要结束，不继续写引言。
'''
(O/'摘要指南阅读与逐句核对.md').write_text(notes,encoding='utf8')
sourcefiles=[R/'outputs/grid81/review.json',R/'outputs/grid88/review.json',R/'work/grid70/policies.py']
receipt=dict(created_utc=dt.datetime.now(dt.timezone.utc).isoformat(),language='Chinese',section_only='abstract',sentences=sentences,character_count=len(abstract),metrics_recomputed=metrics,source_files=[dict(path=p.relative_to(R).as_posix(),sha256=sha(p)) for p in sourcefiles],preserved_draft_hashes=oldhash,guide_live_browser_read=True,guide_examples_read=3,new_simulations=0,new_training=0,english_sections=0,figures=0,awaiting_user_review=True)
(O/'revision_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
for p,h in oldhash.items():assert sha(R/p)==h
C=R/'论文协作资料/FRAME_论文逐节重写_20261017/01_摘要';assert not C.exists();shutil.copytree(O,C)
A=REPO/'research_archive/power-grid-2026/protocols/FRAME_CN_section01_abstract_20261017';assert not A.exists();shutil.copytree(O,A)
for name in ['DECISIONS.md','EXPERIMENT_LOG.md']:
 p=REPO/'docs'/name;p.write_text(p.read_text(encoding='utf8')+'\n## 2026-10-17 — 中文逐节重写 01摘要\n\n按用户要求实际打开Research-Starter-Kit所链飞书Abstract正文，读基本思路、五句话原则和三个案例图片；完成五句中文版摘要及逐句要求/数据来源核对。只写摘要，等待用户修改，不写引言、不画图、不生成英文、不覆盖原稿。两批数据分开，查询与实际控制时间口径各自核对。\n',encoding='utf8')
(REPO/'docs/NEXT_STEPS.md').write_text('# Next steps\n\n1. 等待用户检查新版中文摘要，材料在FRAME_CN_section01_abstract_20261017；仅按反馈修摘要，确认后才进入下一节。\n2. 下一节写作前实际打开对应指南正文和案例，逐项落实。画图留到文字部分完成后。\n3. 不新增实验/模型/预算。保留原稿与全部GRID86–88结果及边界。\n',encoding='utf8')
p=REPO/'research_archive/power-grid-2026/README.md';p.write_text(p.read_text(encoding='utf8')+'\n## FRAME中文逐节重写 01摘要 2026-10-17\n\n[新版摘要和指南核对](protocols/FRAME_CN_section01_abstract_20261017/)\n\n五句中文版摘要，实际重读飞书指南三个案例，等待用户审改；本轮止于摘要，旧稿和结果保留。\n',encoding='utf8')
print(json.dumps(dict(saved=main.as_posix(),sentences=len(sentences),characters=len(abstract),metrics=metrics,old_drafts_unchanged=True),ensure_ascii=False))
