# Two-step guard: training-only qualification

| Training week | One-step survival | Two-step survival | Vetoes | Cost reduction on jointly complete episodes |
|---|---:|---:|---:|---:|
| 2035-01-29_4 | 1719 | 1719 | 0 | NA |
| 2035-10-29_15 | 2017 | 2017 | 0 | 0.0000% |

This is a training-only failure/interface check. A two-step no-op continuation is not a full-week safety guarantee and does not rescue unsafe actions made by the unchanged NN20 base. Costs of incomplete episodes are not ranked. No learned model was changed or fitted.

{"passed": true, "physical_steps": 7472, "ledger_checks": 7470, "max_abs_residual": 0.019078296036695974}
