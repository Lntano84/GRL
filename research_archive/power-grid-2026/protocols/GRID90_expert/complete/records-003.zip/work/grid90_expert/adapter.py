"""ExpertOp influence graph/ranking on a shared action library and public oracle.

The vendor graph and topology scores are unmodified. Task adaptations are explicit:
same candidate library, one-step public forecasts, shared base action/admissibility,
and the largest monitored line when the common controller calls below rho=1.
"""
from pathlib import Path
import functools
import importlib.util
import time
import sys

ROOT=Path(__file__).resolve().parents[2]
W=Path(__file__).parent
sys.path[:0]=[str(W/'deps'),str(W/'vendor/ExpertOp4Grid')]


@functools.lru_cache(maxsize=1)
def vendor():
    from alphaDeesp.core.grid2op.Grid2opSimulation import Grid2opSimulation, score_changes_between_two_observations
    from alphaDeesp.core.alphadeesp import AlphaDeesp
    from alphaDeesp.core.graphsAndPaths import OverFlowGraph
    return Grid2opSimulation,AlphaDeesp,OverFlowGraph,score_changes_between_two_observations


class ProbeUnavailable(Exception):
    """A legal public counterfactual did not supply a usable connected power flow."""


def expert_search(search,obs,base,reward,done=False,**kwargs):
    from common import np,flags,action_vector,digest,graph_features
    started=time.perf_counter()
    eligible,reps,aliases,actions,changed=search.prepare(obs,base)
    prepared=time.perf_counter()
    x,e,g=graph_features(obs,search.env,dict(offered=False,predictions=[None,None]))
    context=dict(x=x,edges=e,glob=g)
    Sim,Alpha,OverGraph,score_changes=vendor()
    limit=min(float(obs.rho.max()),float(kwargs.get('rho_threshold',obs.rho.max())))
    cfg=dict(totalnumberofsimulatedtopos=25,numberofsimulatedtopospernode=5,
             maxUnusedLines=2,ratioToReconsiderFlowDirection=.75,ratioToKeepLoop=.25,
             ThersholdMinPowerOfLoop=.1,ThresholdReportOfLine=.2)
    candidate_cache={};future_cache={};outcomes=[];probes=[];analyses=[]
    search._expert_future_vectors={}
    search._expert_future_template=None
    forecast_s=0.;best=None;ranked_considered=[];events=[]
    key=lambda r:(float(np.float32(r['reward'])),-int(r['pool_id']))

    def purchase(i):
        nonlocal forecast_s,best
        if i in candidate_cache:return candidate_cache[i],future_cache[i]
        t=time.perf_counter();future,rr,ended,info=obs.simulate(actions[i]+base,time_step=1)
        elapsed=time.perf_counter()-t;forecast_s+=elapsed
        f=flags(info);rho=float(future.rho.max())
        valid=bool(0<rho<limit and not ended and not f['exceptions'] and not f['illegal'] and not f['ambiguous'])
        row=dict(pool_id=int(i),rho=rho,reward=float(rr),done=bool(ended),**f,
                 strict_admissible=valid,forecast_s=elapsed,phase='expert_candidate')
        candidate_cache[i]=row;future_cache[i]=(future,bool(ended),info);outcomes.append(row)
        if search._expert_future_template is None:search._expert_future_template=future.copy()
        search._expert_future_vectors[i]=future.to_vect().copy()
        if valid and (best is None or key(row)>key(best)):best=row
        return row,future_cache[i]

    class PublicSimulation(Sim):
        def cut_lines_and_recomputes_flows(self,ids):
            nonlocal forecast_s
            # A diagnostic intervention is not an action proposal. It acts on the
            # current observation, separately from the common continuous action.
            action=self.action_space({'set_line_status':[(int(i),-1) for i in ids]})
            t=time.perf_counter();future,rr,ended,info=obs.simulate(action,time_step=1)
            elapsed=time.perf_counter()-t;forecast_s+=elapsed
            f=flags(info)
            probes.append(dict(lines=[int(i) for i in ids],time_step=1,done=bool(ended),
                reward=float(rr),**f,forecast_s=elapsed,action_vector=action_vector(action).tolist(),
                future_vector=future.to_vect().tolist(),action_hash=digest(action_vector(action))))
            if ended or f['exceptions'] or f['illegal'] or f['ambiguous'] or not np.isfinite(future.p_or).all():
                raise ProbeUnavailable('Public line-cut forecast unavailable')
            self.obs_linecut=future
            self.topo_linecut=self.extract_topo_from_obs(future)
            self.lines_outaged_cut=np.flatnonzero(~future.line_status)
            return future.p_or.copy()

    # Shared aliases preserve the original substation membership of masked actions.
    by_sub={}
    for raw,rep in aliases.items():
        s=int(search.subids[int(raw)])
        by_sub.setdefault(s,[])
        if int(rep) not in by_sub[s]:by_sub[s].append(int(rep))
    configs={};pool_ids={}
    def node_configs(node):
        node=int(node)
        if node in configs:return configs[node]
        objects=obs.get_obj_connect_to(substation_id=node)
        positions=np.concatenate([obs.gen_pos_topo_vect[objects['generators_id']],
            obs.load_pos_topo_vect[objects['loads_id']],obs.line_or_pos_topo_vect[objects['lines_or_id']],
            obs.line_ex_pos_topo_vect[objects['lines_ex_id']]]).astype(int)
        values=[];identifiers=[]
        for i in by_sub.get(node,[]):
            effect=(actions[i]+base).set_bus
            buses=np.where(effect[positions]>0,effect[positions],obs.topo_vect[positions])
            # Disconnected ends have zero flow in the influence graph. The shared
            # candidate itself remains masked and is never reconnected by this projection.
            topo=tuple(int(v-1) if v>0 else 0 for v in buses)
            # Distinct shared representatives may have the same projection when
            # storage terminals are omitted by the upstream expert element model.
            # Keep all IDs: an expert-score tie must not delete a legal action.
            values.append(list(topo));identifiers.append(i)
        configs[node]=values
        pool_ids[node]=identifiers
        return values

    class RestrictedAlpha(Alpha):
        def compute_all_combinations(self,node):
            values=node_configs(node)
            expected=len(self.simulator_data['substations_elements'][node])
            assert all(len(v)==expected for v in values),(node,expected)
            return values
        def rank_topologies(self,all_combinations,graph,node):
            df=super().rank_topologies(all_combinations,graph,node)
            df['_pool_id']=[-1,*pool_ids[int(node)]]
            return df

    root_order=sorted((int(i) for i in np.flatnonzero(obs.line_status)),key=lambda i:(-float(obs.rho[i]),i))
    overflow=[i for i in root_order if obs.rho[i]>=1]
    allowed=int(search.env.parameters.NB_TIMESTEP_OVERFLOW_ALLOWED)
    overflow=[i for i in overflow if obs.timestep_overflow[i]==allowed]+[
              i for i in overflow if obs.timestep_overflow[i]!=allowed]
    monitored=(overflow[:3] if overflow else root_order[:1])
    for line in monitored:
        start=time.perf_counter()
        try:
            sim=PublicSimulation(obs,search.env.action_space,search.env.observation_space,
                param_options=cfg,debug=False,ltc=[line],simu_step=int(obs.current_step)+1)
        except ProbeUnavailable as exc:
            analyses.append(dict(line=line,status='unavailable_public_probe',reason=str(exc)))
            continue
        graph=OverGraph(sim.topo,[line],sim.get_dataframe())
        data=dict(substations_elements=sim.get_substation_elements(),
                  substation_to_node_mapping=sim.get_substation_to_node_mapping(),
                  internal_to_external_mapping=sim.get_internal_to_external_mapping())
        antenna=sim.isAntenna()
        if antenna is None:
            alpha=RestrictedAlpha(graph.get_graph(),sim.get_dataframe(),data,
                                  sim.substation_in_cooldown,debug=False)
            ranked=alpha.get_ranked_combinations()
        else:
            import pandas as pd
            values=node_configs(antenna)
            ranked=[pd.DataFrame([dict(score=0.,topology=v,node=int(antenna),_pool_id=i)
                                  for v,i in zip(values,pool_ids[int(antenna)])])]
        count=0;scores=[];line_ids=[];ranks=[]
        for df in ranked:
            per_node=0
            for native_score,row in df.iterrows():
                if count>=cfg['totalnumberofsimulatedtopos'] or per_node>=cfg['numberofsimulatedtopospernode']:break
                node=int(row['node']);topo=tuple(int(v) for v in row['topology'])
                i=int(row['_pool_id'])
                candidate,(future,ended,info)=purchase(i)
                count+=1;per_node+=1;line_ids.append(i)
                score=float(score_changes([line],obs,future,int(search.env.parameters.NB_TIMESTEP_COOLDOWN_LINE)))
                if ended or candidate['illegal'] or candidate['ambiguous'] or candidate['exceptions']:score=0.
                # Native score is a diagnostic/outer-loop stop; final returned action
                # uses exactly the common admissibility and predicted-reward rule.
                scores.append(score if np.isfinite(score) else None)
                ranks.append(dict(pool_id=i,node=node,expert_score=float(native_score),
                                  topology=list(topo),simulated_score=scores[-1]))
            if count>=cfg['totalnumberofsimulatedtopos']:break
        ranked_considered.extend(line_ids)
        analyses.append(dict(line=line,status='ranked',antenna=antenna is not None,
                            considered=count,rankings=ranks,wall_s=time.perf_counter()-start))
        events.append(dict(line=line,queries=len(outcomes)+len(probes),chosen=None if best is None else best['pool_id']))
        if any(score==4 and candidate_cache[i]['strict_admissible'] for score,i in zip(scores,line_ids)):
            break
        if obs.timestep_overflow[line]==allowed and any(
             score==3 and candidate_cache[i]['strict_admissible'] for score,i in zip(scores,line_ids)):
            break
    reason='expert_ranked_candidates_complete' if outcomes else 'expert_no_candidate'
    chosen=None if best is None else best['pool_id']
    log=dict(rule=search.rule,policy='EXPERTOP_SHARED',budget=25,eligible=eligible,representatives=reps,
        aliases=aliases,order=list(reps),shortlist=[],masked_ids=changed,rho_limit=limit,guard_rho=.9,
        guard_reason='external_expert_search',shortlist_choice=None,fallback=False,
        chosen_pool_id=chosen,outcomes=outcomes,public_queries=len(outcomes)+len(probes),
        candidate_queries=len(outcomes),analysis_queries=len(probes),analysis_probes=probes,
        expert_analyses=analyses,expert_monitored_lines=monitored,expert_considered=ranked_considered,
        stop_reason=reason,local_queries=0,local_substation=None,completion_budget=0,
        source_s=time.perf_counter()-started,prepare_s=prepared-started,forecast_s=forecast_s,
        prior_s=0.,feature_s=0.,forward_rank_s=0.,events=events)
    return None if chosen is None else actions[chosen],log,context,None


def install(Search,item):
    if item['policy']=='EXPERTOP_SHARED':
        Search.choose=expert_search
    else:
        spec=importlib.util.spec_from_file_location('grid90_common_frame_adapter',ROOT/'work/grid89_review/adapter.py')
        ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
        ref.install(Search,item)
